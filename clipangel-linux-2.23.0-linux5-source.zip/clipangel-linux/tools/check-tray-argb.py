import time
from Xlib import X, Xatom, display
from clipangel.x11 import X11
from PIL import Image
from struct import unpack

d=display.Display(); screen=d.screen(); root=screen.root
visual=next(v for depth in screen.allowed_depths if depth.depth==32 for v in depth.visuals if v.red_mask==0xff0000 and v.green_mask==0xff00 and v.blue_mask==0xff)
host=root.create_window(100,100,100,100,0,screen.root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1)
host.change_property(d.intern_atom('_NET_SYSTEM_TRAY_VISUAL'), Xatom.VISUALID,32,[visual.visual_id]); host.map(); host.set_selection_owner(d.intern_atom('_NET_SYSTEM_TRAY_S0'),X.CurrentTime); d.sync()
backend=X11(lambda *a: None)
img=Image.new('RGBA',(64,64),(255,0,0,128)); backend.tray(img.tobytes(),64,64); d.sync()
icon=None
for _ in range(100):
 while d.pending_events():
  e=d.next_event()
  if e.type==X.ClientMessage and e.client_type==d.intern_atom('_NET_SYSTEM_TRAY_OPCODE'): icon=d.create_resource_object('window',e.data[1][2]); break
 if icon: break
 time.sleep(.01)
assert icon is not None
hints=icon.get_full_property(Xatom.WM_NORMAL_HINTS,Xatom.WM_SIZE_HINTS).value
assert hints[5:7].tolist()==[24,24] and hints[15:17].tolist()==[24,24]
assert icon.get_geometry().depth==32
icon.reparent(host,0,0); icon.map(); d.sync()
for w,h in [(24,39),(39,24),(48,48),(16,16)]:
 icon.configure(width=w,height=h); d.sync()
 for _ in range(12): backend.poll(); time.sleep(.01)
 def pixel(x,y):
  data=icon.get_image(x,y,1,1,X.ZPixmap,0xffffffff).data
  return unpack('<I', (data.encode('latin1') if isinstance(data,str) else data)[:4])[0]
 assert pixel(w//2,h//2)==0x80800000, hex(pixel(w//2,h//2))
 if w!=h: assert pixel(0,0)==0, hex(pixel(0,0))
 print('ARGB render passed', w,h,flush=True)
backend.close(); host.destroy(); d.close()
