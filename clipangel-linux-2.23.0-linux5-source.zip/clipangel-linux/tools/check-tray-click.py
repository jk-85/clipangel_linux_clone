import os, sys, time, tempfile, pathlib, tkinter as tk
from Xlib import X, display, protocol
from Xlib.ext import xtest
from clipangel.app import Application
from clipangel.core import Store, Settings

d = display.Display(); screen = d.screen(); root = screen.root
host = root.create_window(1100, 720, 100, 45, 0, screen.root_depth, X.InputOutput, X.CopyFromParent, override_redirect=1, background_pixel=0x222222)
host.map(); host.set_selection_owner(d.intern_atom('_NET_SYSTEM_TRAY_S0'), X.CurrentTime); d.sync()
with tempfile.TemporaryDirectory() as temp:
 p=pathlib.Path(temp); os.environ['XDG_CONFIG_HOME']=str(p/'config'); os.environ['XDG_DATA_HOME']=str(p/'data')
 r=tk.Tk(className='ClipAngel'); s=Settings(p/'settings.json'); s['MonitoringClipboard']=False; s['WindowGeometry']='980x560+40+40'; st=Store(p/'history.sqlite3'); app=Application(r, st, s)
 def pump(n=.15):
  end=time.monotonic()+n
  while time.monotonic()<end:
   r.update(); time.sleep(.005)
 pump(.2)
 icon=None
 while d.pending_events():
  e=d.next_event()
  if e.type==X.ClientMessage and e.client_type==d.intern_atom('_NET_SYSTEM_TRAY_OPCODE'):
   icon=d.create_resource_object('window', e.data[1][2]); break
 assert icon is not None
 print('size hints:', icon.get_full_property(d.intern_atom('WM_NORMAL_HINTS'), d.intern_atom('WM_SIZE_HINTS')).value, flush=True)
 icon.reparent(host,5,3); icon.configure(width=24,height=39); icon.map(); d.sync(); pump()
 errors=[]; orig=app.notify
 def notify(msg,*args,**kw):
  errors.append(msg); print('notify:',msg,flush=True); return orig(msg,*args,**kw)
 app.notify=notify
 if len(sys.argv)>1 and sys.argv[1]=='hidden': app.hide(); pump()
 def click(button,down):
  xtest.fake_input(d, X.ButtonPress if down else X.ButtonRelease, button); d.sync(); pump(.3)
 xtest.fake_input(d,X.MotionNotify,x=1115,y=735); d.sync(); pump()
 click(3,True)
 print('after press:', app.tray_menu.winfo_ismapped(), r.grab_current(), flush=True)
 assert not app.tray_menu.winfo_ismapped()
 click(3,False)
 print('after release:', app.tray_menu.winfo_ismapped(), r.grab_current(), flush=True)
 assert app.tray_menu.winfo_ismapped() and str(r.grab_current())==str(app.tray_menu)
 if app.tray_menu.winfo_ismapped():
  m=app.tray_menu; x=m.winfo_rootx()+20; y=m.winfo_rooty()+m.yposition(0)+5
  xtest.fake_input(d,X.MotionNotify,x=x,y=y); d.sync(); pump()
  click(1,True); click(1,False)
  print('after menu action:',r.state(),m.winfo_ismapped(),r.grab_current(),flush=True)
  assert r.state()=='normal' and not m.winfo_ismapped() and r.grab_current() is None
 assert not errors, errors
 app.quit(); host.destroy(); d.close()
