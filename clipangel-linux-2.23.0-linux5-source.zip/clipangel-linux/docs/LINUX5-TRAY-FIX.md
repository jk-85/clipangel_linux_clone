# Preview 5 — local XEmbed tray test build

Based on the supplied 2.23.0~linux4 source. Changes are limited to the tray
renderer, tray click dispatch, popup opening guard, version metadata and tests.
No new runtime dependencies or database changes. A preferred/minimum 24 px
size is advertised to the tray host; the renderer fits the source artwork to
its actual allocation, centers it, and supports premultiplied transparency for
the standard ARGB8888 visual advertised by the host. Non-ARGB hosts retain the
previous RGB background. The original tray manager restart/re-docking behavior
is not comprehensively addressed. No StatusNotifierItem backend was added.

Verification in a virtual X11 session, not in Cinnamon:
- Original build reproduced `grab failed: another application has grab` on
  holding a real right mouse button over a simulated XEmbed tray window.
- Patched build opens the menu on release, and selecting Open window restores
  a withdrawn main window, dismisses the menu, and releases its Tk grab.
- ARGB pixel checks pass for 24x39, 39x24, 48x48 and 16x16 allocations.
- All nine existing X11 clipboard and hotkey tests pass.
- Actual Cinnamon 5.8.4 panel behavior, theming and final visual size require
  testing on the target desktop. Test scripts require Python-Xlib and Xvfb;
  the click test also uses a window manager such as Openbox.

Run from the source root after `make all`:

```
PYTHONPATH=. xvfb-run -a -s '-screen 0 1280x800x24' python3 tools/check-tray-argb.py
PYTHONPATH=. xvfb-run -a -s '-screen 0 1280x800x24' sh -c 'openbox & sleep .3; python3 tools/check-tray-click.py hidden'
```
