# Feature parity and source basis

**Status:** Linux preview 5, targeting the corrected ClipAngel 2.23 baseline label.
The supplied source snapshot remains `a8c60d32d05197fa01469a9e4ba6b189c180d069`;
its `Properties/AssemblyInfo.cs` says `2.22.0.0`, so the 2.23 baseline label is
user-supplied rather than established by that metadata. See LINUX3-RELEASE.md.
Supplied screenshots were used as visual references, not proof of complete
version-specific parity.

“Implemented” means code exists and the listed behavior is supported, not that every combination has been manually verified. Automated coverage is listed separately in TEST-REPORT.md.

| Area | Linux implementation | Difference / limit |
|---|---|---|
| Main layout and artwork | Classic menu/toolbar, history left, preview right, bottom filters/status, favorite/used colors; original icons | Tk widgets and font metrics differ from WinForms; not pixel-identical |
| Theme | Saved light/dark palette; immediate switching; main interface, previews and dialogs | Window-manager decorations and image pixels are not recolored; source text colors may be adjusted for dark-preview contrast only |
| Menus | Window, List, Clip, Settings, Help and context menus | Windows-only and remote-service actions are disabled or absent |
| Menu languages | Original English, German, Greek, Spanish, French, Hindi, Italian, Polish, Brazilian Portuguese, Russian and simplified-Chinese strings | Linux-only dialogs/tooltips and some new menu entries remain English |
| Text clipboard | Unicode text, plain aliases, clipboard retention while the app runs | X11 CLIPBOARD only; PRIMARY selection is not monitored |
| Rich clipboard | HTML and RTF payload retention, plain-text alternatives | Application-private Windows/OLE clipboard formats are not recreated |
| Image clipboard | PNG, JPEG, BMP, TIFF, WebP; first supported advertised image type | No Windows DIB/OLE interoperability; mixed image + text is retained as one multi-format clip rather than always split into two Windows-style rows |
| File clipboard | URI lists and GNOME copy-list payloads, multiple files | Stored references only, not file backups; replay converts old cut operations to copy to avoid moving originals |
| History | SQLite, count/age retention, favorites, used flags, duplicate replacement | Separate Linux schema; original encrypted databases cannot be opened |
| Search/filter | Unicode case folding, independent words, optional case sensitivity, percent wildcards, all fields, date/type/mark filters | Search implementation and edge cases differ; preview highlights are simplified; date filters use the stored date (new captures use UTC) |
| List/navigation | Multiple selection, select all, move up/down/top, sort, optional columns, load more | Initially renders at most 5,000 matching rows; can load more |
| Clipboard monitoring | XFixes notifications, pause, forced capture, application/URL exclusions and selected confidential hints | Source application/title detection is best-effort; URL generally available only when advertised by clipboard data |
| Paste-back | Focus-checked XTest; original format, plain text, one line, file, sequential clips | Auto: Ctrl+Shift+V for recognized terminal WM_CLASS identities, Ctrl+V otherwise; manual overrides supported. Embedded terminals and custom bindings may need an override |
| Character simulation | Fast/slow ASCII character input | Up to 10,000 characters present in the active keymap; Caps Lock must be off; Unicode uses clipboard paste instead |
| Join / Paste special | Delimiters, case conversion, tab/space/newline normalization, new clip/copy/paste | No claim of byte-for-byte parity with every Windows normalization edge case |
| Edit/rename/duplicate | Plain-text editor, title changes, duplicate and new clips | Editing rich content is plain-text conversion; “save as new” preserves the original |
| Comparison | Side-by-side line comparison and unified-diff copying | Not the original diff engine; combined input limit 500,000 characters |
| Delete/undo | Single/multiple/non-favorite deletion; last 10 deletion operations in memory | Undo is session-local; large deletions can use substantial RAM; automatic retention and clear-on-exit are not undoable |
| HTML preview | Local safe subset: basic emphasis, headings, links, lists, simple tables/colors, small embedded images | Not IE/mshtml or a browser; CSS/layout fidelity limited; scripts, remote images and local file images are not loaded |
| RTF preview | Built-in text fallback; optional local unrtf for formatted preview | Complex Word/Office layouts and embedded objects are not reproduced |
| Text preview | Wrap, monospace, simple code coloring, links, search highlight | First 250,000 characters displayed; full payload retained for paste/export; no dedicated full 1C syntax engine |
| Image preview | Fit, original size, zoom | 32-megapixel decode safety limit, 25-megapixel rendered image cap; not an image editor |
| Open/save/link | Save suitable content format, open with xdg-open or chosen application, selected web/mail links | Original Windows shell integration and editor configuration are replaced by Linux behavior |
| CAC interchange | Source-derived .NET XML table/schema import and export | Synthetic five-type round trips tested; no Windows executable was available for a live interoperability test; unsupported proprietary MIME data is omitted by CAC |
| Windows SQLite import | Read-only import from unencrypted Clips tables | Windows file paths remain references and are not remapped; DPAPI/encrypted SQLite unsupported |
| Linux interchange | JSON export/import retains stored MIME payloads and main metadata; SQLite backup | New Linux format, not read by upstream Windows ClipAngel |
| QR codes | Optional python3-qrcode local generation | Dependency not required for normal operation |
| Translation | Explicitly confirmed browser request to Google Translate | No embedded translation service; maximum 5,000 selected characters |
| Hotkeys and single instance | Configurable root-window shortcuts, conflict reporting, private local IPC, command-line actions | Native Wayland shortcut portal not implemented |
| Tray / close | XEmbed tray, monitoring toggle and menu; close-to-tray or iconify fallback | No StatusNotifierItem integration; simulated XEmbed host tested; actual desktop tray not tested |
| Autostart | Optional XDG user entry, minimized start, Window/Settings toggles and --autostart on/off/status | Off by default; installing the package never starts capture automatically; actual Mint logout/login was not tested |
| Remote channels / cloud | Not implemented | No channel pairing, synchronization, remote publishing, upload, or bundled secrets |
| Windows integrations | Not implemented | No registry/COM/mshtml/DPAPI/Windows updater, elevation bypass, Windows app activation, installer or file-association parity |
| Encryption / security | Private directories/files, no automatic uploads, no HTML script execution | History, backups and exports are unencrypted; no security audit; clipboard hints cannot guarantee password exclusion |
| Native Wayland | Not implemented | XWayland compatibility only; automatic paste disabled; native app capture/global shortcuts not guaranteed |

## Original source inspected

- `Main.cs`: clipboard acquisition, storage, paste, search, menu actions and export/import. In particular, the .cac export/import routines around lines 8132–8188 use a `ClipAngelClips` DataTable and XML schema.
- `Main.Designer.cs` and `Main*.resx`: original layout, menus, labels and translated text.
- `Properties/Settings.settings`: defaults and user-visible options; the Linux defaults largely follow the original, with explicit Linux additions.
- `PasteSpecial.cs`: casing, delimiter and whitespace transformations.
- `Properties/AssemblyInfo.cs`: original version and attribution.
- `Picture/`, `Screenshot/Text clip.png`, `Screenshot/Menu Clip.png`: artwork and visual layout references.
- The original SQLite schema was inspected; the supplied database itself is not included in this distribution.

The Windows source contains platform-specific and commented-out code. Commented-out functionality was not counted as a working feature merely because a name appeared in the source.

## Source files in this reimplementation

`clipangel/core.py`: normalization, SQLite, interchange and text transforms.
`clipangel/app.py`: main interface and capture/paste controller.
`clipangel/views.py`: icon handling and text/HTML/image previews.
`clipangel/dialogs.py`: settings, editing, paste-special and comparison dialogs.
`clipangel/x11.py` + `native/x11.c`: native desktop adapter.
`clipangel/theme.py`: light/dark palettes and classic/ttk widget styling.
`clipangel/paste_policy.py`: destination-class paste accelerator policy.
`clipangel/autostart.py`: optional per-user XDG startup entry management.
`clipangel/ipc.py` + `clipangel/__main__.py`: launch and single-instance commands.
`packaging/`: reproducible local Debian-package construction.
`tests/`: storage, X11 and GUI integration checks.
