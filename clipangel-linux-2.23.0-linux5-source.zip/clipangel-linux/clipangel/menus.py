# SPDX-License-Identifier: GPL-3.0-only
"""Tk/X11 menu lifecycle and opening-click protection.

On X11, tk_popup is non-blocking: its global grab must remain in place until
Tk's menu bindings dismiss the menu. Releasing it immediately prevents outside
clicks from dismissing the popup.

Tk may reposition a tall menu over its opening button (or a context menu over
the right-click position). The release of that same, stationary click must not
invoke the newly exposed entry. Preserve ordinary Tk mouse/keyboard traversal
and press-drag-release selection; suppress only the opening click's release.
"""
from __future__ import annotations

from dataclasses import dataclass
import tkinter as tk
from weakref import WeakSet


@dataclass(frozen=True)
class OpeningClick:
    menu: tk.Menu
    button: int
    x: int
    y: int


class Menus:
    def __init__(self, root: tk.Tk):
        self.root = root
        self._menus: WeakSet[tk.Menu] = WeakSet()
        self._opening: OpeningClick | None = None

    def create(self, parent: tk.Misc, **options) -> tk.Menu:
        menu = tk.Menu(parent, **options)
        self._menus.add(menu)
        # Widget bindings run before Tk's Menu class bindings. Do not replace
        # the class bindings: they handle outside clicks, Escape, cascades,
        # keyboard navigation, restoring focus, and releasing the global grab.
        menu.bind('<ButtonPress>', self._new_press, add='+')
        menu.bind('<ButtonRelease>', self._release, add='+')
        menu.bind('<Unmap>', self._unmapped, add='+')
        return menu

    def attach(self, button: tk.Menubutton, menu: tk.Menu) -> None:
        """Protect a standard menubutton without changing its Tk behavior."""
        button.configure(menu=menu)
        if not getattr(button, '_clipangel_opening_guard', False):
            # This button can survive a settings-driven menu rebuild. Resolve
            # its current menu when clicked, and install bindings only once.
            button.bind('<ButtonPress-1>', lambda e: self._button_press(
                self.root.nametowidget(button.cget('menu')), e), add='+')
            button.bind('<ButtonRelease-1>', self._new_press, add='+')
            button._clipangel_opening_guard = True

    def _button_press(self, menu: tk.Menu, event: tk.Event) -> None:
        self._opening = None
        # When another menu has a grab, this widget may receive clicks from
        # outside its bounds. Those clicks dismiss, rather than open, its menu.
        w = event.widget
        inside = (w.winfo_rootx() <= event.x_root < w.winfo_rootx() + w.winfo_width()
                  and w.winfo_rooty() <= event.y_root < w.winfo_rooty() + w.winfo_height())
        if inside and not menu.winfo_ismapped():
            self._opening = OpeningClick(menu, 1, event.x_root, event.y_root)

    def _new_press(self, _event=None) -> None:
        self._opening = None

    def _release(self, event: tk.Event) -> str | None:
        opening, self._opening = self._opening, None
        if opening is None or event.num != opening.button:
            return None
        path = str(event.widget)
        belongs = path == str(opening.menu) or path.startswith(str(opening.menu) + '.')
        if belongs and abs(event.x_root - opening.x) <= 5 and abs(event.y_root - opening.y) <= 5:
            # A click can jitter a few pixels. It is still an opening click,
            # not a deliberate selection, even if Tk moved the menu under it.
            opening.menu.tk.call(str(opening.menu), 'postcascade', 'none')
            opening.menu.activate('none')
            return 'break'
        return None

    def _unmapped(self, event: tk.Event) -> None:
        if self._opening is not None and str(event.widget) == str(self._opening.menu):
            self._opening = None

    def popup(self, menu: tk.Menu, x: int, y: int, button: int | None = 3) -> None:
        self.dismiss()
        self._opening = OpeningClick(menu, button, x, y) if button is not None else None
        try:
            menu.tk_popup(x, y)
        except tk.TclError:
            # Do not leave a partially posted menu or a grab after an error.
            self.dismiss()
            raise
        # No grab_release here! tk_popup returns while the menu is still open.

    def dismiss(self) -> None:
        """Dismiss our menu chain before hiding/rebuilding, not a modal dialog."""
        self._opening = None
        posted = [m for m in self._menus if m.winfo_exists() and m.winfo_ismapped()]
        if not posted:
            return
        # Use Tk's own unposting routine, as its Escape/outside-click bindings
        # do; raw .unpost() alone does not restore focus/grab bookkeeping.
        self.root.tk.call('tk::MenuUnpost', str(posted[0]))
