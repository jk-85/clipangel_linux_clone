# SPDX-License-Identifier: GPL-3.0-only
"""ClipAngel's classic two-pane desktop interface and clipboard controller."""
from __future__ import annotations
import fnmatch
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog, font as tkfont
from datetime import datetime
from urllib.parse import unquote, urlparse, urlencode
import webbrowser
from PIL import Image, ImageTk
from .pillow_compat import Resampling

from . import __version__, UPSTREAM_VERSION
from . import autostart
from .paste_policy import paste_key
from .theme import Theme
from .menus import Menus
from .core import Store, Settings, DEFAULTS, atomic_write, private_dir, decode_text, file_urls, delimiter, timestamp
from .x11 import X11
from .views import Icons, Preview, Tooltip, ASSETS
from .dialogs import SettingsDialog, TextEditor, PasteSpecial, compare_dialog, date_dialog, text_dialog, window

HOTKEYS = {
    1: "GlobalHotkeyOpenLast", 2: "GlobalHotkeyOpenFavorites", 3: "GlobalHotkeyPasteText",
    4: "GlobalHotkeySwitchMonitoring", 5: "GlobalHotkeyIncrementalPaste", 6: "GlobalHotkeyDecrementalPaste",
    7: "GlobalHotkeyCompareLastClips", 8: "GlobalHotkeyForcedCapture",
}
SUPPORTED = ["text/plain;charset=utf-8", "text/plain;charset=UTF-8", "UTF8_STRING", "text/plain", "TEXT", "STRING"]
MARKS = [("all marks", "all"), ("favorite", "favorite"), ("used", "used"), ("unused", "unused")]
TYPES = [("all types", "all"), ("all texts", "texts"), ("plain text", "text"), ("HTML", "html"),
         ("RTF", "rtf"), ("image", "img"), ("file", "file")]


def human_size(size: int) -> str:
    if size >= 1024 * 1024:
        return f"{size / (1024*1024):.1f} MiB"
    if size >= 1024:
        return f"{size / 1024:.1f} KiB"
    return f"{size} B"


class Application:
    def __init__(self, root: tk.Tk, store: Store, settings: Settings, instance=None):
        self.root, self.store, self.settings, self.instance = root, store, settings, instance
        self.running = True
        self.x11: X11 | None = None
        self.backend_error = ""
        self.last_target = 0
        self.last_target_app = self.last_target_title = ""
        self.rows: list[dict] = []
        self.row_map: dict[int, dict] = {}
        self.visible_limit = 5000
        self.filtered_count = 0
        self.selected_id = None
        self.previous_before_filter = None
        self.start_date = self.end_date = ""
        self.filter_after = None
        self.preview_after = None
        self.message_after = None
        self._reloading = False
        self._generation = 0
        self._token = 0
        self._requests: dict[int, tuple[int, str]] = {}
        self._capture_pending: set[str] = set()
        self._capture_data: dict[str, bytes] = {}
        self._capture_meta: dict[str, str] = {}
        self._current_formats: dict[str, bytes] | None = None
        self._capture_forced = False
        self._sequence_ids: list[int] = []
        self._sequence_pos = -1
        self._captured = 0
        self._active_tick = 0.
        self._last_prune = 0.
        self._hotkeys_ok = False
        self._paste_job = 0
        self._toolbar = []
        self._temp_files = []
        # Read the actual startup entry, including changes made by Mint's
        # Startup Applications tool. Never enable startup merely by launching.
        self.settings["Autostart"] = autostart.is_enabled()
        self._load_locale()
        self.root.title(f"ClipAngel {UPSTREAM_VERSION} — Linux preview 5")
        self.root.minsize(740, 410)
        geometry = settings["WindowGeometry"]
        try:
            self.root.geometry(geometry)
        except tk.TclError:
            self.root.geometry("980x600")
        self.theme = Theme(root)
        self._style()
        self.icons = Icons(root)
        root.iconphoto(True, self.icons.get("Alien-64x64.png", 64))
        self.vars = {key: tk.BooleanVar(root, settings[key]) for key, value in DEFAULTS.items() if type(value) is bool}
        self.search_var = tk.StringVar(root)
        self.mark_var = tk.StringVar(root, MARKS[0][0])
        self.type_var = tk.StringVar(root, TYPES[0][0])
        self.sort_var = tk.StringVar(root, "default")
        self.url_var = tk.StringVar(root)
        self.app_var = tk.StringVar(root)
        self.window_var = tk.StringVar(root)
        self.menus = Menus(root)
        self._build_ui()
        self._build_menus()
        self.theme.walk(self.root)
        self._bind_keys()
        self.root.protocol("WM_DELETE_WINDOW", self.close_window)
        self.root.report_callback_exception = self._callback_error
        self.root.attributes("-topmost", settings["AlwaysOnTop"])
        self.root.update_idletasks()
        self.root.after(80, lambda: self._restore_splitter())
        try:
            self.x11 = X11(self._xevent)
            self._register_hotkeys()
            self._set_tray_icon()
            if not self.x11.lib.ca_has_xfixes(self.x11.ctx):
                self.backend_error = "XFixes is unavailable. Automatic clipboard capture cannot run."
        except (RuntimeError, OSError) as exc:
            self.backend_error = str(exc)
        self.refresh()
        self._sync_toolbar()
        self.root.after(30, self._poll)
        self.root.after(300, lambda: self.capture_current() if self.settings["MonitoringClipboard"] else None)
        if self.backend_error:
            self.root.after(350, lambda: self.notify(self.backend_error, error=True, duration=20000))
        elif self.x11 and self.x11.wayland:
            self.root.after(350, lambda: self.notify("Wayland compatibility mode: automatic paste is disabled; use a desktop shortcut for clipangel --show.", duration=20000))
        elif settings.warning:
            self.root.after(350, lambda: self.notify(settings.warning, error=True, duration=20000))

    def _load_locale(self):
        path = Path(__file__).with_name("locales") / (self.settings["Language"] + ".json")
        try:
            self.labels = json.loads(path.read_text("utf-8"))
        except (ValueError, OSError):
            self.labels = {}

    def t(self, key: str, fallback: str) -> str:
        return self.labels.get(key, fallback).replace("&", "")

    def _style(self):
        self.theme.apply(self.settings["DarkTheme"], self.settings["FontSize"])
        if hasattr(self, "message_label"):
            self.message_label.configure(foreground=self.theme.palette["fg"])

    def _build_ui(self):
        self.top = tk.Frame(self.root, background=self.theme.palette["bg"], height=29)
        self.top.pack(fill="x")
        self.menu_frame = tk.Frame(self.top, background=self.theme.palette["bg"])
        self.menu_frame.pack(side="left")
        self.toolbar_frame = tk.Frame(self.top, background=self.theme.palette["bg"])
        self.toolbar_frame.pack(side="right", padx=4)
        tools = [
            ("TextFormatting.png", "Native formatting", lambda: self.toggle("ShowNativeTextFormatting"), "ShowNativeTextFormatting"),
            ("word wrap.png", "Word wrap (Ctrl+W)", lambda: self.toggle("WordWrap"), "WordWrap"),
            ("FixedWidthFont.png", "Monospaced font", lambda: self.toggle("MonospacedFont"), "MonospacedFont"),
            ("MoveCopiedClipToTop.png", "Move to top after use", lambda: self.toggle("MoveCopiedClipToTop"), "MoveCopiedClipToTop"),
            ("Top1.png", "Move to top", lambda: self.move("top"), None),
            ("Set favorite.png", "Mark as favorite (Alt+Q)", lambda: self.favorite(True), None),
            ("Edit.png", "Edit clip text (F4)", self.edit_text, None),
            ("OpenFile.png", "Open clip file (Ctrl+F4)", self.open_file, None),
            ("Columns.png", "Secondary columns", lambda: self.toggle("ShowSecondaryColumns"), "ShowSecondaryColumns"),
            ("TopMostWindow.png", "Window always on top", lambda: self.toggle("AlwaysOnTop"), "AlwaysOnTop"),
        ]
        for name, tooltip, command, key in tools:
            button = tk.Button(self.toolbar_frame, image=self.icons.get(name), relief="flat", borderwidth=1,
                               background=self.theme.palette["bg"], activebackground=self.theme.palette["hover"], padx=3, pady=3, command=command, takefocus=False)
            button.pack(side="left"); Tooltip(button, tooltip)
            button._theme_pressed = lambda k=key: bool(k and self.settings[k])
            self._toolbar.append((button, key))
        self.panes = tk.PanedWindow(self.root, orient="horizontal", sashwidth=5, sashrelief="flat", background=self.theme.palette["bg"], borderwidth=0, showhandle=False)
        self.panes.pack(fill="both", expand=True, padx=3)
        self.left = ttk.Frame(self.panes)
        self.right = ttk.Frame(self.panes)
        self.panes.add(self.left, minsize=260, width=self.settings["SplitterPosition"])
        self.panes.add(self.right, minsize=260)
        self.left.rowconfigure(0, weight=1); self.left.columnconfigure(0, weight=1)
        self.tree = ttk.Treeview(self.left, columns=("chars", "type", "app", "created"), show="tree", selectmode="extended", takefocus=True)
        self.tree.grid(row=0, column=0, sticky="nsew")
        self.tree.column("#0", width=340, minwidth=120, stretch=True)
        self.tree.heading("#0", text="Clip")
        for name, text, width in (("chars", "Chars", 50), ("type", "Type", 55), ("app", "Application", 130), ("created", "Created", 150)):
            self.tree.column(name, width=width, minwidth=35, stretch=False); self.tree.heading(name, text=text)
        self.tree.configure(displaycolumns=("chars",))
        self.tree.tag_configure("favorite", background=self.theme.palette["favorite"])
        self.tree.tag_configure("used", background=self.theme.palette["used"])
        self.tree.tag_configure("matched", background=self.theme.palette["matched"])
        self.tree_scroll = ttk.Scrollbar(self.left, orient="vertical", command=self.tree.yview)
        self.tree_scroll.grid(row=0, column=1, sticky="ns"); self.tree.configure(yscrollcommand=self.tree_scroll.set)
        filters = ttk.Frame(self.left); filters.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(2, 0))
        self.mark_combo = ttk.Combobox(filters, textvariable=self.mark_var, values=[x[0] for x in MARKS], state="readonly", width=9)
        self.mark_combo.pack(side="left", padx=(0, 2))
        self.type_combo = ttk.Combobox(filters, textvariable=self.type_var, values=[x[0] for x in TYPES], state="readonly", width=9)
        self.type_combo.pack(side="left", padx=(0, 2))
        self.search = ttk.Combobox(filters, textvariable=self.search_var, values=self.settings["LastFilterValues"], width=12)
        self.search.pack(side="left", fill="x", expand=True)
        Tooltip(self.search, 'Search clipboard history (Ctrl+F). Use % as a wildcard; separate words match independently.')
        for icon, text, command in [("FindPrevious.png", "Previous match (Shift+F3)", lambda: self.find(-1)),
                                    ("FindNext.png", "Next match (F3)", lambda: self.find(1)),
                                    ("ClearFilter.png", "Clear filters (Ctrl+L)", self.clear_filters)]:
            button = tk.Button(filters, image=self.icons.get(icon), command=command, relief="flat", background=self.theme.palette["bg"], padx=1, pady=1, takefocus=False)
            button.pack(side="left"); Tooltip(button, text)
        self.search_options_button = tk.Menubutton(filters, text="⋮", relief="flat", background=self.theme.palette["bg"], padx=3, takefocus=False)
        self.search_options_button.pack(side="left")
        self.mark_combo.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        self.type_combo.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        self.search_var.trace_add("write", self._search_changed)
        self.tree.bind("<<TreeviewSelect>>", self._selection_changed)
        self.tree.bind("<Double-Button-1>", self._double_click_clip)
        self.tree.bind("<Button-3>", self._context_menu)
        self.tree.bind("<Tab>", lambda e: self.focus_preview())
        self.tree.bind("<Control-a>", self.select_all)
        self.right.columnconfigure(0, weight=1); self.right.rowconfigure(2, weight=1)
        metadata = ttk.Frame(self.right); metadata.grid(row=0, column=0, sticky="ew", pady=(0, 3))
        self.url_entry = ttk.Entry(metadata, textvariable=self.url_var, state="readonly")
        self.url_entry.pack(side="left", fill="x", expand=True, padx=(0, 3))
        self.url_entry.bind("<Alt-Button-1>", lambda e: self.open_link(self.url_var.get()))
        Tooltip(self.url_entry, "Source URL. Alt+click to open.")
        self.app_entry = ttk.Entry(metadata, textvariable=self.app_var, state="readonly", width=16)
        self.app_entry.pack(side="left"); Tooltip(self.app_entry, "Source application")
        self.window_entry = ttk.Entry(self.right, textvariable=self.window_var, state="readonly")
        self.window_entry.grid(row=1, column=0, sticky="ew", pady=(0, 3))
        Tooltip(self.window_entry, "Source window title")
        self.preview = Preview(self.right, self.open_link)
        self.preview.grid(row=2, column=0, sticky="nsew")
        self.preview.text.bind("<Tab>", lambda e: self.focus_list())
        self.preview.text.bind("<Button-3>", self._preview_context)
        self.preview.canvas.bind("<Button-3>", self._image_context)
        self.status = ttk.Frame(self.root); self.status.pack(fill="x", padx=2, pady=(1, 0))
        self.status_vars = [tk.StringVar(self.root, "") for _ in range(7)]
        for variable in self.status_vars:
            ttk.Label(self.status, textvariable=variable, style="Status.TLabel").pack(side="left")
            ttk.Separator(self.status, orient="vertical").pack(side="left", fill="y", pady=3)
        self.message_var = tk.StringVar(self.root)
        self.message_label = ttk.Label(self.status, textvariable=self.message_var, style="Status.TLabel")
        self.message_label.pack(side="left", fill="x", expand=True)
        self.capture_label = ttk.Label(self.status, style="Status.TLabel")
        self.capture_label.pack(side="right")

    def _double_click_clip(self, event):
        # Ignore headings/empty space instead of pasting an old selection.
        row = self.tree.identify_row(event.y)
        if row and self.tree.identify_region(event.x, event.y) in ("tree", "cell"):
            if row not in self.tree.selection():
                self.tree.selection_set(row)
            self.tree.focus(row)
            self.paste()
        return "break"

    def _restore_splitter(self):
        # A hidden login-started window has no usable pane geometry yet.
        if not self.root.winfo_viewable() or self.root.winfo_width() < 740:
            return
        try:
            width = min(self.root.winfo_width()-280, max(260, self.settings["SplitterPosition"]))
            self.panes.sash_place(0, width, 0)
        except tk.TclError:
            pass

    def _menu(self, title: str) -> tk.Menu:
        button = tk.Menubutton(self.menu_frame, text=title, relief="flat", background=self.theme.palette["bg"], activebackground=self.theme.palette["hover"], padx=8, pady=4)
        button.pack(side="left")
        menu = self.menus.create(button, tearoff=False)
        self.menus.attach(button, menu)
        return menu

    def _add(self, menu, label, command, key="", accelerator="", icon=None, disabled=False):
        options = {"label": self.t(key, label) if key else label, "command": command, "accelerator": accelerator}
        if icon:
            options.update(image=self.icons.get(icon), compound="left")
        if disabled:
            options["state"] = "disabled"
        menu.add_command(**options)

    def _check(self, menu, label, setting, key="", accelerator=""):
        menu.add_checkbutton(label=self.t(key, label) if key else label, variable=self.vars[setting],
                             command=lambda: self.toggle(setting, self.vars[setting].get()), accelerator=accelerator)

    def _build_menus(self):
        self.menus.dismiss()
        for name in ("context", "tray_menu", "search_options_menu", "preview_context", "image_context"):
            old = getattr(self, name, None)
            if old is not None:
                old.destroy()
        for widget in self.menu_frame.winfo_children():
            widget.destroy()
        win = self._menu(self.t("fileToolStripMenuItem1", "Window"))
        self._add(win, "Switch focus list/text", self.switch_focus, "toolStripMenuItemSwitchFocus", "Tab")
        self._add(win, "Set focus to clip text", self.focus_preview, "menuItemSetFocusClipText")
        win.add_separator()
        self._check(win, "Always on top", "AlwaysOnTop", "windowAlwaysOnTopToolStripMenuItem")
        self._check(win, "Monitoring clipboard", "MonitoringClipboard", "toolStripMenuItemMonitoringClipboard")
        self._check(win, "Dark theme", "DarkTheme")
        self._check(win, "Start at login (minimized)", "Autostart")
        self._add(win, "Capture current clipboard", self.capture_current)
        self._add(win, "Clear clipboard", self.clear_clipboard, "сдуфкClipboardToolStripMenuItem")
        self._add(win, "Connect clip channel (not ported)", lambda: None, disabled=True)
        win.add_separator(); self._add(win, "Exit", self.quit, "exitToolStripMenuItem", "Ctrl+Q")
        lst = self._menu(self.t("listToolStripMenuItem", "List"))
        self._check(lst, "Secondary columns", "ShowSecondaryColumns", "toolStripMenuItemSecondaryColumns")
        self._check(lst, "Move to top after use", "MoveCopiedClipToTop", "moveCopiedClipToTopToolStripMenuItem")
        for label, direction, key, icon in [("Move to top", "top", "moveTopToolStripMenuItem", "Top1.png"),
                                            ("Move up", "up", "moveUpToolStripMenuItem", "up.png"),
                                            ("Move down", "down", "moveDownToolStripMenuItem", "down.png")]:
            self._add(lst, label, lambda d=direction: self.move(d), key, icon=icon)
        lst.add_separator()
        self._add(lst, "Filter by date", self.filter_date, "filterByDateToolStripMenuItem", icon="calendar.png")
        sort = self.menus.create(lst, tearoff=False)
        for label, value in [("Sort by default", "default"), ("Sort by visual size", "chars"), ("Sort by byte size", "size"), ("Sort by creation date", "created")]:
            sort.add_radiobutton(label=label, variable=self.sort_var, value=value, command=self.refresh)
        lst.add_cascade(label=self.t("sortingToolStripMenuItem", "Sort"), menu=sort)
        self._add(lst, "Delete all non favorite", self.delete_nonfavorites, "deleteAllNonFavoriteToolStripMenuItem")
        lst.add_separator()
        for label, mark, key in [("Show all marks", "all", "showAllMarksToolStripMenuItem"), ("Show only favorite", "favorite", "showOnlyFavoriteToolStripMenuItem"), ("Show only used", "used", "showOnlyUsedToolStripMenuItem")]:
            self._add(lst, label, lambda v=mark: self.set_filter(mark=v), key)
        for label, kind, key in [("Show all types", "all", "showAllTypesToolStripMenuItem"), ("Show only images", "img", "showOnlyImagesToolStripMenuItem"),
                                  ("Show only files", "file", "showOnlyFilesToolStripMenuItem"), ("Show only texts", "texts", "showOnlyTextsToolStripMenuItem")]:
            self._add(lst, label, lambda v=kind: self.set_filter(kind=v), key)
        lst.add_separator()
        self._add(lst, "Clear filters", self.clear_filters, "toolStripMenuItemClearFilters", "Ctrl+L")
        self._add(lst, "Clear filters and select previous", self.clear_and_previous, "returnToPrevousSelectedClipToolStripMenuItem")
        self._add(lst, "Clear filters and select top", lambda: self.clear_filters(top=True), "toolStripMenuItemClearFilterAndSelectTop")
        self._add(lst, "Select top", self.select_top, accelerator="Ctrl+Home")
        self._add(lst, "Load more clips", self.load_more)
        clip = self._menu(self.t("clipToolStripMenuItem", "Clip"))
        paste = self.menus.create(clip, tearoff=False)
        self._paste_entries(paste)
        clip.add_cascade(label=self.t("pasteToolStripMenuItem", "Paste"), menu=paste)
        self._add(clip, "Copy to clipboard", self.copy_selected, "copyToClipboardToolStripMenuItem", "Ctrl+C", "copy.png")
        self._add(clip, "Delete", self.delete_selected, accelerator="Del", icon="delete.png")
        self._add(clip, "Undo deletion", self.undo_delete, accelerator="Ctrl+Z")
        self._add(clip, "New text clip", self.new_clip, accelerator="Ctrl+N")
        self._add(clip, "Edit title", self.edit_title, "changeClipTitleToolStripMenuItem", "F2")
        clip.add_separator()
        self._add(clip, "Find next", lambda: self.find(1), "NextMatchTextMenuItem", "F3", "FindNext.png")
        self._add(clip, "Find previous", lambda: self.find(-1), "PreviousMatchTextMenuItem", "Shift+F3", "FindPrevious.png")
        self._check(clip, "Native formatting", "ShowNativeTextFormatting", "textFormattingToolStripMenuItem")
        self._check(clip, "Word wrap", "WordWrap", "wordWrapToolStripMenuItem", "Ctrl+W")
        self._check(clip, "Monospaced font", "MonospacedFont", "monospacedFontToolStripMenuItem")
        clip.add_separator()
        self._add(clip, "Mark as favorite", lambda: self.favorite(True), "setFavouriteToolStripMenuItem", "Alt+Q", "Set favorite.png")
        self._add(clip, "Unmark as favorite", lambda: self.favorite(False), "resetFavouriteToolStripMenuItem", "Alt+W", "Reset favorite.png")
        self._add(clip, "Edit text", self.edit_text, "editClipTextToolStripMenuItem", "F4", "Edit.png")
        self._add(clip, "Open file", self.open_file, "toolStripMenuItem16", "Ctrl+F4", "OpenFile.png")
        self._add(clip, "Open file with...", self.open_with, "openWithToolStripMenuItem")
        self._add(clip, "Save as file...", self.save_as, "saveAsFileMenuItem")
        self._add(clip, "Join text of clips", self.join_clips, "mergeTextOfClipsToolStripMenuItem", icon="merge.png")
        self._add(clip, "Duplicate text clip", self.duplicate, "duplicateTextClipToolStripMenuItem", icon="Dublicate.png")
        self._add(clip, "Text compare", self.compare, "textCompareToolStripMenuItem", icon="Compare.png")
        self._add(clip, "Decode URL", self.decode_url, "decodeTextToolStripMenuItem")
        self._add(clip, "QR code", self.qr_code)
        self._add(clip, "Translate text...", self.translate, "translateToolStripMenuItem")
        self._add(clip, "Upload image to web (not ported)", lambda: None, disabled=True)
        self._add(clip, "Send clip to channel (not ported)", lambda: None, disabled=True)
        self._add(clip, "Ignore application", self.ignore_application, "ignoreApplicationInCaptureToolStripMenuItem")
        clip.add_separator()
        self._add(clip, "Export clips", self.export_clips, "exportMenuItem", "Ctrl+E")
        self._add(clip, "Import clips", self.import_clips, "importToolStripMenuItem", "Ctrl+I")
        settings_button = tk.Button(self.menu_frame, text=self.t("settingsToolStripMenuItem1", "Settings"), command=self.show_settings,
                                    relief="flat", borderwidth=0, padx=8, pady=4, background=self.theme.palette["bg"], activebackground=self.theme.palette["hover"])
        settings_button.pack(side="left")
        help_menu = self._menu(self.t("fToolStripMenuItem", "Help"))
        self._add(help_menu, "Help", self.help, "helpToolStripMenuItem", "F1")
        self._add(help_menu, "History of changes", self.changes, "historyToolStripMenuItem")
        self._add(help_menu, "Check update", self.update_info, "checkUpdateToolStripMenuItem")
        self._add(help_menu, "Diagnostics", self.diagnostics)
        self._add(help_menu, "About", self.about, "aboutToolStripMenuItem1")
        self.context = self.menus.create(self.root, tearoff=False)
        self._paste_entries(self.context)
        self.context.add_separator()
        for label, cmd, accelerator, icon in [("Copy to clipboard", self.copy_selected, "Ctrl+C", "copy.png"),
                                               ("Edit title", self.edit_title, "F2", None), ("Edit text", self.edit_text, "F4", "Edit.png"),
                                               ("Mark as favorite", lambda: self.favorite(True), "Alt+Q", "Set favorite.png"),
                                               ("Unmark as favorite", lambda: self.favorite(False), "Alt+W", "Reset favorite.png"),
                                               ("Open file", self.open_file, "Ctrl+F4", "OpenFile.png"),
                                               ("Text compare", self.compare, "", "Compare.png"),
                                               ("Export clips", self.export_clips, "", None), ("Delete", self.delete_selected, "Del", "delete.png")]:
            self._add(self.context, label, cmd, accelerator=accelerator, icon=icon)
        search_options = self.search_options_menu = self.menus.create(self.search_options_button, tearoff=False)
        for key, label in [("SearchCaseSensitive", "Case sensitive"), ("SearchWordsIndependently", "Independent words"),
                           ("SearchWildcards", '"%" as any character sequence'), ("SearchAllFields", "Search all fields"),
                           ("SearchIgnoreBigTexts", "Ignore big texts"), ("FilterListBySearchString", "Filter list by search string")]:
            self._check(search_options, label, key)
        self.menus.attach(self.search_options_button, search_options)
        self.tray_menu = self.menus.create(self.root, tearoff=False)
        self._add(self.tray_menu, "Open window", self.show)
        self._add(self.tray_menu, "Open favorite clips", lambda: self.show(favorites=True))
        self._add(self.tray_menu, "Compare last clips", lambda: self.compare(last=True))
        self.tray_menu.add_separator()
        self._check(self.tray_menu, "Monitoring clipboard", "MonitoringClipboard")
        self._add(self.tray_menu, "Clear clipboard", self.clear_clipboard)
        self._add(self.tray_menu, "Settings", self.show_settings)
        self._add(self.tray_menu, "Exit", self.quit)

        # Reuse these menus instead of allocating another Tk menu on every click.
        self.preview_context = self.menus.create(self.root, tearoff=False)
        self.preview_context.add_command(label="Copy", command=self._copy_preview)
        self.preview_context.add_command(label="Select all", command=self.preview.select_all)
        self.preview_context.add_command(label="Paste selected text", command=lambda: self.paste("text"))
        self.preview_context.add_separator()
        self.preview_context.add_command(label="Set selected text in filter", command=lambda: self.search_var.set(self.preview.selected_text()))
        self.preview_context.add_command(label="Add selected text to filter", command=lambda: self.search_var.set((self.search_var.get()+" "+self.preview.selected_text()).strip()))
        self.image_context = self.menus.create(self.root, tearoff=False)
        self.image_context.add_command(label="Original size", command=self.preview.image_original)
        self.image_context.add_command(label="Fit from inside", command=self.preview.image_fit)
        self.image_context.add_command(label="Zoom in", command=lambda: self.preview.zoom(1.2))
        self.image_context.add_command(label="Zoom out", command=lambda: self.preview.zoom(1/1.2))
        self.image_context.add_command(label="Copy image", command=self.copy_selected)
        self.image_context.add_command(label="Save as file...", command=self.save_as)

    def _paste_entries(self, menu):
        self._add(menu, "Paste", self.paste, accelerator="Enter", icon="Paste.png")
        self._add(menu, "Paste text", lambda: self.paste("text"), accelerator="Ctrl+Enter", icon="Paste.png")
        self._add(menu, "Paste line", lambda: self.paste("line"), accelerator="Ctrl+Shift+Enter")
        self._add(menu, "Paste file", lambda: self.paste("file"))
        self._add(menu, "Paste special...", self.paste_special)
        self._add(menu, "Simulate fast char input", lambda: self.paste("fast"))
        self._add(menu, "Simulate slow char input", lambda: self.paste("slow"))

    def _bind_keys(self):
        bindings = {
            "<Return>": self.paste, "<Control-Return>": lambda: self.paste("text"),
            "<Control-Shift-Return>": lambda: self.paste("line"), "<Escape>": self.hide,
            "<F2>": self.edit_title, "<F3>": lambda: self.find(1), "<Shift-F3>": lambda: self.find(-1),
            "<F4>": self.edit_text, "<Control-F4>": self.open_file, "<F1>": self.help,
            "<Control-f>": self.focus_search, "<Control-l>": self.clear_filters,
            "<Control-w>": lambda: self.toggle("WordWrap"), "<Alt-q>": lambda: self.favorite(True),
            "<Alt-w>": lambda: self.favorite(False), "<Control-n>": self.new_clip,
            "<Control-e>": self.export_clips, "<Control-i>": self.import_clips,
            "<Control-q>": self.quit, "<Control-Home>": self.select_top,
        }
        for key, action in bindings.items():
            self.root.bind(key, lambda e, fn=action: (fn(), "break")[1])
        self.tree.bind("<Delete>", lambda e: (self.delete_selected(), "break")[1])
        self.tree.bind("<Control-z>", lambda e: (self.undo_delete(), "break")[1])
        self.tree.bind("<Control-c>", lambda e: (self.copy_selected(), "break")[1])
        self.preview.text.bind("<Control-c>", self._copy_preview)

    def selected(self) -> list[int]:
        selected = set(self.tree.selection())
        return [int(item) for item in self.tree.get_children() if item in selected]

    def current(self, with_data=False) -> dict | None:
        ids = self.selected()
        ident = int(self.tree.focus()) if self.tree.focus() in {str(i) for i in ids} else ids[0] if ids else None
        return self.store.get(ident, with_data) if ident is not None else None

    def _search_changed(self, *_):
        if self.filter_after:
            self.root.after_cancel(self.filter_after)
        if self.previous_before_filter is None:
            self.previous_before_filter = self.selected_id
        self.filter_after = self.root.after(170, self.refresh)

    def refresh(self, select: int | None = None):
        if not self.running:
            return
        self.filter_after = None
        ids = self.selected()
        if select is not None:
            ids = [select]
        mark = dict(MARKS).get(self.mark_var.get(), "all")
        kind = dict(TYPES).get(self.type_var.get(), "all")
        query = self.search_var.get() if self.settings["FilterListBySearchString"] else ""
        rows, count = self.store.query(query, kind, mark, self.settings, self.start_date, self.end_date, self.sort_var.get(), self.visible_limit)
        self.rows, self.filtered_count = rows, count
        self.row_map = {r["id"]: r for r in rows}
        self._reloading = True
        self.tree.delete(*self.tree.get_children())
        for row in rows:
            tags = ["favorite"] if row["favorite"] else ["used"] if row["used"] else []
            created = self._date_label(row["created"])
            self.tree.insert("", "end", iid=str(row["id"]), text=row["title"].replace("\n", " ").replace("\t", " "),
                             image=self.icons.type_icon(row["kind"]), values=(row["chars"] if row["kind"] != "img" else row["dimensions"], row["kind"], row["app"], created), tags=tags)
        chosen = [str(i) for i in ids if i in self.row_map]
        if not chosen and rows:
            chosen = [str(rows[0]["id"])]
        if chosen:
            self.tree.selection_set(chosen); self.tree.focus(chosen[0]); self.tree.see(chosen[0])
        self._reloading = False
        self._update_preview()
        self._status()

    @staticmethod
    def _date_label(value: str) -> str:
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone().strftime("%d.%m.%Y %H:%M:%S")
        except ValueError:
            return value[:19]

    def _selection_changed(self, _event=None):
        if self._reloading:
            return
        if self.preview_after:
            self.root.after_cancel(self.preview_after)
        self.preview_after = self.root.after(35, self._update_preview)

    def _update_preview(self):
        self.preview_after = None
        row = self.current()
        if not row:
            self.selected_id = None
            self.url_var.set(""); self.app_var.set(""); self.window_var.set("")
            if self.store.count():
                text = "No clips match the current filters.\n\nClear the search or choose List → Clear filters."
            else:
                text = ("Clipboard history is empty.\n\nCopy text, formatted text, an image or files in another application.\n"
                        "ClipAngel will capture it here.\n\nAlt+V  Open history\nAlt+B  Open favorites\nEnter  Paste to the previous application\n"
                        "Ctrl+Enter  Paste as plain text\nCtrl+F  Search\nF4  Edit text\nAlt+Q  Mark as favorite\n\n"
                        "Import a Windows .cac export or unencrypted SQLite database\nfrom Clip → Import clips.\n\n"
                        "Clipboard history is stored locally, without encryption.\nPause monitoring before copying sensitive information.")
            self.preview.show_empty(text)
        else:
            self.selected_id = row["id"]
            self.url_var.set(row["url"]); self.app_var.set(row["app"]); self.window_var.set(row["window"])
            self.preview.show(row, self.store.formats(row["id"]), self.settings)
            self.preview.search(self.search_var.get(), self.settings["SearchCaseSensitive"])
        self._status()

    def _status(self):
        row = self.current()
        total = self.store.count()
        self.status_vars[0].set(f"{self.filtered_count} / {total}")
        position = next((i+1 for i, r in enumerate(self.rows) if row and r["id"] == row["id"]), 0)
        self.status_vars[1].set(f"{position} ({len(self.selected())})")
        self.status_vars[2].set((row["dimensions"] or f'{row["chars"]:,} C') if row else "")
        self.status_vars[3].set(human_size(row["size"]) if row else "")
        self.status_vars[4].set(row["kind"] if row else "")
        self.status_vars[5].set(self._date_label(row["created"]) if row else "")
        self.status_vars[6].set("Date filter" if self.start_date or self.end_date else "")
        monitoring = self.settings["MonitoringClipboard"] and self.x11 is not None and not self.backend_error
        self.capture_label.configure(text="● Capturing" if monitoring else "● Paused", foreground=self.theme.palette["success" if monitoring else "warning"])
        if self.filtered_count > len(self.rows) and not self.message_var.get():
            self.message_var.set(f"Showing {len(self.rows)}; List → Load more")

    def notify(self, text: str, error: bool = False, duration: int = 7000):
        self.message_var.set(text)
        self.message_label.configure(foreground=self.theme.palette["error" if error else "fg"])
        if self.message_after:
            self.root.after_cancel(self.message_after)
        self.message_after = self.root.after(duration, lambda: self.message_var.set(""))

    def _callback_error(self, exc_type, exc, tb):
        import traceback
        traceback.print_exception(exc_type, exc, tb)
        self.notify(f"{exc_type.__name__}: {exc}", error=True, duration=15000)

    def _poll(self):
        if not self.running:
            return
        try:
            if self.x11:
                self.x11.poll()
                if time.monotonic() - self._active_tick > .25:
                    self._active_tick = time.monotonic()
                    self._remember_target()
            if self.instance:
                for command in self.instance.commands():
                    self.handle_command(command)
                    if not self.running:
                        return
            if time.monotonic() - self._last_prune > 300:
                self._last_prune = time.monotonic(); self.store.prune(self.settings)
        except Exception as exc:
            self.notify(f"Clipboard service: {exc}", error=True)
        if self.running:
            self.root.after(25, self._poll)

    def _remember_target(self):
        if not self.x11:
            return
        if self.root.grab_current() is not None:
            return
        ident, app, title = self.x11.active()
        if ident and app.casefold() not in {"clipangel", "desktop", "xfdesktop", "gnome-shell"} and "— ClipAngel" not in title:
            self.last_target, self.last_target_app, self.last_target_title = ident, app, title

    def _xevent(self, event: int, token: int, data: bytes):
        if not self.running:
            return
        if event == 1:
            if token:
                self._start_capture(token)
            elif self._current_formats:
                self.root.after(70, self._restore_clipboard)
        elif event in (2, 3):
            request = self._requests.pop(token, None)
            if not request:
                return
            generation, name = request
            if generation != self._generation:
                return
            if name == "TARGETS":
                if event == 2:
                    self._targets(data.decode("utf-8", "replace").splitlines())
                return
            self._capture_pending.discard(name)
            if event == 2:
                self._capture_data[name] = data
            if not self._capture_pending:
                self._finish_capture()
        elif event == 4:
            self._hotkey(token)
        elif event == 5:
            if token == 3:
                self.menus.popup(self.tray_menu, self.root.winfo_pointerx(), self.root.winfo_pointery(), button=None)
            else:
                self.show()

    def _request(self, name: str):
        self._token += 1
        self._requests[self._token] = self._generation, name
        if not self.x11.request(name, self._token):
            self._requests.pop(self._token, None)
            self._capture_pending.discard(name)

    def _start_capture(self, owner: int, forced: bool = False):
        if not self.x11 or (owner == self.x11.window and not forced):
            return
        self._generation += 1
        self._current_formats = None
        self._capture_data = {}; self._capture_pending = set()
        self._capture_forced = forced
        if not forced and not self.settings["MonitoringClipboard"]:
            return
        _ident, app, title = self.x11.active()
        if app.casefold() == "clipangel" or not app:
            app, title = self.last_target_app, self.last_target_title
        ignored = self.settings["IgnoreApplicationsClipCapture"].splitlines()
        if not forced and any(pattern.strip() and fnmatch.fnmatchcase(app.casefold(), pattern.strip().casefold()) for pattern in ignored):
            return
        self._capture_meta = {"app": app, "window": title if self.settings["ReadWindowTitles"] else ""}
        self._request("TARGETS")

    def _targets(self, targets: list[str]):
        if self.settings["IgnoreExclusiveFormatClipCapture"]:
            if any(name in targets for name in ("x-kde-passwordManagerHint", "application/x-keepassxc-secret", "application/x-clipangel-ignore", "ExcludeClipboardContentFromMonitorProcessing")):
                self.notify("Confidential clipboard content was not saved.")
                return
        wanted = []
        for name in SUPPORTED:
            if name in targets:
                wanted.append(name); break
        for choices in (("text/html",), ("text/rtf", "application/rtf"), ("text/uri-list",), ("x-special/gnome-copied-files",)):
            for name in choices:
                if name in targets:
                    wanted.append(name); break
        if self.settings["CaptureImages"]:
            for name in ("image/png", "image/jpeg", "image/bmp", "image/tiff", "image/webp"):
                if name in targets:
                    wanted.append(name); break
        self._capture_pending = set(wanted)
        for name in wanted:
            self._request(name)
        if not self._capture_pending:
            self._finish_capture()

    def _finish_capture(self):
        if not self._capture_data or not any(self._capture_data.values()):
            return
        raw = self._capture_data
        if sum(map(len, raw.values())) > self.settings["MaxClipSizeKB"] * 1024:
            self.notify(f"Clip skipped: larger than the {self.settings['MaxClipSizeKB']} KiB capture limit.")
            return
        html = decode_text(raw.get("text/html", b""))
        source = re.search(r"SourceURL:([^\r\n]+)", html)
        url = source.group(1).strip() if source else ""
        ignored = [s.strip().casefold() for s in self.settings["IgnoreUrlsClipCapture"].splitlines() if s.strip()]
        if any(value in url.casefold() for value in ignored):
            return
        meta = dict(self._capture_meta)
        if url:
            meta["url"] = url
        ident = self.store.add(raw, meta, self.settings)
        self._current_formats = self.store.formats(ident)
        self._captured += 1
        if self._captured % 25 == 0:
            self.store.prune(self.settings)
        self.refresh(select=ident if not self.root.focus_displayof() else None)
        if self.settings["PlaySoundOnClipCapture"]:
            self.root.bell()

    def _restore_clipboard(self):
        if self.running and self.x11 and self._current_formats and not self.x11.owner and self.settings["MonitoringClipboard"]:
            self.x11.copy(self._current_formats)

    def capture_current(self):
        if self.x11 and self.x11.owner:
            self._start_capture(self.x11.owner, forced=True)

    def clear_clipboard(self):
        self._generation += 1; self._current_formats = None
        if self.x11:
            self.x11.clear()
        self.notify("System clipboard cleared. Saved history has not been deleted.")

    def _register_hotkeys(self):
        if not self.x11:
            return
        errors = self.x11.bind_hotkeys({ident: self.settings[key] for ident, key in HOTKEYS.items()})
        self._hotkeys_ok = bool(self.settings["GlobalHotkeyOpenLast"] and self.settings["GlobalHotkeyOpenLast"] not in errors)
        if errors:
            self.root.after(300, lambda: self.notify("Shortcuts unavailable: " + ", ".join(errors), error=True, duration=20000))

    def _hotkey(self, ident: int):
        if self.root.grab_current() is not None:
            self.root.bell(); return
        if ident == 1:
            self.show()
        elif ident == 2:
            self.show(favorites=True)
        elif ident == 3:
            self._remember_target()
            rows, _ = self.store.query(limit=1)
            if rows:
                self.clear_filters(); self.select(rows[0]["id"]); self.paste("text")
        elif ident == 4:
            self.toggle("MonitoringClipboard")
        elif ident in (5, 6):
            self._remember_target()
            self.sequence_paste(1 if ident == 5 else -1)
        elif ident == 7:
            self.show(); self.compare(last=True)
        elif ident == 8:
            self.capture_current()

    def _set_tray_icon(self):
        if self.x11:
            name = "alien.ico" if self.settings["MonitoringClipboard"] else "alien - no capture .ico"
            with Image.open(ASSETS / name) as source:
                image = source.convert("RGBA")
                self.x11.tray(image.tobytes(), *image.size)

    def show(self, favorites: bool = False):
        self._remember_target()
        if favorites:
            self.mark_var.set("favorite"); self.refresh()
        was_hidden = self.root.state() != "normal"
        self.root.deiconify(); self.root.lift(); self.root.focus_force()
        if was_hidden:
            self.root.after_idle(self._restore_splitter)
        self.tree.focus_set()
        if not self.selected() and self.rows:
            self.select_top()

    def hide(self):
        self.menus.dismiss()
        if self.settings["ClearFiltersOnClose"]:
            self.clear_filters()
        self._save_geometry()
        if self.x11 and (self.x11.has_tray or (self._hotkeys_ok and not self.x11.wayland)):
            self.root.withdraw()
        else:
            self.root.iconify()

    def close_window(self):
        if self.settings["CloseToTray"]:
            self.hide()
        else:
            self.quit()

    def _save_geometry(self):
        if self.root.state() == "normal":
            self.settings["WindowGeometry"] = self.root.geometry()
            try:
                self.settings["SplitterPosition"] = self.panes.sash_coord(0)[0]
            except tk.TclError:
                pass
        self.settings.save()

    def _publish(self, formats: dict[str, bytes]):
        if not self.x11:
            raise RuntimeError("The clipboard backend is unavailable")
        self._generation += 1
        self._current_formats = formats
        self.x11.copy(formats)

    def _selected_text(self, allow_preview: bool = False) -> str:
        if allow_preview:
            selected = self.preview.selected_text()
            if selected:
                return selected
        return delimiter(self.settings["DelimiterForTextJoin"]).join(self.store.get(i)["text"] for i in self.selected() if self.store.get(i))

    def copy_selected(self):
        if not self.selected():
            return
        try:
            data = self._paste_data("original")
            self._publish(data)
            self._mark_used(self.selected())
            self.notify("Copied to the system clipboard.")
        except (RuntimeError, ValueError, OSError) as exc:
            messagebox.showerror("Copy", str(exc), parent=self.root)

    def _copy_preview(self, event=None):
        selected = self.preview.selected_text()
        if selected:
            self._publish({"text/plain": selected.encode()})
        return "break"

    def _paste_data(self, mode: str, override: str | None = None) -> dict[str, bytes]:
        if override is not None:
            return {"text/plain": override.encode()}
        ids = self.selected()
        if not ids:
            raise ValueError("Select a clip first")
        if mode == "file":
            urls = []
            for ident in ids:
                existing = file_urls(self.store.formats(ident))
                urls.extend(existing or [self._temporary_file(ident).as_uri()])
            return {"text/uri-list": ("\r\n".join(urls)+"\r\n").encode(),
                    "x-special/gnome-copied-files": ("copy\n"+"\n".join(urls)).encode(),
                    "text/plain": "\n".join(unquote(urlparse(u).path) for u in urls).encode()}
        if mode == "original" and len(ids) == 1:
            return self.store.formats(ids[0])
        clips = [self.store.get(i) for i in ids]
        if mode == "original" and all(c["kind"] == "file" for c in clips):
            urls = [u for i in ids for u in file_urls(self.store.formats(i))]
            return {"text/uri-list": ("\r\n".join(urls)+"\r\n").encode(),
                    "x-special/gnome-copied-files": ("copy\n"+"\n".join(urls)).encode(),
                    "text/plain": "\n".join(unquote(urlparse(u).path) for u in urls).encode()}
        if any(c["kind"] == "img" for c in clips):
            raise ValueError("Images have no plain-text content. Select a single image and use Paste, or use Paste file.")
        text = self._selected_text(allow_preview=mode == "text")
        if mode == "line":
            text = re.sub(r"[\r\n]+", " ", text)
        return {"text/plain": text.encode()}

    def paste(self, mode: str = "original", override: str | None = None):
        if not self.selected() and override is None:
            return
        ids = self.selected()
        try:
            data = self._paste_data(mode, override)
            typed = decode_text(data.get("text/plain", b"")) if mode in ("fast", "slow") else None
            if typed is not None and (len(typed) > 10000 or not self.x11 or not self.x11.can_type(typed)):
                raise ValueError("Simulated typing supports up to 10,000 ASCII characters available on the active keyboard layout. Use Paste text for Unicode or larger clips.")
            self._publish(data)
        except (ValueError, RuntimeError, OSError) as exc:
            messagebox.showerror("Paste", str(exc), parent=self.root)
            return
        self._remember_search()
        if self.settings["DontSendPaste"] or not self.x11 or self.x11.wayland:
            self._mark_used(ids)
            self.notify("Copied. Switch to the destination application and paste manually.", duration=12000)
            return
        target = self.last_target
        if not target:
            self.notify("Copied. No previous application was identified; switch to the destination and paste.", duration=12000)
            return
        # Use the destination's class, not the clip's source app or window
        # title. Query by saved window ID before hiding the history window.
        _, target_app, _ = self.x11.window_info(target)
        sequence = paste_key(self.settings["PasteKey"], target_app or self.last_target_app)
        self._paste_job += 1
        job = self._paste_job
        self._save_geometry()
        self.root.withdraw()
        if not self.x11.activate(target):
            self.show(); self.notify("Copied, but the destination window is no longer available.", error=True, duration=12000)
            return
        def finish():
            self._mark_used(ids)
        def failed():
            self.show(); self.notify("Paste was cancelled because focus changed or a modifier remained pressed. The clip is still copied.", error=True, duration=15000)
        def type_next(index=0):
            if not self.running or job != self._paste_job:
                return
            count = 1 if mode == "slow" else 3
            for _ in range(count):
                if index >= len(typed):
                    finish(); return
                if not self.x11.type_char(target, typed[index]):
                    failed(); return
                index += 1
            self.root.after(45 if mode == "slow" else 2, lambda: type_next(index))
        def attempt(tries=0):
            if not self.running or job != self._paste_job:
                return
            if self.x11.modifiers() and tries < 50:
                self.root.after(30, lambda: attempt(tries+1)); return
            if typed is not None:
                type_next()
            elif self.x11.paste(target, sequence):
                finish()
            else:
                failed()
        self.root.after(120, attempt)

    def _mark_used(self, ids: list[int]):
        self.store.set_mark(ids, "used", True)
        if self.settings["MoveCopiedClipToTop"]:
            for ident in reversed(ids):
                self.store.move(ident, "top")
        self.refresh(select=ids[0] if ids else None)

    def sequence_paste(self, direction: int):
        if not self._sequence_ids:
            rows, _ = self.store.query(limit=30000)
            self._sequence_ids = [row["id"] for row in rows]
            self._sequence_pos = -1
        if not self._sequence_ids:
            return
        self._sequence_pos = (self._sequence_pos + direction) % len(self._sequence_ids)
        ident = self._sequence_ids[self._sequence_pos]
        if not self.store.get(ident):
            self._sequence_ids = []; return
        self.clear_filters(); self.select(ident); self.paste()

    def _remember_search(self):
        text = self.search_var.get().strip()
        if text:
            history = [text] + [s for s in self.settings["LastFilterValues"] if s != text]
            self.settings["LastFilterValues"] = history[:30]
            self.search.configure(values=history[:30])

    def favorite(self, value: bool):
        self.store.set_mark(self.selected(), "favorite", value); self.refresh()

    def move(self, direction: str):
        ids = self.selected()
        for ident in ids if direction == "up" else reversed(ids):
            self.store.move(ident, direction)
        self.sort_var.set("default"); self.refresh()

    def delete_selected(self):
        ids = self.selected()
        if not ids:
            return
        if self.settings["ConfirmationBeforeDelete"] or any(self.row_map[i]["favorite"] for i in ids):
            if not messagebox.askyesno("Delete clips", f"Delete {len(ids)} selected clip(s)?\nCtrl+Z can undo this during the current session.", parent=self.root, default="no"):
                return
        index = next((i for i, r in enumerate(self.rows) if r["id"] in ids), 0)
        self.store.delete(ids); self.refresh()
        if self.rows:
            self.select(self.rows[min(index, len(self.rows)-1)]["id"])

    def delete_nonfavorites(self):
        count = self.store.db.execute("SELECT COUNT(*) FROM clips WHERE favorite=0").fetchone()[0]
        if not count:
            return
        if messagebox.askyesno("Delete non-favorite clips", f"Delete all {count} non-favorite clips?\nFavorite clips will be kept.", parent=self.root, default="no"):
            ids = [r[0] for r in self.store.db.execute("SELECT id FROM clips WHERE favorite=0")]
            self.store.delete(ids); self.refresh(); self.notify("Deleted non-favorite clips. Ctrl+Z undoes this action.")

    def undo_delete(self):
        ids = self.store.undo_delete(); self.refresh(select=ids[0] if ids else None)
        self.notify(f"Restored {len(ids)} clip(s)." if ids else "There is no deletion to undo.")

    def edit_title(self):
        clip = self.current()
        if clip:
            title = simpledialog.askstring("Edit clip title", "Title", initialvalue=clip["title"], parent=self.root)
            if title is not None:
                self.store.rename(clip["id"], title); self.refresh()

    def edit_text(self):
        clip = self.current()
        if not clip:
            return
        if clip["kind"] == "img":
            self.notify("Use Open file to edit an image with your image editor."); return
        def save(value, as_new):
            if as_new:
                ident = self.store.add({"text/plain": value.encode()}, {"app": "ClipAngel", "title": clip["title"]}, self.settings, force_duplicate=True)
            else:
                self.store.edit(clip["id"], value); ident = clip["id"]
            self.refresh(select=ident)
        TextEditor(self.root, clip["text"], "Edit clip text", clip["kind"] in ("html", "rtf", "file"), save)

    def new_clip(self):
        def save(value, _as_new):
            ident = self.store.add({"text/plain": value.encode()}, {"app": "ClipAngel"}, self.settings, force_duplicate=True)
            self.refresh(select=ident)
        TextEditor(self.root, "", "New text clip", False, save)

    def duplicate(self):
        clip = self.current()
        if clip and clip["kind"] != "img":
            ident = self.store.add({"text/plain": clip["text"].encode()}, {"app": "ClipAngel", "title": clip["title"]}, self.settings, force_duplicate=True)
            self.refresh(select=ident)

    def join_clips(self):
        if self.selected():
            ident = self.store.add({"text/plain": self._selected_text().encode()}, {"app": "ClipAngel"}, self.settings, force_duplicate=True)
            self.clear_filters(); self.select(ident)

    def paste_special(self):
        texts = [self.store.get(i)["text"] for i in self.selected()]
        if not texts:
            return
        def action(text, mode):
            self.settings.save()
            if mode == "new":
                ident = self.store.add({"text/plain": text.encode()}, {"app": "ClipAngel"}, self.settings, force_duplicate=True)
                self.refresh(select=ident)
            elif mode == "copy":
                self._publish({"text/plain": text.encode()}); self.notify("Transformed text copied.")
            else:
                self.paste("text", text)
        PasteSpecial(self.root, texts, self.settings, action)

    def compare(self, last=False):
        ids = self.selected()
        if last or len(ids) < 2:
            rows, _ = self.store.query(kind="texts", limit=2)
            ids = [r["id"] for r in rows]
        if len(ids) != 2:
            self.notify("Select two text clips to compare."); return
        first, second = (self.store.get(i) for i in ids)
        if first["kind"] == "img" or second["kind"] == "img":
            self.notify("Text comparison does not compare image pixels."); return
        compare_dialog(self.root, first, second, lambda text: self._publish({"text/plain": text.encode()}))

    def decode_url(self):
        if self.selected():
            text = unquote(self._selected_text())
            ident = self.store.add({"text/plain": text.encode()}, {"app": "ClipAngel"}, self.settings, force_duplicate=True)
            self.refresh(select=ident)

    def ignore_application(self):
        clip = self.current()
        if clip and clip["app"]:
            apps = self.settings["IgnoreApplicationsClipCapture"].splitlines()
            if clip["app"] not in apps:
                apps.append(clip["app"]); self.settings["IgnoreApplicationsClipCapture"] = "\n".join(apps); self.settings.save()
            self.notify(f"Future clipboard captures from {clip['app']} will be ignored.")

    def export_clips(self):
        ids = self.selected() or [row["id"] for row in self.rows]
        if not ids:
            return
        filename = filedialog.asksaveasfilename(parent=self.root, title=f"Export {len(ids)} clip(s)", defaultextension=".cac",
                                              filetypes=[("ClipAngel Windows export", "*.cac"), ("ClipAngel Linux full-fidelity JSON", "*.json")], initialfile="ClipAngel-clips.cac")
        if not filename:
            return
        try:
            count = self.store.export_json(Path(filename), ids) if filename.lower().endswith(".json") else self.store.export_cac(Path(filename), ids)
            self.notify(f"Exported {count} clip(s). The export is not encrypted.", duration=12000)
        except (OSError, ValueError) as exc:
            messagebox.showerror("Export clips", str(exc), parent=self.root)

    def import_clips(self):
        filename = filedialog.askopenfilename(parent=self.root, title="Import ClipAngel clips", filetypes=[("ClipAngel exports and databases", "*.cac *.json *.sqlite *.db"), ("All files", "*")])
        if not filename:
            return
        try:
            backup_dir = private_dir(self.store.path.parent / "backups")
            backup = backup_dir / ("before-import-" + datetime.now().strftime("%Y%m%d-%H%M%S") + ".sqlite")
            self.store.backup(backup)
            count = self.store.import_file(Path(filename))
            self.clear_filters(top=True)
            messagebox.showinfo("Import complete", f"Processed {count} clip(s). Duplicate contents may have merged.\n\nA backup of the previous history was saved to:\n{backup}\n\nWindows file paths are not automatically remapped to Linux paths.", parent=self.root)
        except Exception as exc:
            messagebox.showerror("Import clips", f"Import failed: {exc}\n\nEncrypted Windows databases are not supported. Export to .cac on Windows first.", parent=self.root)

    def _file_data(self, ident: int) -> tuple[bytes, str]:
        clip = self.store.get(ident, True)
        formats = clip["formats"]
        if clip["kind"] == "img":
            for mime, data in formats.items():
                if mime.startswith("image/"):
                    ext = {"image/png": ".png", "image/jpeg": ".jpg", "image/bmp": ".bmp", "image/tiff": ".tiff", "image/webp": ".webp"}.get(mime, ".png")
                    return data, ext
        if clip["kind"] == "html":
            return formats["text/html"], ".html"
        if clip["kind"] == "rtf":
            return formats["text/rtf"], ".rtf"
        return clip["text"].encode(), ".txt"

    def _temporary_file(self, ident: int) -> Path:
        clip = self.store.get(ident, True)
        if clip["kind"] == "file":
            urls = file_urls(clip["formats"])
            if len(urls) == 1:
                parsed = urlparse(urls[0])
                if parsed.scheme == "file" and parsed.netloc in ("", "localhost"):
                    path = Path(unquote(parsed.path))
                    if path.exists():
                        return path.resolve()
        data, suffix = self._file_data(ident)
        directory = private_dir(self.store.path.parent / "temporary-files")
        path = directory / (f"clip-{ident}-{int(time.time()*1000)}" + suffix)
        atomic_write(path, data); self._temp_files.append(path)
        return path

    def save_as(self):
        clip = self.current()
        if not clip:
            return
        data, suffix = self._file_data(clip["id"])
        filename = filedialog.asksaveasfilename(parent=self.root, title="Save clip as file", defaultextension=suffix,
                                              initialfile=f"clip-{clip['id']}{suffix}", filetypes=[("Original format", "*"+suffix), ("Plain text", "*.txt"), ("All files", "*")])
        if filename:
            try:
                atomic_write(Path(filename), clip["text"].encode() if filename.endswith(".txt") else data)
                self.notify("Clip saved.")
            except OSError as exc:
                messagebox.showerror("Save as file", str(exc), parent=self.root)

    def _open_path(self) -> Path | None:
        clip = self.current(True)
        if not clip:
            return None
        if clip["kind"] == "file":
            urls = file_urls(clip["formats"])
            if urls:
                parsed = urlparse(urls[0])
                if parsed.scheme != "file" or parsed.netloc not in ("", "localhost"):
                    self.notify("Only local files can be opened from a file clip.", error=True); return None
                path = Path(unquote(parsed.path))
                if not path.exists():
                    messagebox.showerror("Open file", f"This path does not exist on this computer:\n{path}\n\nImported Windows paths are not remapped automatically.", parent=self.root)
                    return None
                if path.is_file() and (os.access(path, os.X_OK) or path.suffix.lower() in (".desktop", ".sh", ".exe", ".appimage")):
                    if not messagebox.askyesno("Open executable file", "Opening this file may execute code. Only continue for a file you trust.\n\n"+str(path), parent=self.root, default="no"):
                        return None
                return path
        return self._temporary_file(clip["id"])

    def open_file(self):
        path = self._open_path()
        if path:
            try:
                subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            except OSError as exc:
                messagebox.showerror("Open file", str(exc), parent=self.root)

    def open_with(self):
        path = self._open_path()
        if not path:
            return
        executable = filedialog.askopenfilename(parent=self.root, title="Choose an application executable", initialdir="/usr/bin")
        if executable:
            if not os.path.isfile(executable) or not os.access(executable, os.X_OK):
                messagebox.showerror("Open with", "Choose an executable application file.", parent=self.root); return
            subprocess.Popen([executable, str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)

    def open_link(self, url: str):
        if not url:
            return
        parsed = urlparse(url)
        if parsed.scheme.lower() not in ("http", "https", "mailto"):
            self.notify("Only http, https and mailto links can be opened from the preview.", error=True); return
        webbrowser.open(url)

    def translate(self):
        text = self._selected_text(allow_preview=True)
        if not text:
            return
        if len(text) > 5000:
            self.notify("Select at most 5,000 characters for browser translation.", error=True); return
        if messagebox.askyesno("Translate text", "This sends the selected text to Google Translate in your browser. Continue?", parent=self.root, default="no"):
            webbrowser.open("https://translate.google.com/?" + urlencode({"sl": "auto", "tl": "en", "text": text, "op": "translate"}))

    def qr_code(self):
        text = self._selected_text(allow_preview=True)
        if not text:
            return
        if len(text.encode()) > 2000:
            self.notify("Select no more than 2,000 UTF-8 bytes for a QR code.", error=True); return
        try:
            import qrcode
            image = qrcode.make(text).get_image().convert("RGB")
        except ImportError:
            messagebox.showinfo("QR code", "Install the optional python3-qrcode package to use this feature.", parent=self.root); return
        except Exception as exc:
            messagebox.showerror("QR code", str(exc), parent=self.root); return
        win = window(self.root, "QR code", "520x560")
        image.thumbnail((480, 480), Resampling.NEAREST)
        photo = ImageTk.PhotoImage(image, master=win)
        label = ttk.Label(win, image=photo); label.image = photo; label.pack(expand=True)
        def save():
            path = filedialog.asksaveasfilename(parent=win, defaultextension=".png", initialfile="clip-qr.png")
            if path:
                data = io.BytesIO(); image.save(data, "PNG"); atomic_write(Path(path), data.getvalue())
        ttk.Button(win, text="Save PNG...", command=save).pack(pady=10)

    def find(self, direction: int):
        if self.preview.find(direction):
            return
        query = self.search_var.get()
        if query and not self.settings["FilterListBySearchString"]:
            matches, _ = self.store.query(query, settings=self.settings, limit=50000)
            ids = [row["id"] for row in matches if row["id"] in self.row_map]
        else:
            ids = [row["id"] for row in self.rows]
        if ids:
            current = ids.index(self.selected_id) if self.selected_id in ids else -1
            self.select(ids[(current+direction) % len(ids)])

    def select(self, ident: int):
        if not self.tree.exists(str(ident)):
            return
        self.tree.selection_set(str(ident)); self.tree.focus(str(ident)); self.tree.see(str(ident)); self._update_preview()

    def select_top(self):
        if self.rows:
            self.select(self.rows[0]["id"])

    def select_all(self, event=None):
        self.tree.selection_set(self.tree.get_children()); self._status(); return "break"

    def focus_search(self):
        self.search.focus_set(); self.search.selection_range(0, "end"); return "break"

    def focus_preview(self):
        (self.preview.canvas if self.preview.mode == "image" else self.preview.text).focus_set(); return "break"

    def focus_list(self):
        self.tree.focus_set(); return "break"

    def switch_focus(self):
        return self.focus_preview() if self.root.focus_get() == self.tree else self.focus_list()

    def set_filter(self, mark=None, kind=None):
        if mark:
            self.mark_var.set(next(label for label, value in MARKS if value == mark))
        if kind:
            self.type_var.set(next(label for label, value in TYPES if value == kind))
        self.refresh()

    def clear_filters(self, top=False):
        self.search_var.set(""); self.mark_var.set("all marks"); self.type_var.set("all types")
        self.start_date = self.end_date = ""
        if self.filter_after:
            self.root.after_cancel(self.filter_after); self.filter_after = None
        self.refresh()
        if top:
            self.select_top()

    def clear_and_previous(self):
        ident = self.previous_before_filter
        self.clear_filters(); self.previous_before_filter = None
        if ident:
            self.select(ident)

    def filter_date(self):
        def apply(start, end):
            self.start_date, self.end_date = start, end; self.refresh()
        date_dialog(self.root, self.start_date, self.end_date, apply)

    def load_more(self):
        self.visible_limit += 5000; self.refresh()

    def _context_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item and item not in self.tree.selection():
            self.tree.selection_set(item); self.tree.focus(item); self._update_preview()
        self.menus.popup(self.context, event.x_root, event.y_root)
        return "break"

    def _preview_context(self, event):
        self.menus.popup(self.preview_context, event.x_root, event.y_root)
        return "break"

    def _image_context(self, event):
        self.menus.popup(self.image_context, event.x_root, event.y_root)
        return "break"

    def toggle(self, setting: str, value: bool | None = None):
        if setting == "Autostart":
            desired = not autostart.is_enabled() if value is None else value
            try:
                autostart.set_enabled(desired)
            except OSError as exc:
                self.vars[setting].set(autostart.is_enabled())
                self.notify(f"Could not update autostart: {exc}", error=True)
                return
            value = desired
        self.settings[setting] = not self.settings[setting] if value is None else value
        self.vars[setting].set(self.settings[setting])
        if setting == "MonitoringClipboard":
            self._generation += 1
            self._set_tray_icon()
            if self.settings[setting]:
                self.capture_current()
        elif setting == "AlwaysOnTop":
            self.root.attributes("-topmost", self.settings[setting])
        elif setting == "DarkTheme":
            self._style()
            self._update_preview()
        self.settings.save(); self._sync_toolbar()
        if setting.startswith("Search") or setting == "FilterListBySearchString":
            self.refresh()
        elif setting in ("WordWrap", "MonospacedFont", "ShowNativeTextFormatting"):
            self._update_preview()
        self._status()

    def _sync_toolbar(self):
        for button, key in self._toolbar:
            button.configure(background=self.theme.palette["hover" if key and self.settings[key] else "bg"])
        secondary = self.settings["ShowSecondaryColumns"]
        self.tree.configure(show="tree headings" if secondary else "tree", displaycolumns=("chars", "type", "app", "created") if secondary else ("chars",))

    def show_settings(self):
        self.menus.dismiss()
        self.show()
        self.settings["Autostart"] = autostart.is_enabled()
        self.vars["Autostart"].set(self.settings["Autostart"])
        SettingsDialog(self.root, self.settings, self.store.path, self.apply_settings)

    def apply_settings(self, values: dict):
        desired = values.get("Autostart", self.settings["Autostart"])
        # Only an explicit checkbox change writes the entry. Do not undo a
        # Startup Applications/CLI change made while this dialog was open.
        if desired != self.settings["Autostart"]:
            try:
                autostart.set_enabled(desired)
            except OSError as exc:
                self.notify(f"Could not update autostart: {exc}", error=True)
                return
        self.settings.update(values)
        self.settings["Autostart"] = autostart.is_enabled()
        for key, variable in self.vars.items():
            variable.set(self.settings[key])
        self.settings.save(); self._style(); self._load_locale(); self._build_menus()
        self.theme.walk(self.root)
        self.root.attributes("-topmost", self.settings["AlwaysOnTop"])
        self._sync_toolbar(); self._register_hotkeys(); self._set_tray_icon()
        self.store.prune(self.settings); self.refresh()

    def _documentation(self, filename: str) -> str:
        paths = [Path(__file__).parent.parent / "docs" / filename, Path("/usr/share/doc/clipangel") / filename]
        for path in paths:
            if path.exists():
                return path.read_text("utf-8")
        return "Documentation is included in the source package and in /usr/share/doc/clipangel."

    def help(self):
        text_dialog(self.root, "Help", self._documentation("USER-GUIDE.md"))

    def changes(self):
        text_dialog(self.root, "History of changes", self._documentation("CHANGELOG.md"))

    def update_info(self):
        messagebox.showinfo("Updates", "This is an unofficial Linux reimplementation, not the Windows executable.\n\nInstall updates as a new .deb package. The Windows updater is intentionally not used, and this build does not contact an update server.", parent=self.root)

    def about(self):
        text_dialog(self.root, "About ClipAngel Linux", f"ClipAngel Linux {__version__}\n\nSource-informed Linux reimplementation targeting ClipAngel {UPSTREAM_VERSION}.\n\nOriginal ClipAngel: Tormozit and contributors.\nOriginal source snapshot: a8c60d32d05197fa01469a9e4ba6b189c180d069\nOriginal artwork and menu translations are retained under the accompanying GPL license.\n\nLinux interface: Python 3 / Tk\nClipboard and desktop integration: native X11 / XFixes / XTest\nHistory: SQLite\nLicense: GNU General Public License, version 3.\n\nThis is NOT an official upstream release and NOT a pixel-perfect or feature-complete Windows port. Read FEATURE-PARITY.md for supported and unsupported functions.\n\nNo telemetry or automatic uploads. HTML previews do not execute scripts or load remote resources. Browser translation only runs after explicit confirmation.\n\nHistory and exports are not encrypted. Do not use clipboard history as a password vault.", "700x570")

    def diagnostics(self):
        rtf = "unrtf available" if shutil.which("unrtf") else "Plain-text fallback (optional unrtf not installed)"
        backend = "Unavailable" if not self.x11 else "XWayland compatibility (limited)" if self.x11.wayland else "X11"
        data = f"Version: {__version__}\nPython: {sys.version.split()[0]}\nTk: {tk.TkVersion}\nBackend: {backend}\nGlobal history shortcut registered: {self._hotkeys_ok}\nXEmbed tray manager: {bool(self.x11 and self.x11.has_tray)}\nXFixes available: {bool(self.x11 and self.x11.lib.ca_has_xfixes(self.x11.ctx))}\nRTF preview: {rtf}\nMonitoring: {self.settings['MonitoringClipboard']}\nTheme: {'Dark' if self.settings['DarkTheme'] else 'Light'}\nStart at login: {autostart.is_enabled()}\nStartup entry: {autostart.entry_path()}\nPaste setting: {self.settings['PasteKey']}\nLast target class: {self.last_target_app or '(unknown)'}\nResolved paste key: {paste_key(self.settings['PasteKey'], self.last_target_app)}\nHistory records: {self.store.count()}\n\nDatabase: {self.store.path}\nSettings: {self.settings.path}\n\nClipboard contents are not included in this diagnostic report.\n\nLast startup error: {self.backend_error or 'None'}"
        text_dialog(self.root, "Diagnostics", data, "760x470")

    def handle_command(self, command: dict):
        action = command.get("action", "show")
        if action == "show":
            self.show()
        elif action == "favorites":
            self.show(favorites=True)
        elif action == "toggle-monitoring":
            self.toggle("MonitoringClipboard")
        elif action == "capture":
            self.capture_current()
        elif action == "add-text":
            value = command.get("text", "")
            if isinstance(value, str) and len(value.encode()) <= 1024*1024:
                ident = self.store.add({"text/plain": value.encode()}, {"app": "Command line"}, self.settings)
                self.refresh(select=ident)
        elif action == "sync-autostart":
            self.settings["Autostart"] = autostart.is_enabled()
            self.vars["Autostart"].set(self.settings["Autostart"])
            self.settings.save()
        elif action == "quit":
            self.quit()

    def quit(self):
        if not self.running:
            return
        self.menus.dismiss()
        self._save_geometry()
        self.running = False; self._paste_job += 1
        if self.settings["DeleteNonFavoriteClipsOnExit"]:
            ids = [r[0] for r in self.store.db.execute("SELECT id FROM clips WHERE favorite=0")]
            self.store.delete(ids, remember=False)
        if self.x11:
            self.x11.close()
        if self.instance:
            self.instance.close()
        self.store.close()
        for timer in self.root.tk.call("after", "info"):
            # Timers also belong to child widgets (tooltips/image rendering).
            # root.after_cancel deletes their Tcl commands through the wrong
            # owner, causing a second deletion when that widget is destroyed.
            # Cancel scheduling here; each owner's destroy frees its commands.
            self.root.tk.call("after", "cancel", timer)
        self.root.destroy()
