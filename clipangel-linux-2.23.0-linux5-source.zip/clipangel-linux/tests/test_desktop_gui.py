"""Real X11 event tests, using independent terminal-style receiver processes.

The GNOME/Konsole identities below are fixtures, not those applications' binaries.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import tkinter as tk
from tkinter import ttk
import unittest
from unittest.mock import patch

from clipangel import autostart
from clipangel.app import Application
from clipangel.core import Store, Settings
from clipangel.dialogs import SettingsDialog, TextEditor, PasteSpecial, compare_dialog, text_dialog
from clipangel.theme import DARK, LIGHT

TARGET = r'''
import json,sys,tkinter as tk
from pathlib import Path
p=Path(sys.argv[1]); identity=sys.argv[2]; wanted=sys.argv[3]
r=tk.Tk(className=identity); r.title('A renamed window: not a terminal title')
t=tk.Text(r); t.pack(); events=[]; returns=[]
def paste(e, key):
 events.append(key)
 if key==wanted:
  t.insert('insert',r.clipboard_get())
 return 'break'
def enter(e):
 returns.append(True)
 return 'break'
t.bind('<Control-v>',lambda e:paste(e,'Ctrl+V'))
t.bind('<Control-Shift-V>',lambda e:paste(e,'Ctrl+Shift+V'))
t.bind('<Shift-Insert>',lambda e:paste(e,'Shift+Insert'))
t.bind('<Return>',enter)
r.update(); t.focus_force(); (p/'ready').write_text('ready')
def save():
 (p/'received').write_text(json.dumps({'text':t.get('1.0','end-1c'),'keys':events,'returns':len(returns)}),encoding='utf-8')
 r.after(25,save)
r.after(25,save); r.after(15000,r.destroy); r.mainloop()
'''


@unittest.skipUnless(os.environ.get('DISPLAY'), 'requires X11 and a window manager')
class DesktopGUITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name)
        self.env = patch.dict(os.environ, {'XDG_CONFIG_HOME': str(self.path / 'config'),
                                          'XDG_DATA_HOME': str(self.path / 'data')})
        self.env.start()
        self.root = tk.Tk(className='ClipAngel')
        self.settings = Settings(self.path / 'settings.json')
        self.settings['MonitoringClipboard'] = False
        self.store = Store(self.path / 'history.sqlite3')
        self.app = Application(self.root, self.store, self.settings)
        self.errors = []
        self.root.report_callback_exception = lambda *args: self.errors.append(args)
        self.pump(.25)

    def tearDown(self):
        if self.app.running:
            self.app.quit()
        self.env.stop()
        self.temp.cleanup()
        self.assertEqual(self.errors, [])

    def pump(self, seconds=.15, until=None):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            self.root.update()
            time.sleep(.004)
            if until and until():
                return

    def fixture_paste(self, identity, wanted, configured='Auto', double_click=True, mode='original'):
        self.settings['PasteKey'] = configured
        proc = subprocess.Popen([sys.executable, '-c', TARGET, str(self.path), identity, wanted],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            self.pump(4, lambda: (self.path / 'ready').exists())
            self.assertTrue((self.path / 'ready').exists())
            self.pump(.3)
            active, detected, _ = self.app.x11.active()
            self.assertEqual(detected.casefold(), identity.casefold())
            payload = 'Terminal paste: München 日本語 😀 — no Enter sent'
            ident = self.store.add({'text/plain': payload.encode()})
            self.app.refresh(select=ident)
            self.app.show()
            self.pump(.2)
            self.assertEqual(self.app.last_target, active)
            # Use fresh WM_CLASS queried by window ID, not stale cached metadata.
            self.app.last_target_app = 'deliberately-wrong-cache'
            if double_click:
                box = self.app.tree.bbox(str(ident))
                self.assertTrue(box)
                x, y, w, h = box
                for stamp in (100000, 100100):
                    self.app.tree.event_generate('<ButtonPress-1>', x=x+48, y=y+h//2, time=stamp)
                    self.app.tree.event_generate('<ButtonRelease-1>', x=x+48, y=y+h//2, time=stamp+25)
                    self.root.update()
            elif mode == 'enter':
                self.app.tree.event_generate('<KeyPress-Return>')
            else:
                self.app.paste(mode)
            def read():
                try:
                    return json.loads((self.path / 'received').read_text())
                except (FileNotFoundError, json.JSONDecodeError):
                    return {}
            self.pump(4, lambda: read().get('text') == payload)
            result = read()
            self.assertEqual(result.get('text'), payload, result)
            self.assertEqual(result.get('keys'), [wanted])
            self.assertEqual(result.get('returns'), 0)
            self.assertTrue(self.store.get(ident)['used'])
        finally:
            proc.terminate()
            _, stderr = proc.communicate(timeout=3)
            self.assertEqual(stderr, b'')

    def test_double_click_gnome_terminal(self):
        self.fixture_paste('Gnome-terminal', 'Ctrl+Shift+V')

    def test_double_click_konsole(self):
        self.fixture_paste('konsole', 'Ctrl+Shift+V')

    def test_double_click_regular_editor(self):
        self.fixture_paste('notepadqq', 'Ctrl+V')

    def test_enter_into_terminal(self):
        self.fixture_paste('konsole', 'Ctrl+Shift+V', double_click=False, mode='enter')

    def test_plain_text_paste_into_terminal(self):
        self.fixture_paste('Gnome-terminal', 'Ctrl+Shift+V', double_click=False, mode='text')

    def test_manual_paste_override_into_terminal(self):
        self.fixture_paste('konsole', 'Shift+Insert', configured='Shift+Insert')

    def test_window_metadata_by_id_does_not_change_focus(self):
        before = self.app.x11.active()
        self.assertEqual(self.app.x11.window_info(before[0]), before)
        self.assertEqual(self.app.x11.active(), before)
        self.assertEqual(self.app.x11.window_info(0), (0, '', ''))
        self.assertEqual(self.app.x11.window_info(0x7ffffffe), (0, '', ''))

    def test_dark_theme_live_and_restart_setting(self):
        raw = b'<p style="color: black">Black source text with <b>formatting</b></p>'
        ident = self.store.add({'text/html': raw})
        self.app.refresh(select=ident)
        self.app.toggle('ShowNativeTextFormatting', True)
        self.app.toggle('DarkTheme', True)
        self.pump()
        self.assertEqual(self.root.cget('background'), DARK['bg'])
        self.assertEqual(self.app.preview.text.cget('background'), DARK['surface'])
        self.assertEqual(ttk.Style(self.root).lookup('Treeview', 'fieldbackground'), DARK['surface'])
        self.assertEqual(self.app.tree.tag_configure('favorite')['background'], DARK['favorite'])
        self.assertTrue(Settings(self.settings.path)['DarkTheme'])
        self.assertEqual(self.store.formats(ident)['text/html'], raw)
        for tag in self.app.preview.text.tag_names():
            if tag.startswith('style'):
                self.assertEqual(self.app.preview.text.tag_cget(tag, 'foreground'), DARK['fg'])
        self.app.toggle('DarkTheme', False)
        self.pump()
        self.assertEqual(self.app.preview.text.cget('background'), LIGHT['surface'])
        self.assertEqual(self.root.cget('background'), LIGHT['bg'])
        self.assertFalse(Settings(self.settings.path)['DarkTheme'])

    def test_dialogs_created_in_dark_theme(self):
        self.app.toggle('DarkTheme', True)
        settings = SettingsDialog(self.root, self.settings, self.store.path, self.app.apply_settings)
        settings.notebook.select(1)
        editor = TextEditor(self.root, 'test text', 'Test', False, lambda *args: None)
        self.pump()
        self.assertEqual(editor.text.cget('background'), DARK['surface'])
        self.assertEqual(editor.win.cget('background'), DARK['bg'])
        editor.win.destroy()
        special = PasteSpecial(self.root, ['text'], self.settings, lambda *args: None)
        self.pump()
        self.assertEqual(special.preview.cget('background'), DARK['surface'])
        special.win.destroy()
        info = text_dialog(self.root, 'Test', 'Dark documentation')
        self.pump()
        for frame in info.winfo_children():
            for widget in frame.winfo_children():
                if isinstance(widget, tk.Text):
                    self.assertEqual(widget.cget('foreground'), DARK['fg'])
        info.destroy()
        settings.win.destroy()

    def test_about_dialog_header_and_project_link(self):
        url = 'https://github.com/tormozit/ClipAngel'
        for dark, palette in ((False, LIGHT), (True, DARK)):
            with self.subTest(dark=dark):
                self.app.toggle('DarkTheme', dark)
                self.app.about()
                self.pump()
                dialog = next(w for w in self.root.winfo_children()
                              if isinstance(w, tk.Toplevel) and w.title().startswith('About ClipAngel Linux'))
                try:
                    text = next(w for frame in dialog.winfo_children()
                                for w in frame.winfo_children() if isinstance(w, tk.Text))
                    self.assertEqual(text.get('1.0', '2.end'),
                                     'ClipAngel Linux clone\nOriginal project: ' + url)
                    self.assertIn('Original ClipAngel: Tormozit and contributors.', text.get('1.0', 'end'))
                    self.assertEqual(text.get('link.first', 'link.last'), url)
                    self.assertEqual(text.tag_cget('link', 'foreground'), palette['link'])
                    self.assertEqual(str(text.cget('state')), 'disabled')
                    x, y, w, h = text.bbox('link.first')
                    with patch('clipangel.dialogs.webbrowser.open') as browser:
                        text.event_generate('<Motion>', x=x + w // 2, y=y + h // 2, warp=True)
                        self.pump()
                        text.event_generate('<ButtonPress-1>', x=x + w // 2, y=y + h // 2)
                        text.event_generate('<ButtonRelease-1>', x=x + w // 2, y=y + h // 2)
                        self.pump()
                        browser.assert_called_once_with(url)
                finally:
                    dialog.destroy()

    def test_existing_combobox_popup_recolors(self):
        combo = self.app.type_combo
        popup = self.root.tk.call('ttk::combobox::PopdownWindow', str(combo))
        listbox = str(popup) + '.f.l'
        self.app.toggle('DarkTheme', True)
        self.assertEqual(self.root.tk.call(listbox, 'cget', '-background'), DARK['surface'])
        self.app.toggle('DarkTheme', False)
        self.assertEqual(self.root.tk.call(listbox, 'cget', '-background'), LIGHT['surface'])

    def test_autostart_menu_toggle_and_theme_do_not_reenable_external_disable(self):
        self.assertFalse(autostart.entry_path().exists())
        self.app.toggle('Autostart', True)
        self.assertTrue(autostart.is_enabled())
        path = autostart.entry_path()
        path.write_text(path.read_text().replace('Hidden=false', 'Hidden=true'))
        self.app.toggle('DarkTheme', True)
        self.app.apply_settings({'Autostart': True, 'DarkTheme': False})
        self.assertFalse(autostart.is_enabled())
        self.assertFalse(self.settings['Autostart'])
        self.app.toggle('Autostart', True)
        self.assertTrue(autostart.is_enabled())
        self.app.toggle('Autostart', False)
        self.assertFalse(path.exists())

    def test_autostart_write_error_is_reported(self):
        with patch('clipangel.autostart.set_enabled', side_effect=PermissionError('test denied')):
            self.app.toggle('Autostart', True)
        self.assertFalse(self.settings['Autostart'])
        self.assertFalse(self.app.vars['Autostart'].get())
        self.assertIn('Could not update autostart', self.app.message_var.get())

    def test_preferences_save_theme_and_autostart(self):
        dialog = SettingsDialog(self.root, self.settings, self.store.path, self.app.apply_settings)
        dialog.vars['DarkTheme'].set(True)
        dialog.vars['Autostart'].set(True)
        dialog.accept()
        self.pump()
        self.assertTrue(autostart.is_enabled())
        self.assertEqual(self.root.cget('background'), DARK['bg'])
        dialog = SettingsDialog(self.root, self.settings, self.store.path, self.app.apply_settings)
        self.assertTrue(dialog.vars['DarkTheme'].get())
        self.assertTrue(dialog.vars['Autostart'].get())
        dialog.vars['Autostart'].set(False)
        dialog.vars['DarkTheme'].set(False)
        dialog.accept()
        self.pump()
        self.assertFalse(autostart.is_enabled())
        self.assertEqual(self.root.cget('background'), LIGHT['bg'])

    def test_minimized_initial_window_and_splitter_on_show(self):
        self.app.quit()
        self.root = tk.Tk(className='ClipAngel')
        self.root.withdraw()
        self.store = Store(self.path / 'hidden-history.sqlite3')
        self.settings['WindowGeometry'] = '980x600+40+40'
        self.settings['SplitterPosition'] = 410
        self.app = Application(self.root, self.store, self.settings)
        self.root.report_callback_exception = lambda *args: self.errors.append(args)
        self.root.after(150, self.app.hide)
        self.pump(.4)
        self.assertEqual(self.root.state(), 'withdrawn')
        self.assertFalse(self.root.winfo_viewable())
        self.app.show()
        self.pump(.2)
        self.assertEqual(self.root.state(), 'normal')
        self.assertGreater(self.app.panes.sash_coord(0)[0], 300)
        self.assertGreater(self.app.preview.winfo_width(), 250)

    def test_click_empty_history_does_not_paste(self):
        from types import SimpleNamespace
        ident = self.store.add({'text/plain': b'not pasted'})
        self.app.refresh(select=ident)
        self.pump()
        with patch.object(self.app, 'paste') as paste:
            self.app._double_click_clip(SimpleNamespace(x=60, y=self.app.tree.winfo_height()-5))
            paste.assert_not_called()


if __name__ == '__main__':
    unittest.main()
