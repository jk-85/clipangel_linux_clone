/* SPDX-License-Identifier: GPL-3.0-only
 * ClipAngel Linux: X11 selection, global hotkey, XEmbed and paste adapter.
 * No polling of clipboard contents and no shell commands. All calls run on
 * the GUI thread. Implements both directions of the ICCCM INCR protocol.
 */
#define _POSIX_C_SOURCE 200809L
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <limits.h>

/* Stable extension ABI; build does not require extension development headers. */
extern Bool XFixesQueryExtension(Display *, int *, int *);
extern Status XFixesQueryVersion(Display *, int *, int *);
extern void XFixesSelectSelectionInput(Display *, Window, Atom, unsigned long);
extern Bool XTestFakeKeyEvent(Display *, unsigned int, Bool, unsigned long);
typedef struct { int type; unsigned long serial; Bool send_event; Display *display;
    Window window; int subtype; Window owner; Atom selection;
    Time timestamp, selection_timestamp; } FixesSelectionEvent;

typedef void (*Callback)(int, unsigned long, const void *, size_t);
enum { EV_OWNER=1, EV_DATA=2, EV_FAIL=3, EV_KEY=4, EV_TRAY=5 };
#define SLOTS 64
#define MAX_DATA (64UL*1024*1024)
#define CHUNK 49152

typedef struct { Atom type; unsigned char *data; size_t length; } Format;
typedef struct { int active, incr; unsigned long token; Atom target, property;
    unsigned char *data; size_t length; double deadline; } Incoming;
typedef struct { int active; Window window; Atom property, type;
    unsigned char *data; size_t length, offset; double deadline; } Outgoing;
typedef struct { int id, code; unsigned int modifiers; } Hotkey;
typedef struct {
    Display *d; Window root, window, tray, tray_manager;
    Atom clipboard, targets, incr, timestamp, utf8, active_window, name, tray_atom;
    int fixes_base, screen; unsigned int numlock;
    Callback callback; Format formats[SLOTS]; int nformats;
    Incoming incoming[SLOTS]; Outgoing outgoing[SLOTS];
    Hotkey keys[24]; int nkeys; Time server_time, owned_time;
    unsigned char *tray_rgba; int tray_width, tray_height;
    Visual *tray_visual; int tray_depth, tray_alpha;
    Colormap tray_colormap; GC tray_gc; double tray_check;
} Context;

static int xerror = 0;
static int ignore_error(Display *d, XErrorEvent *e) { (void)d; xerror=e->error_code; return 0; }
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec/1e9; }
static void emit(Context *c,int event,unsigned long token,const void *data,size_t n) {
    if(c->callback) c->callback(event,token,data,n);
}
static void incoming_done(Context *c, Incoming *r, int success) {
    unsigned long token=r->token; unsigned char *data=r->data; size_t length=r->length;
    r->active=0; r->data=NULL; r->length=0;
    emit(c,success?EV_DATA:EV_FAIL,token,data,length); free(data);
}
static int append(Incoming *r,const unsigned char *p,size_t n) {
    if(n>MAX_DATA-r->length) return 0;
    unsigned char *q=realloc(r->data,r->length+n+1); if(!q) return 0;
    r->data=q; if(n) memcpy(q+r->length,p,n); r->length+=n; q[r->length]=0; return 1;
}
static int property(Context *c,Window w,Atom atom,Atom *type,int *format,
                    unsigned long *n,unsigned char **data,int remove) {
    unsigned long left=0; *data=NULL; *n=0; *type=None; *format=0;
    int status=XGetWindowProperty(c->d,w,atom,0,MAX_DATA/4,remove,AnyPropertyType,
                                 type,format,n,&left,data);
    if(status!=Success || left || (*format!=8 && *format!=16 && *format!=32)) {
        if(*data) XFree(*data); *data=NULL; return 0;
    }
    return 1;
}
static void read_incoming(Context *c,Incoming *r,int first) {
    Atom type; int format; unsigned long n; unsigned char *data;
    if(!property(c,c->window,r->property,&type,&format,&n,&data,True)) {
        incoming_done(c,r,0); return;
    }
    if(first && type==c->incr) {
        unsigned long size=(format==32 && n)?((unsigned long*)data)[0]:0;
        XFree(data);
        if(size>MAX_DATA) { incoming_done(c,r,0); return; }
        r->incr=1; r->deadline=now()+10; XFlush(c->d); return;
    }
    int ok=1;
    if(type==XA_ATOM && format==32) {
        unsigned long *atoms=(unsigned long*)data;
        for(unsigned long i=0;i<n && ok;i++) {
            char *s=XGetAtomName(c->d,atoms[i]);
            if(s) { ok=append(r,(unsigned char*)s,strlen(s)) && append(r,(unsigned char*)"\n",1); XFree(s); }
        }
    } else if(format==8) { ok=append(r,data,n); }
    else if(n) { ok=0; }
    XFree(data); r->deadline=now()+10;
    if(!ok || !r->incr || n==0) incoming_done(c,r,ok);
    XFlush(c->d);
}
static void notify_request(Context *c,XSelectionRequestEvent *req,Atom property) {
    XEvent ev; memset(&ev,0,sizeof(ev)); ev.xselection.type=SelectionNotify;
    ev.xselection.display=req->display; ev.xselection.requestor=req->requestor;
    ev.xselection.selection=req->selection; ev.xselection.target=req->target;
    ev.xselection.property=property; ev.xselection.time=req->time;
    XSendEvent(c->d,req->requestor,False,0,&ev); XFlush(c->d);
}
static void selection_request(Context *c,XSelectionRequestEvent *req) {
    Atom p=req->property?req->property:req->target;
    if(req->selection!=c->clipboard) { notify_request(c,req,None); return; }
    if(req->target==c->targets) {
        Atom atoms[SLOTS+2]; atoms[0]=c->targets; atoms[1]=c->timestamp;
        for(int i=0;i<c->nformats;i++) atoms[i+2]=c->formats[i].type;
        XChangeProperty(c->d,req->requestor,p,XA_ATOM,32,PropModeReplace,
                        (unsigned char*)atoms,c->nformats+2);
        notify_request(c,req,p); return;
    }
    if(req->target==c->timestamp) {
        unsigned long time=c->owned_time;
        XChangeProperty(c->d,req->requestor,p,XA_INTEGER,32,PropModeReplace,(unsigned char*)&time,1);
        notify_request(c,req,p); return;
    }
    Format *f=NULL;
    for(int i=0;i<c->nformats;i++) if(c->formats[i].type==req->target) { f=&c->formats[i]; break; }
    if(!f) { notify_request(c,req,None); return; }
    if(f->length<=CHUNK) {
        XChangeProperty(c->d,req->requestor,p,f->type,8,PropModeReplace,f->data,(int)f->length);
        notify_request(c,req,p); return;
    }
    Outgoing *s=NULL;
    for(int i=0;i<SLOTS;i++) if(!c->outgoing[i].active) { s=&c->outgoing[i]; break; }
    if(!s) { notify_request(c,req,None); return; }
    s->data=malloc(f->length);
    if(!s->data) { notify_request(c,req,None); return; }
    memcpy(s->data,f->data,f->length); s->length=f->length; s->offset=0;
    s->active=1; s->window=req->requestor; s->property=p; s->type=f->type; s->deadline=now()+15;
    XSelectInput(c->d,req->requestor,PropertyChangeMask);
    unsigned long size=f->length;
    XChangeProperty(c->d,req->requestor,p,c->incr,32,PropModeReplace,(unsigned char*)&size,1);
    notify_request(c,req,p);
}
static void outgoing_next(Context *c,Outgoing *s) {
    size_t n=s->length-s->offset; if(n>CHUNK) n=CHUNK;
    XChangeProperty(c->d,s->window,s->property,s->type,8,PropModeReplace,s->data+s->offset,(int)n);
    s->offset+=n; s->deadline=now()+15;
    if(n==0) { free(s->data); memset(s,0,sizeof(*s)); }
    XFlush(c->d);
}
/* Use the tray host's advertised ARGB8888 visual when available. The
 * legacy RGB path keeps the previous background for non-ARGB hosts. */
static void tray_choose_visual(Context *c) {
    c->tray_visual=DefaultVisual(c->d,c->screen);
    c->tray_depth=DefaultDepth(c->d,c->screen);
    Window manager=XGetSelectionOwner(c->d,c->tray_atom);
    if(!manager) return;
    Atom type; int format; unsigned long n; unsigned char *data;
    Atom atom=XInternAtom(c->d,"_NET_SYSTEM_TRAY_VISUAL",False);
    if(!property(c,manager,atom,&type,&format,&n,&data,False)) return;
    if(type==XA_VISUALID && format==32 && n==1) {
        XVisualInfo wanted={0}; wanted.visualid=((unsigned long*)data)[0];
        wanted.screen=c->screen;
        int count=0;
        XVisualInfo *info=XGetVisualInfo(c->d,VisualIDMask|VisualScreenMask,&wanted,&count);
        if(info && count && info->depth==32 && info->class==TrueColor &&
           info->red_mask==0xff0000 && info->green_mask==0xff00 && info->blue_mask==0xff) {
            c->tray_visual=info->visual; c->tray_depth=32; c->tray_alpha=1;
        }
        if(info) XFree(info);
    }
    XFree(data);
}
static unsigned long tray_channel(unsigned long mask,unsigned int value) {
    if(!mask) return 0;
    unsigned int shift=0; while(!(mask&1)) { mask>>=1; shift++; }
    return ((value*mask+127)/255)<<shift;
}
/* Render the source to the actual allocation, preserving aspect ratio.
 * Interpolate premultiplied channels so transparent edges stay clean. */
static void tray_draw(Context *c) {
    if(!c->tray || !c->tray_rgba) return;
    XWindowAttributes wa;
    if(!XGetWindowAttributes(c->d,c->tray,&wa) || wa.width<1 || wa.height<1) return;
    int w=wa.width>256?256:wa.width, h=wa.height>256?256:wa.height;
    if(w*c->tray_height>h*c->tray_width) w=h*c->tray_width/c->tray_height;
    else h=w*c->tray_height/c->tray_width;
    if(w<1) w=1; if(h<1) h=1;
    XImage *img=XCreateImage(c->d,c->tray_visual,c->tray_depth,ZPixmap,0,NULL,w,h,32,0);
    if(!img) return;
    img->data=calloc(h,img->bytes_per_line);
    if(!img->data) { XDestroyImage(img); return; }
    for(int y=0;y<h;y++) for(int x=0;x<w;x++) {
        double fx=(x+0.5)*c->tray_width/w-0.5, fy=(y+0.5)*c->tray_height/h-0.5;
        if(fx<0) fx=0; if(fx>c->tray_width-1) fx=c->tray_width-1;
        if(fy<0) fy=0; if(fy>c->tray_height-1) fy=c->tray_height-1;
        int x0=(int)fx, y0=(int)fy;
        int x1=x0+1<c->tray_width?x0+1:x0, y1=y0+1<c->tray_height?y0+1:y0;
        double dx=fx-x0, dy=fy-y0;
        const unsigned char *p[4]={c->tray_rgba+4*(y0*c->tray_width+x0),
            c->tray_rgba+4*(y0*c->tray_width+x1),c->tray_rgba+4*(y1*c->tray_width+x0),
            c->tray_rgba+4*(y1*c->tray_width+x1)};
        double k[4]={(1-dx)*(1-dy),dx*(1-dy),(1-dx)*dy,dx*dy};
        double a=0,r=0,g=0,b=0;
        for(int i=0;i<4;i++) {
            double weight=k[i]*p[i][3]/255.0;
            a+=weight; r+=weight*p[i][0]; g+=weight*p[i][1]; b+=weight*p[i][2];
        }
        if(!c->tray_alpha) { double bg=240*(1-a); r+=bg; g+=bg; b+=bg; }
        unsigned long pixel=tray_channel(img->red_mask,(unsigned int)(r+0.5))|
            tray_channel(img->green_mask,(unsigned int)(g+0.5))|
            tray_channel(img->blue_mask,(unsigned int)(b+0.5));
        if(c->tray_alpha) pixel|=(unsigned long)(a*255+0.5)<<24;
        XPutPixel(img,x,y,pixel);
    }
    XClearWindow(c->d,c->tray);
    XPutImage(c->d,c->tray,c->tray_gc,img,0,0,(wa.width-w)/2,(wa.height-h)/2,w,h);
    XDestroyImage(img); XFlush(c->d);
}
static void tray_dock(Context *c) {
    Window manager=XGetSelectionOwner(c->d,c->tray_atom);
    if(manager==c->tray_manager) return;
    c->tray_manager=manager;
    if(!manager || !c->tray) return;
    XEvent ev; memset(&ev,0,sizeof(ev)); ev.xclient.type=ClientMessage;
    ev.xclient.window=manager; ev.xclient.message_type=XInternAtom(c->d,"_NET_SYSTEM_TRAY_OPCODE",False);
    ev.xclient.format=32; ev.xclient.data.l[0]=CurrentTime; ev.xclient.data.l[1]=0;
    ev.xclient.data.l[2]=c->tray;
    XSendEvent(c->d,manager,False,NoEventMask,&ev); XFlush(c->d);
}

void *ca_create(Callback callback) {
    XSetErrorHandler(ignore_error);
    Context *c=calloc(1,sizeof(*c)); if(!c) return NULL;
    c->d=XOpenDisplay(NULL); if(!c->d) { free(c); return NULL; }
    c->screen=DefaultScreen(c->d); c->root=RootWindow(c->d,c->screen); c->callback=callback;
    c->window=XCreateSimpleWindow(c->d,c->root,-10,-10,1,1,0,0,0);
    XSelectInput(c->d,c->window,PropertyChangeMask);
    XStoreName(c->d,c->window,"ClipAngel clipboard service");
    XClassHint hint={"clipangel","ClipAngel"}; XSetClassHint(c->d,c->window,&hint);
    c->clipboard=XInternAtom(c->d,"CLIPBOARD",False);
    c->targets=XInternAtom(c->d,"TARGETS",False);
    c->incr=XInternAtom(c->d,"INCR",False);
    c->timestamp=XInternAtom(c->d,"TIMESTAMP",False);
    c->utf8=XInternAtom(c->d,"UTF8_STRING",False);
    c->name=XInternAtom(c->d,"_NET_WM_NAME",False);
    c->active_window=XInternAtom(c->d,"_NET_ACTIVE_WINDOW",False);
    char s[64]; snprintf(s,sizeof(s),"_NET_SYSTEM_TRAY_S%d",c->screen);
    c->tray_atom=XInternAtom(c->d,s,False);
    int error_base=0, major=5, minor=0;
    if(XFixesQueryExtension(c->d,&c->fixes_base,&error_base)) {
        XFixesQueryVersion(c->d,&major,&minor);
        XFixesSelectSelectionInput(c->d,c->window,c->clipboard,1|2|4);
    } else c->fixes_base=-1;
    XModifierKeymap *map=XGetModifierMapping(c->d);
    KeyCode num=XKeysymToKeycode(c->d,XK_Num_Lock);
    if(map) {
        for(int m=0;m<8;m++) for(int k=0;k<map->max_keypermod;k++)
            if(map->modifiermap[m*map->max_keypermod+k]==num && num) c->numlock|=(1U<<m);
        XFreeModifiermap(map);
    }
    XFlush(c->d); return c;
}
unsigned long ca_window(void *ctx) { return ((Context*)ctx)->window; }
unsigned long ca_owner(void *ctx) { Context *c=ctx; return XGetSelectionOwner(c->d,c->clipboard); }
int ca_has_xfixes(void *ctx) { return ((Context*)ctx)->fixes_base>=0; }
int ca_fd(void *ctx) { return ConnectionNumber(((Context*)ctx)->d); }

void ca_poll(void *ctx) {
    Context *c=ctx; int count=0;
    while(XPending(c->d) && count++<300) {
        XEvent e; XNextEvent(c->d,&e);
        if(c->fixes_base>=0 && e.type==c->fixes_base) {
            FixesSelectionEvent *f=(FixesSelectionEvent*)&e;
            c->server_time=f->timestamp;
            if(f->owner==c->window) c->owned_time=f->selection_timestamp;
            else emit(c,EV_OWNER,f->owner,NULL,0);
        } else if(e.type==SelectionRequest) selection_request(c,&e.xselectionrequest);
        else if(e.type==SelectionNotify) {
            for(int i=0;i<SLOTS;i++) {
                Incoming *r=&c->incoming[i];
                if(r->active && ((e.xselection.property && r->property==e.xselection.property) ||
                   (!e.xselection.property && r->target==e.xselection.target))) {
                    if(e.xselection.property) read_incoming(c,r,1); else incoming_done(c,r,0);
                    break;
                }
            }
        } else if(e.type==PropertyNotify) {
            if(e.xproperty.state==PropertyNewValue && e.xproperty.window==c->window) {
                for(int i=0;i<SLOTS;i++) if(c->incoming[i].active && c->incoming[i].incr &&
                    c->incoming[i].property==e.xproperty.atom) { read_incoming(c,&c->incoming[i],0); break; }
            } else if(e.xproperty.state==PropertyDelete) {
                for(int i=0;i<SLOTS;i++) if(c->outgoing[i].active &&
                    c->outgoing[i].window==e.xproperty.window && c->outgoing[i].property==e.xproperty.atom)
                    outgoing_next(c,&c->outgoing[i]);
            }
        } else if(e.type==KeyPress) {
            unsigned int state=e.xkey.state & ~(c->numlock|LockMask);
            for(int i=0;i<c->nkeys;i++) if(c->keys[i].code==(int)e.xkey.keycode && c->keys[i].modifiers==state)
                emit(c,EV_KEY,c->keys[i].id,NULL,0);
        } else if(e.type==MappingNotify) XRefreshKeyboardMapping(&e.xmapping);
        else if(e.type==Expose && e.xexpose.window==c->tray && e.xexpose.count==0) {
            tray_draw(c);
        } else if(e.type==ConfigureNotify && e.xconfigure.window==c->tray) {
            tray_draw(c);
        } else if(e.type==ButtonRelease && e.xbutton.window==c->tray &&
                  (e.xbutton.button==Button1 || e.xbutton.button==Button3)) {
            /* Tk uses another X connection. Do not request its popup grab
             * while the native pointer grab from ButtonPress is active. */
            emit(c,EV_TRAY,e.xbutton.button,NULL,0);
        }
    }
    double t=now();
    for(int i=0;i<SLOTS;i++) {
        if(c->incoming[i].active && c->incoming[i].deadline<t) incoming_done(c,&c->incoming[i],0);
        if(c->outgoing[i].active && c->outgoing[i].deadline<t) {
            free(c->outgoing[i].data); memset(&c->outgoing[i],0,sizeof(Outgoing));
        }
    }
    if(t>c->tray_check) { tray_dock(c); c->tray_check=t+2; }
}
int ca_request(void *ctx,const char *name,unsigned long token) {
    Context *c=ctx; Incoming *r=NULL; int slot;
    for(slot=0;slot<SLOTS;slot++) if(!c->incoming[slot].active) { r=&c->incoming[slot]; break; }
    if(!r) return 0;
    memset(r,0,sizeof(*r)); r->active=1; r->token=token; r->deadline=now()+5;
    r->target=XInternAtom(c->d,name,False);
    char prop[64]; snprintf(prop,sizeof(prop),"CLIPANGEL_DATA_%d",slot);
    r->property=XInternAtom(c->d,prop,False); XDeleteProperty(c->d,c->window,r->property);
    XConvertSelection(c->d,c->clipboard,r->target,r->property,c->window,CurrentTime);
    XFlush(c->d); return 1;
}
void ca_clear_formats(void *ctx) {
    Context *c=ctx;
    for(int i=0;i<c->nformats;i++) free(c->formats[i].data);
    memset(c->formats,0,sizeof(c->formats)); c->nformats=0;
}
int ca_add_format(void *ctx,const char *name,const void *data,size_t length) {
    Context *c=ctx;
    if(c->nformats>=SLOTS || length>MAX_DATA) return 0;
    Format *f=&c->formats[c->nformats]; f->data=malloc(length+1); if(!f->data) return 0;
    if(length) memcpy(f->data,data,length); f->data[length]=0;
    f->length=length; f->type=XInternAtom(c->d,name,False); c->nformats++; return 1;
}
int ca_claim(void *ctx) {
    Context *c=ctx; XSetSelectionOwner(c->d,c->clipboard,c->window,CurrentTime); XSync(c->d,False);
    return XGetSelectionOwner(c->d,c->clipboard)==c->window;
}
void ca_release(void *ctx) { Context *c=ctx; XSetSelectionOwner(c->d,c->clipboard,None,CurrentTime); XFlush(c->d); }
void ca_ungrab(void *ctx) {
    Context *c=ctx; XUngrabKey(c->d,AnyKey,AnyModifier,c->root); c->nkeys=0; XSync(c->d,False);
}
int ca_grab(void *ctx,int id,const char *key,unsigned int modifiers) {
    Context *c=ctx; KeySym sym=XStringToKeysym(key);
    KeyCode code=XKeysymToKeycode(c->d,sym);
    if(!code || c->nkeys>=24) return 0;
    unsigned int variants[4]={0,LockMask,c->numlock,LockMask|c->numlock};
    XSync(c->d,False); xerror=0;
    for(int i=0;i<4;i++) XGrabKey(c->d,code,modifiers|variants[i],c->root,False,GrabModeAsync,GrabModeAsync);
    XSync(c->d,False);
    if(xerror) {
        for(int i=0;i<4;i++) XUngrabKey(c->d,code,modifiers|variants[i],c->root);
        XSync(c->d,False); return 0;
    }
    c->keys[c->nkeys++]=(Hotkey){id,code,modifiers}; return 1;
}
static Window active(Context *c) {
    Atom type; int format; unsigned long n; unsigned char *data;
    Window w=0;
    if(property(c,c->root,c->active_window,&type,&format,&n,&data,False)) {
        if(format==32 && n) w=((unsigned long*)data)[0]; XFree(data);
    }
    if(!w) { int revert; XGetInputFocus(c->d,&w,&revert); if(w==PointerRoot) w=0; }
    return w;
}
unsigned long ca_window_info(void *ctx,unsigned long window,char *app,size_t app_len,char *title,size_t title_len) {
    Context *c=ctx; Window w=window; if(app_len) app[0]=0; if(title_len) title[0]=0;
    if(!w || w==c->root) return 0;
    XWindowAttributes attributes;
    if(!XGetWindowAttributes(c->d,w,&attributes)) return 0;
    XClassHint hint={0};
    if(XGetClassHint(c->d,w,&hint)) {
        if(app_len) snprintf(app,app_len,"%s",hint.res_class?hint.res_class:(hint.res_name?hint.res_name:""));
        if(hint.res_name) XFree(hint.res_name); if(hint.res_class) XFree(hint.res_class);
    }
    Atom type; int format; unsigned long n; unsigned char *data;
    if(property(c,w,c->name,&type,&format,&n,&data,False)) {
        if(format==8 && title_len) snprintf(title,title_len,"%.*s",(int)n,data); XFree(data);
    }
    if(title_len && !title[0]) { char *name=NULL; if(XFetchName(c->d,w,&name) && name) { snprintf(title,title_len,"%s",name); XFree(name); } }
    return w;
}
unsigned long ca_active(void *ctx,char *app,size_t app_len,char *title,size_t title_len) {
    Context *c=ctx;
    return ca_window_info(ctx,active(c),app,app_len,title,title_len);
}
int ca_activate(void *ctx,unsigned long w) {
    Context *c=ctx; if(!w || w==c->window || w==c->root) return 0;
    XWindowAttributes a; XSync(c->d,False); xerror=0;
    if(!XGetWindowAttributes(c->d,w,&a) || a.map_state!=IsViewable) return 0;
    XEvent ev; memset(&ev,0,sizeof(ev)); ev.xclient.type=ClientMessage; ev.xclient.window=w;
    ev.xclient.message_type=c->active_window; ev.xclient.format=32;
    ev.xclient.data.l[0]=2; ev.xclient.data.l[1]=c->server_time;
    XSendEvent(c->d,c->root,False,SubstructureRedirectMask|SubstructureNotifyMask,&ev);
    XRaiseWindow(c->d,w); XSetInputFocus(c->d,w,RevertToParent,CurrentTime); XSync(c->d,False);
    return !xerror;
}
static int focus_in(Context *c,Window target) {
    Window w; int revert; XGetInputFocus(c->d,&w,&revert);
    for(int i=0;i<20 && w && w!=c->root;i++) {
        if(w==target) return 1;
        Window root,parent,*children=NULL; unsigned int n;
        if(!XQueryTree(c->d,w,&root,&parent,&children,&n)) return 0;
        if(children) XFree(children); w=parent;
    }
    return 0;
}
int ca_modifiers(void *ctx) {
    Context *c=ctx; Window root,child; int rx,ry,wx,wy; unsigned int mask=0;
    XQueryPointer(c->d,c->root,&root,&child,&rx,&ry,&wx,&wy,&mask);
    return mask & (ShiftMask|ControlMask|Mod1Mask|Mod4Mask);
}
int ca_paste_key(void *ctx,unsigned long target,int mode) {
    Context *c=ctx; if(!focus_in(c,target) || ca_modifiers(c)) return 0;
    KeyCode ctrl=XKeysymToKeycode(c->d,XK_Control_L),shift=XKeysymToKeycode(c->d,XK_Shift_L);
    KeyCode key=XKeysymToKeycode(c->d,mode==2 ? XK_Insert : XK_v);
    if(!key || !ctrl || !shift || mode<0 || mode>2) return 0;
    if(mode!=2) XTestFakeKeyEvent(c->d,ctrl,True,0);
    if(mode) XTestFakeKeyEvent(c->d,shift,True,0);
    XTestFakeKeyEvent(c->d,key,True,0); XTestFakeKeyEvent(c->d,key,False,0);
    if(mode) XTestFakeKeyEvent(c->d,shift,False,0);
    if(mode!=2) XTestFakeKeyEvent(c->d,ctrl,False,0);
    XFlush(c->d); return 1;
}
int ca_paste(void *ctx,unsigned long target) { return ca_paste_key(ctx,target,0); }

int ca_type_char(void *ctx,unsigned long target,unsigned int character) {
    Context *c=ctx; if(!focus_in(c,target) || ca_modifiers(c)) return 0;
    Window root,child; int rx,ry,wx,wy; unsigned int mask=0;
    XQueryPointer(c->d,c->root,&root,&child,&rx,&ry,&wx,&wy,&mask);
    if(mask&LockMask) return 0;
    KeySym sym=(character=='\n'||character=='\r')?XK_Return:character=='\t'?XK_Tab:character;
    KeyCode code=XKeysymToKeycode(c->d,sym); if(!code) return 0;
    int per=0; KeySym *mapping=XGetKeyboardMapping(c->d,code,1,&per); int shift=0,found=0;
    for(int i=0;i<per && i<2;i++) if(mapping[i]==sym) { shift=i; found=1; break; }
    XFree(mapping); if(!found) return 0;
    KeyCode sh=XKeysymToKeycode(c->d,XK_Shift_L);
    if(shift) XTestFakeKeyEvent(c->d,sh,True,0);
    XTestFakeKeyEvent(c->d,code,True,0); XTestFakeKeyEvent(c->d,code,False,0);
    if(shift) XTestFakeKeyEvent(c->d,sh,False,0); XFlush(c->d); return 1;
}
int ca_can_type(void *ctx,unsigned int character) {
    Context *c=ctx; KeySym sym=(character=='\n'||character=='\r')?XK_Return:character=='\t'?XK_Tab:character;
    KeyCode code=XKeysymToKeycode(c->d,sym); if(!code) return 0;
    int per=0; KeySym *mapping=XGetKeyboardMapping(c->d,code,1,&per); int found=0;
    for(int i=0;i<per && i<2;i++) if(mapping[i]==sym) found=1;
    XFree(mapping); return found;
}
int ca_tray(void *ctx,const unsigned char *rgba,int width,int height) {
    Context *c=ctx; if(width<1 || width>128 || height<1 || height>128) return 0;
    size_t bytes=(size_t)width*height*4;
    unsigned char *copy=malloc(bytes); if(!copy) return 0;
    memcpy(copy,rgba,bytes); free(c->tray_rgba); c->tray_rgba=copy;
    c->tray_width=width; c->tray_height=height;
    if(!c->tray) {
        tray_choose_visual(c);
        unsigned long background=c->tray_alpha?0:0xf0f0f0;
        const int preferred=24;
        if(c->tray_alpha) {
            c->tray_colormap=XCreateColormap(c->d,c->root,c->tray_visual,AllocNone);
            XSetWindowAttributes attr={0}; attr.colormap=c->tray_colormap;
            attr.background_pixel=background; attr.border_pixel=0;
            c->tray=XCreateWindow(c->d,c->root,0,0,preferred,preferred,0,c->tray_depth,
                InputOutput,c->tray_visual,CWColormap|CWBackPixel|CWBorderPixel,&attr);
        } else {
            c->tray=XCreateSimpleWindow(c->d,c->root,0,0,preferred,preferred,0,0,background);
        }
        XSizeHints size_hints={0}; size_hints.flags=PMinSize|PBaseSize;
        size_hints.min_width=size_hints.min_height=preferred;
        size_hints.base_width=size_hints.base_height=preferred;
        XSetWMNormalHints(c->d,c->tray,&size_hints);
        XSelectInput(c->d,c->tray,ExposureMask|ButtonPressMask|ButtonReleaseMask|StructureNotifyMask);
        XStoreName(c->d,c->tray,"ClipAngel"); XClassHint hint={"clipangel","ClipAngel"}; XSetClassHint(c->d,c->tray,&hint);
        Atom embed=XInternAtom(c->d,"_XEMBED_INFO",False); unsigned long info[2]={0,1};
        XChangeProperty(c->d,c->tray,embed,embed,32,PropModeReplace,(unsigned char*)info,2);
        c->tray_gc=XCreateGC(c->d,c->tray,0,NULL);
        c->tray_manager=0;
    }
    tray_dock(c); tray_draw(c); XFlush(c->d);
    return c->tray_manager!=0;
}
int ca_tray_available(void *ctx) { Context *c=ctx; return XGetSelectionOwner(c->d,c->tray_atom)!=None; }
void ca_destroy(void *ctx) {
    Context *c=ctx; if(!c) return; ca_ungrab(c); ca_clear_formats(c);
    for(int i=0;i<SLOTS;i++) { free(c->incoming[i].data); free(c->outgoing[i].data); }
    free(c->tray_rgba);
    if(c->tray_gc) XFreeGC(c->d,c->tray_gc);
    if(c->tray) XDestroyWindow(c->d,c->tray);
    if(c->tray_colormap) XFreeColormap(c->d,c->tray_colormap);
    XDestroyWindow(c->d,c->window); XCloseDisplay(c->d); free(c);
}
