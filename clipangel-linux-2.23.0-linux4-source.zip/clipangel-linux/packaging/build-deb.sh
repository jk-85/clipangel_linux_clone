#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# Native build: run on the intended architecture. Does not invoke apt or use sudo.
set -eu
cd "$(dirname "$0")/.."
version=2.23.0~linux4
arch=$(dpkg --print-architecture)
export SOURCE_DATE_EPOCH=${SOURCE_DATE_EPOCH:-1795478400}
make all
stage="build/package"
rm -rf "$stage"
install -d "$stage/DEBIAN" "$stage/usr/bin" "$stage/usr/lib/clipangel/clipangel" \
  "$stage/usr/share/applications" "$stage/usr/share/icons/hicolor/64x64/apps" \
  "$stage/usr/share/doc/clipangel"
install -m 755 packaging/clipangel "$stage/usr/bin/clipangel"
install -m 644 clipangel/*.py clipangel/libclipangel-x11.so "$stage/usr/lib/clipangel/clipangel/"
cp -R clipangel/assets clipangel/locales "$stage/usr/lib/clipangel/clipangel/"
find "$stage/usr/lib" -type f -exec chmod 644 {} +
find "$stage/usr/lib" -type d -exec chmod 755 {} +
strip --strip-unneeded "$stage/usr/lib/clipangel/clipangel/libclipangel-x11.so"
install -m 644 packaging/clipangel.desktop "$stage/usr/share/applications/"
install -m 644 clipangel/assets/Alien-64x64.png "$stage/usr/share/icons/hicolor/64x64/apps/clipangel.png"
install -m 644 README.md LICENSE docs/*.md "$stage/usr/share/doc/clipangel/"
install -m 644 packaging/copyright "$stage/usr/share/doc/clipangel/copyright"
install -m 755 packaging/postinst packaging/postrm "$stage/DEBIAN/"
size=$(du -sk "$stage/usr" | cut -f1)
cat > "$stage/DEBIAN/control" <<EOF
Package: clipangel
Version: $version
Section: utils
Priority: optional
Architecture: $arch
Maintainer: Local ClipAngel Linux Build <noreply@localhost>
Installed-Size: $size
Depends: libc6 (>= 2.17), python3 (>= 3.10), python3-tk, python3-pil (>= 9.0.1), python3-pil.imagetk (>= 9.0.1), libx11-6, libxfixes3, libxtst6, xdg-utils
Recommends: python3-qrcode
Suggests: unrtf
Description: ClipAngel clipboard history - unofficial native Linux reimplementation
 Source-informed recreation of ClipAngel 2.23's classic two-pane interface.
 Stores text, HTML, RTF, images and file references in a private SQLite history.
 Includes terminal-aware paste, dark/light themes, optional login startup,
 favorites, search, editing, transforms, comparison, and CAC import/export.
 X11 is required for full clipboard, global-shortcut and paste-back integration.
 This is a Linux preview, not an official or feature-complete upstream release.
EOF
(cd "$stage" && find usr -type f -print0 | LC_ALL=C sort -z | xargs -0 md5sum > DEBIAN/md5sums)
find "$stage" -type d -exec chmod 00755 {} +
find "$stage" -exec touch -h -d "@$SOURCE_DATE_EPOCH" {} +
mkdir -p dist
dpkg-deb --root-owner-group -Zxz --build "$stage" "dist/clipangel_${version}_${arch}.deb"
echo "Created dist/clipangel_${version}_${arch}.deb"
