#!/usr/bin/env python3
"""Synthetic visual fixture; never reads or modifies the user's real history."""
import argparse
import io
from pathlib import Path
import sys
import tempfile
import time
import tkinter as tk
from PIL import Image,ImageDraw,ImageGrab
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from clipangel.core import Store,Settings
from clipangel.app import Application
from clipangel.dialogs import SettingsDialog


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--screenshot',type=Path,help='capture the actual window, then exit')
    parser.add_argument('--dark', action='store_true', help='use the dark application theme')
    parser.add_argument('--settings-tab', choices=('General','Appearance','History','Capture','Hotkeys','Search / View'))
    args=parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='clipangel-demo-') as directory:
        path=Path(directory); settings=Settings(path/'settings.json')
        settings.update({'DarkTheme':args.dark,'WindowGeometry':'1060x670+60+60','SplitterPosition':460,'ShowNativeTextFormatting':True,'GlobalHotkeyOpenLast':'','GlobalHotkeyOpenFavorites':'','MonitoringClipboard':False})
        store=Store(path/'demo.sqlite3')
        samples=[
            ('Meeting notes — keyboard workflows',{'text/plain':b'Keep useful snippets. Search before retyping. Mark long-lived snippets as favorites.'},False,False),
            ('SELECT id, title FROM clips ORDER BY created DESC;',{'text/plain':b'SELECT id, title\nFROM clips\nORDER BY created DESC;'},False,True),
            ('Unicode: Grüße aus München — 日本語',{'text/plain':'Grüße aus München — 日本語\nUTF-8 is preserved when copying and pasting.'.encode()},True,False),
            ('Release checklist',{'text/plain':b'Build\nRun tests\nPackage\nVerify the installed launcher'},False,False),
            ('https://example.org/documentation',{'text/plain':b'https://example.org/documentation'},False,True),
            ('JSON configuration',{'text/plain':b'{\n  "historyLimit": 30000,\n  "captureImages": true,\n  "globalShortcut": "Alt+V"\n}'},False,False),
            ('Rich text sample',{'text/plain':b'Bold and italic text retained as RTF.', 'text/rtf':br'{\rtf1\ansi\b Bold\b0 and \i italic\i0 text retained as RTF.}'},False,False),
            ('Two local file references',{'text/uri-list':b'file:///tmp/demo-notes.txt\r\nfile:///tmp/demo-report.pdf\r\n'},False,False),
            ('Useful command',{'text/plain':b'python3 -m unittest discover -s tests -v'},True,False),
            ('Text to compare — revision 1',{'text/plain':b'Capture text\nSearch history\nPaste original formatting'},False,False),
            ('Text to compare — revision 2',{'text/plain':b'Capture text and images\nSearch history\nPaste original formatting'},False,True),
        ]
        for title,data,favorite,used in samples:
            store.add(data,{'title':title,'favorite':favorite,'used':used,'app':'Demo fixture','window':'Synthetic sample data — not personal history'})
        img=Image.new('RGB',(640,360),'#edf3f8'); draw=ImageDraw.Draw(img)
        draw.rounded_rectangle((45,50,595,310),24,fill='white',outline='#7b95ad',width=3)
        draw.text((80,90),'ClipAngel image clipboard sample',fill='#1b334a')
        for i in range(7):draw.rectangle((80+i*65,240-i*15,120+i*65,270),fill='#5585ab')
        data=io.BytesIO(); img.save(data,'PNG')
        store.add({'image/png':data.getvalue()},{'title':'Image sample — 640 × 360','app':'Demo image','window':'Synthetic clipboard image'})
        rich='''<h2>ClipAngel for Linux</h2>
<p><b>Your clipboard history, close at hand.</b></p>
<p>Copy text, formatted snippets, images or files. Find them in the list and paste them into the previous application.</p>
<h3>Familiar workflows</h3>
<ul><li><b>Alt+V</b> — open clipboard history</li><li><b>Alt+B</b> — open favorite clips</li><li><b>Enter</b> — paste original formatting</li><li><b>Ctrl+Enter</b> — paste plain text</li><li><b>Ctrl+F</b> — search the history</li><li><b>F4</b> — edit a text clip</li></ul>
<h3>New in Linux preview 4</h3><p>Reliable menus and optional RTF conversion, plus terminal paste, dark theme and optional startup at login.</p>
<p><i>ClipAngel 2.23 · Linux preview 4 · X11 integration</i><br>Demonstration content only. Monitoring is paused for this screenshot.</p>'''
        current=store.add({'text/html':rich.encode()},{'title':'ClipAngel for Linux — quick start','app':'Demo fixture','window':'ClipAngel Linux — source-informed desktop recreation','favorite':True})
        root=tk.Tk(className='ClipAngel'); app=Application(root,store,settings); app.select(current)
        if args.settings_tab:
            dialog=SettingsDialog(root,settings,store.path,app.apply_settings)
            dialog.notebook.select(('General','Appearance','History','Capture','Hotkeys','Search / View').index(args.settings_tab))
        if args.screenshot:
            end=time.monotonic()+1.2
            while time.monotonic()<end:root.update(); time.sleep(.01)
            capture=dialog.win if args.settings_tab else root
            x,y=capture.winfo_rootx(),capture.winfo_rooty()
            ImageGrab.grab().crop((max(0,x-1),max(0,y-20),x+capture.winfo_width()+1,y+capture.winfo_height()+3)).save(args.screenshot)
            app.quit()
        else:root.mainloop()

if __name__=='__main__':main()
