#!/usr/bin/env python3
"""Smoke-test an extracted package, without installing into the host system."""
import argparse
import configparser
import os
from pathlib import Path
import sqlite3
import subprocess
import tempfile
import time

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('root',type=Path,help='dpkg-deb -x destination')
a=p.parse_args(); executable=a.root.resolve()/'usr/bin/clipangel'
assert executable.is_file() and os.access(executable,os.X_OK)
entry=configparser.ConfigParser(interpolation=None); entry.read(a.root/'usr/share/applications/clipangel.desktop')
assert entry['Desktop Entry']['Exec']=='clipangel --show'
assert entry['Desktop Entry']['Type']=='Application'
print(subprocess.check_output([str(executable),'--version'],text=True).strip())
with tempfile.TemporaryDirectory(prefix='clipangel-package-test-') as d:
    data=Path(d); log=open(data/'stderr.log','w+')
    cmd=[str(executable),'--data-dir',d]
    proc=subprocess.Popen(cmd,stdout=log,stderr=log,cwd='/tmp')
    try:
        deadline=time.monotonic()+8
        while not (data/'history.sqlite3').exists() and time.monotonic()<deadline and proc.poll() is None:
            time.sleep(.05)
        assert proc.poll() is None,'Packaged GUI exited during startup'
        assert (data/'history.sqlite3').exists(),'Packaged GUI did not create history'
        time.sleep(.8)
        payload='Packaged launcher / IPC / Unicode check: München 日本語'
        subprocess.run(cmd+['--add-text',payload],check=True,timeout=5)
        deadline=time.monotonic()+4
        found=False
        while time.monotonic()<deadline:
            db=sqlite3.connect(data/'history.sqlite3')
            found=bool(db.execute('SELECT id FROM clips WHERE text=?',(payload,)).fetchone())
            db.close()
            if found:break
            time.sleep(.05)
        assert found,'IPC clip was not stored by packaged application'
        subprocess.run(cmd+['--show'],check=True,timeout=5)
        subprocess.run(cmd+['--quit'],check=True,timeout=5)
        assert proc.wait(timeout=5)==0,'Packaged GUI returned a nonzero exit code'
        log.seek(0); errors=log.read(); assert not errors,errors
        assert (data/'settings.json').exists(),'Settings were not saved'
        assert (data/'history.sqlite3').stat().st_mode&0o777==0o600
        print('PASS: desktop entry, packaged startup, command-line IPC, Unicode SQLite write, show, clean exit, settings, permissions')
    finally:
        if proc.poll() is None:proc.terminate();proc.wait(timeout=5)
        log.close()
