#!/usr/bin/env python3
"""Check upgrade between extracted linux3/new packages using isolated user data.

Requires X11. This does not install packages or simulate a real desktop login.
"""
import argparse
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import tempfile
import time

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('old_root',type=Path)
parser.add_argument('new_root',type=Path)
a=parser.parse_args()
old=a.old_root.resolve()/'usr/bin/clipangel'
new=a.new_root.resolve()/'usr/bin/clipangel'

with tempfile.TemporaryDirectory(prefix='clipangel-upgrade-check-') as directory:
    home=Path(directory)
    env=dict(os.environ,HOME=str(home),XDG_CONFIG_HOME=str(home/'config'),
             XDG_DATA_HOME=str(home/'data'),XDG_RUNTIME_DIR=str(home/'run'))
    (home/'run').mkdir(mode=0o700)
    config=home/'config/clipangel/settings.json'
    dbfile=home/'data/clipangel/history.sqlite3'
    entry=home/'config/autostart/clipangel.desktop'
    payload='Existing history survives upgrade: München 日本語'
    def cli(binary,*extra):
        result=subprocess.run([str(binary),*extra],env=env,capture_output=True,text=True,check=True,timeout=6)
        assert not result.stderr,result.stderr
        return result.stdout
    def wait_for(predicate,seconds=5):
        deadline=time.monotonic()+seconds
        while time.monotonic()<deadline:
            if predicate():return
            time.sleep(.04)
        raise AssertionError('Timed out waiting for expected application state')
    def has_text(text):
        if not dbfile.exists():return False
        with sqlite3.connect(dbfile) as db:
            return bool(db.execute('SELECT id FROM clips WHERE text=?',(text,)).fetchone())
    log=(home/'process.log').open('w+')
    process=None
    try:
        print(cli(old,'--version').strip())
        process=subprocess.Popen([str(old),'--minimized'],env=env,stdout=log,stderr=log)
        wait_for(dbfile.exists);time.sleep(.4)
        cli(old,'--add-text',payload);wait_for(lambda:has_text(payload))
        cli(old,'--autostart','on')
        cli(old,'--quit');assert process.wait(timeout=6)==0;process=None
        with sqlite3.connect(dbfile) as db:
            ident=db.execute('SELECT id FROM clips WHERE text=?',(payload,)).fetchone()[0]
            db.execute('UPDATE clips SET favorite=1,used=1 WHERE id=?',(ident,))
        settings=json.loads(config.read_text())
        settings.update(FontSize=11,WordWrap=False,PasteKey='Ctrl+Shift+V',PastePolicyVersion=1,DarkTheme=True)
        config.write_text(json.dumps(settings))
        original_entry=entry.read_bytes()
        print('PASS: old binary creates history and startup entry; seeded favorite/used marks and saved dark/custom preferences')
        print(cli(new,'--version').strip())
        process=subprocess.Popen([str(new),'--minimized'],env=env,stdout=log,stderr=log)
        time.sleep(.7);assert process.poll() is None
        cli(new,'--add-text','New clip after upgrade');wait_for(lambda:has_text('New clip after upgrade'))
        with sqlite3.connect(dbfile) as db:
            assert db.execute('SELECT id,favorite,used FROM clips WHERE text=?',(payload,)).fetchone()==(ident,1,1)
        cli(new,'--show');time.sleep(.2)
        cli(new,'--quit');assert process.wait(timeout=6)==0;process=None
        settings=json.loads(config.read_text())
        assert settings['FontSize']==11
        assert settings['WordWrap'] is False
        assert settings['PasteKey']=='Ctrl+Shift+V'
        assert settings['DarkTheme'] is True
        assert settings['Autostart'] is True
        assert entry.read_bytes()==original_entry
        assert 'enabled' in cli(new,'--autostart','status')
        log.seek(0);output=log.read();assert not output,output
        print('PASS: new binary retains clip ID, favorite/used marks, dark theme, custom paste key, font/wrapping and byte-identical startup entry')
        print('PASS: new clip stored, window reopens, clean exit with empty stderr')
        print('LIMIT: extracted-package check, not dependency-resolved apt installation or real login')
    finally:
        if process is not None and process.poll() is None:
            process.terminate();process.wait(timeout=5)
        log.close()
