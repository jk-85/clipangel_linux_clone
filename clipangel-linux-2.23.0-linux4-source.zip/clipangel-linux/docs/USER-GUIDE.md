# Using ClipAngel Linux

## Capture and paste

Start ClipAngel, switch to another application and copy something normally. Press Alt+V to see the history. Double-click a row, or select it and press Enter to paste it into the previously active application. Ctrl+Enter pastes plain text; Ctrl+Shift+Enter collapses line breaks. Escape dismisses an open menu first; when no menu is open it hides/minimizes the window. Alt+B opens favorites.

ClipAngel must remain running to monitor the clipboard and serve copied payloads. It stores the clipboard when ownership changes; it does not poll and repeatedly copy the same content. By default clips above 2,000 KiB are skipped. Settings → History controls this limit.

When paste cannot safely identify or focus the destination, ClipAngel leaves the selected content on the clipboard and reports the problem. Switch to the destination and paste manually. Wayland compatibility mode always requires manual paste. Settings → General → Paste keystroke defaults to Auto: it sends Ctrl+Shift+V to GNOME Terminal, Konsole and other explicitly recognized terminal window classes, and Ctrl+V to ordinary applications. Manual overrides remain available for customized bindings. Embedded terminals inside another application may require an override. The old default migrates to Auto once; existing non-default manual settings are retained. No Enter key is added, but clipboard text can itself contain line breaks.

Global shortcuts can conflict with other programs. Change them under Settings → Hotkeys. The status bar reports registration failures. The application launcher and `clipangel --show` remain available when a shortcut cannot be registered.

## Find and organize

The bottom-left controls filter by mark and content type. Type into the search field; independent words match anywhere by default. Percent (%) matches a sequence when wildcards are enabled. Search options are available next to the field and in Settings. Ctrl+F focuses search; Ctrl+L clears filters; F3/Shift+F3 navigate matches.

Alt+Q marks selected clips as favorite; Alt+W removes the favorite mark. Favorite clips survive automatic age/count pruning. Ctrl+A selects all currently loaded rows. Use List → Load more for additional results beyond the initial 5,000-row display limit. Ctrl+Z restores the last explicit deletion within the current session.

## Preview and edit

The right pane shows the selected content. Toolbar controls change native formatting, wrapping, monospace and list columns. Native HTML/RTF preview is approximate, not a browser/Office rendering engine. Text previews are capped at 250,000 characters; paste and export retain the complete payload.

F2 edits the clip title. F4 edits plain text. For rich/file clips, the editor defaults to saving a new plain-text clip so the original survives. Text compare provides a side-by-side line view and a unified diff. Paste special joins selected texts and offers casing, tabs, spaces and line-break normalization.

Images can be fit to the pane or viewed at original size; Ctrl+mouse-wheel zooms. Save as file and Open file use the appropriate retained format. Opening external files or links is an explicit user action; previews never load remote resources automatically.

RTF preview works without extra packages: ClipAngel extracts and displays plain
text while preserving the original RTF payload. The optional `unrtf` package
adds approximate formatted RTF preview. Enable native formatting to use it.
Help → Diagnostics shows converter availability; installing it is not required
for RTF capture, original-format copy/paste, or export.

## Menus

Click a menu button once to open it, including the tall Clip menu near a screen
edge. The opening click does not select an entry beneath it. Click the desired
entry separately, or use the arrow keys and Enter. Press-drag-release selection
is also retained. Click outside or press Escape to dismiss. In a submenu, Escape
returns to the parent first. History, text-preview, image-preview and tray menus
share the same lifecycle handling.

## Appearance

Use Window → Dark theme to switch immediately, or Settings → Appearance → Use dark theme and OK. The preference is saved. Text, lists, menus, filters, editors and dialogs use the selected palette. Low-contrast source colors are adapted only in the dark preview; clipboard data, exports and images are unchanged. Window borders/title bars remain controlled by your desktop theme. Font size is also under Settings → Appearance.

## Import Windows history

In the Windows application, export selected clips as `.cac`. In Linux use Clip → Import clips and select that file. Import also accepts an unencrypted Windows `Clips` SQLite database and this port's JSON format. The application creates a local history backup before GUI imports. Keep your original Windows backup: complex rich content, encrypted databases and proprietary Windows formats have limitations described in FEATURE-PARITY.md.

Windows file paths are not translated into Linux mount paths. File clips do not contain the file bytes. Move/copy the underlying files yourself and create new file references on Linux as necessary.

Export selected records as CAC for source-derived Windows interchange or JSON for complete Linux MIME payload retention. Neither format is encrypted. CAC compatibility was tested against the inspected schema and synthetic records, not by running the original Windows executable.

## Privacy and lifecycle

Pause monitoring from the Window menu or tray before copying secrets. Common confidential/password-manager hints suppress capture when present, but many applications do not provide them. The full history is accessible to your user account. Use appropriate disk encryption and account controls; this program is not a password vault.

Close-to-tray is on by default. Window → Exit or `clipangel --quit` exits completely. Clear clipboard does not delete saved history. Delete non-favorites keeps favorites. Clear-on-exit is optional and off by default.

Open/Save/Paste-file actions may create private files in the history directory's `temporary-files` folder. These remain until explicitly removed; deleting a history row does not securely erase backups, exports, undo memory or generated files. Removing the package does not remove personal history.

Autostart is opt-in under Window → Start at login (minimized), or Settings → General → Start ClipAngel at login (minimized). It creates a per-user XDG entry for `clipangel --minimized`. `clipangel --autostart on`, `off` and `status` provide the same control from a terminal without requiring a display. The usual entry is `~/.config/autostart/clipangel.desktop`; XDG_CONFIG_HOME is honored. Uncheck the option or run `clipangel --autostart off` to remove the entry. Run these commands as your regular user, not with sudo. Package installation itself never enables startup or starts monitoring. Existing startup entries survive upgrades.

## Command line

```
clipangel --show
clipangel --favorites
clipangel --toggle-monitoring
clipangel --capture
clipangel --add-text 'A saved snippet'
clipangel --minimized
clipangel --quit
clipangel --version
clipangel --autostart on
clipangel --autostart status
clipangel --autostart off
clipangel --data-dir "$HOME/clipangel-test"
```

Commands address the instance associated with the selected data directory. Data-directory instances are isolated. The local IPC socket is accessible only through a private user directory and no TCP listener is created. Do not pass secrets through `--add-text`, because shell history and process arguments can expose them.

Help → Diagnostics shows backend, storage paths and shortcut/tray status without including clipboard contents.
