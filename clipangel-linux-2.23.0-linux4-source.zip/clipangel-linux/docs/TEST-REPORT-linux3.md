# ClipAngel Linux preview 3 — verification report

Build: `2.23.0~linux3` (amd64). Date: 2026-11-24.

## Environment

Debian 13 amd64; Python 3.13.5; Pillow 12.3.0; Tk 8.6.16; Xvfb and
Openbox, including a run using normal decorated, non-maximized windows.
This is not a Linux Mint 21.2 desktop installation.

## Automated regression suite

**78 tests passed** with the installed Pillow. The prior 49-test suite is retained
and 29 regression tests cover the new behavior. The source archive contains the
full test output under `docs/validation/linux3/automated-tests.log`.

**78 tests also passed** with application-facing Pillow resampling constants
replaced by the older integer constant layout. The image engine was still the
installed Pillow 12.3.0. This is an API compatibility simulation, **not a test
with Pillow 9.0.1 installed**. See `legacy-pillow-tests.log`.

Coverage includes:

- Unicode SQLite history/search, favorites, retention, duplicate handling,
  delete/undo, editing, transforms, CAC/JSON interchange and Windows-schema import.
- X11 text/rich/image/file transfer, XFixes notifications, shortcut conflicts,
  clipboard persistence, and approximately 3 MB binary incremental transfer.
- Native paste into an independent ordinary application process.
- Actual double-click dispatch through the history widget, and Enter/plain-text
  paste, into independent receiver processes with GNOME Terminal and Konsole
  WM_CLASS values. These receivers implement the expected Ctrl+Shift+V paste
  binding. Ordinary-editor receivers continue to get Ctrl+V; manual overrides
  remain effective. The receivers verify Unicode payloads and that no Return
  key is generated. **These are fixtures, not the real terminal binaries.**
- Saved-window metadata queries without changing focus, unknown destinations,
  exact-class matching, once-only migration of the old paste default, and
  retention of non-default overrides.
- Live light/dark switching, persisted theme settings, history/preview colors,
  new dialogs, existing combo-box popdowns, and readable black source text on a
  dark preview without changing the stored HTML bytes.
- Autostart creation/removal, per-user XDG paths with spaces/Unicode, external
  disable flags, malformed entries, write failures, and command-line operation
  without DISPLAY. Removing ClipAngel's entry preserves unrelated entries.
- Saving appearance/startup through the actual preferences dialog, not only by
  modifying in-memory settings. Unrelated settings changes do not re-enable an
  entry disabled externally while the preferences dialog was open.
- A window created withdrawn, minimized initialization, subsequent reopening and
  restoration of a usable split-pane layout.

## Compatibility and UI inspection

All application Python modules parse using Python 3.10 grammar. This is not a
Python 3.10 runtime run. The rebuilt native adapter's directly required GLIBC
symbol versions do not exceed 2.17. Package requirements still accept Pillow
9.0.1; no new runtime dependencies were added.

The actual main-window light/dark screenshots and dark General/Appearance dialogs
were generated with synthetic clips and inspected. Their desktop title bars
retain Openbox's own theme; the application does not override desktop decorations.

## Distribution and application limits

No clean dependency-resolved apt installation on Linux Mint 21.2 was performed.
GNOME Terminal and Konsole were not available in this container. Attempts to
refresh repository indexes failed because `deb.debian.org` could not be resolved.
Consequently, neither real terminal binaries nor an actual Mint logout/login
cycle was exercised. XDG startup entry validation and minimized launch behavior
are not a substitute for a full desktop-session test.

Native Wayland paste/global-shortcut support remains unimplemented. No upstream
Windows executable was run to establish full feature or import/export parity.
The corrected 2.23 baseline labeling follows the user's correction; the exact
source provenance and the archive's older assembly metadata are documented in
LINUX3-RELEASE.md.

## Extracted-package and upgrade smoke checks

Both checks passed. `extracted-package.log` records packaged launcher/version,
desktop entry, GUI startup, command-line IPC, Unicode database write, reopening,
clean shutdown and private permissions.

`upgrade-smoke.log` records an actual launch of the extracted linux2 package,
creation of a synthetic history clip, preservation of its ID and favorite mark,
and a subsequent launch of the extracted linux3 package against the same profile.
The new build retained custom font/wrapping settings, migrated the old default
paste setting to Auto, accepted another clip, honored live startup on/off changes,
reopened the window and exited without application stderr.

The upgrade check launched the command from the generated autostart entry,
relocating only the executable to the extracted test root. This verifies the
command, not an actual desktop login event.

The packaged launcher uses `/usr/bin/python3`; because this container's system
interpreter has no Pillow installed, the smoke-check environment supplied the
host's existing Pillow 12.3.0 through PYTHONPATH. The shipped launcher and package
were not changed to depend on that environment path. Normal installations use
the declared distribution packages. These extracted checks are not a clean
apt-installation test and do not verify dependency resolution.
