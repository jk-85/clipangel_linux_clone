# ClipAngel Linux preview 2 — Linux Mint 21.2 dependency fix

Version: `2.22.0~linux2` (amd64). Date: 2026-11-24.

## Problem

The preview 1 Debian package required `python3-pil (>= 9.1)` and
`python3-pil.imagetk (>= 9.1)`. Linux Mint 21.2 uses the Ubuntu 22.04 (Jammy)
package base, whose Pillow packages have upstream version 9.0.1. Its security
updates do not make that upstream version satisfy a >= 9.1 constraint.

The original application also used `Image.Resampling`, introduced in Pillow
9.1. Lowering the package dependency alone would not have corrected image
rendering on Pillow 9.0.1.

## Change

Both package dependencies now require **>= 9.0.1**. A small compatibility
module selects `Image.Resampling` when present, or the equivalent legacy
`Image` constants otherwise. Toolbar icons, preview resizing, tray icons and
QR thumbnails use this module. It does not monkey-patch Pillow internals.
The package version is increased, so the corrected package can replace
preview 1. Existing settings and clipboard history are not migrated or deleted.

Python 3.10+, X11, amd64 and the other requirements remain unchanged. This
patch makes no additional Windows-feature-parity claims.

## Installation

Download `clipangel_2.22.0~linux2_amd64.deb`. In its containing directory:

```sh
sudo apt update
sudo apt install ./clipangel_2.22.0~linux2_amd64.deb
clipangel
```

Run the application as the ordinary desktop user, not with sudo. Quit an
already running instance before restarting after the upgrade. There is no
need to uninstall/purge ClipAngel or delete its history first.

Do not force dependency checks, install packages from another Ubuntu release,
or replace the system Pillow with pip to solve this package error. The corrected
package uses the distribution's normal Pillow packages.

If installation still fails, collect the full terminal error and:

```sh
apt-cache policy python3-pil python3-pil.imagetk
```

## Verification and limits

The validation environment is Debian 13 amd64, Python 3.13.5, Pillow 12.3.0,
Tk 8.6, Xvfb and Openbox. It is **not** a Linux Mint 21.2 installation.

- All **49 tests passed** with the installed Pillow: core/history/import/export,
  X11 clipboard transfer, shortcuts, GUI capture, image preview and Unicode
  paste-back, plus three Pillow-compatibility regression tests.
- All **49 tests also passed** with application-facing resampling constants
  switched to the legacy integer layout. Image operations still ran through
  Pillow 12.3.0. This is an API compatibility simulation, **not a run with
  Pillow 9.0.1 installed**.
- All nine application Python modules passed parsing with Python 3.10 grammar.
  This syntax check is not a Python 3.10 runtime test.
- The native X11 adapter was rebuilt. Its highest directly required GLIBC
  symbol version is 2.17; it does not require this build host's newer glibc.
- The source archive includes the test logs and extracted-package smoke-test
  log under `docs/validation/linux2-*`.

**A clean apt installation and runtime test on Linux Mint 21.2 has not been
performed.** The corrected dependency constraints match the published Jammy
Pillow versions; actual installation also depends on configured repositories,
network access and the local system's package state.

## References

Linux Mint 21.2 release notes (Ubuntu 22.04 base):
https://www.linuxmint.com/rel_victoria_cinnamon.php

Ubuntu Jammy Pillow and ImageTk packages:
https://packages.ubuntu.com/jammy/python3-pil
https://packages.ubuntu.com/jammy/python3-pil.imagetk

Pillow 9.1 release notes (new resampling enum and equivalent old constants):
https://pillow.readthedocs.io/en/stable/releasenotes/9.1.0.html
