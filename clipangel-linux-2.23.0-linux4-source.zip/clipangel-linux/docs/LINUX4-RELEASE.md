# ClipAngel Linux preview 4 — menu and installation fixes

Package: `clipangel_2.23.0~linux4_amd64.deb`  
Application: `2.23.0-linux4`  
Date: 2026-11-24

## Upgrade, including an unconfigured linux3 installation

Close the old instance, install the new package with APT, then start normally:

```sh
clipangel --quit
sudo apt update
sudo apt --fix-broken install ./clipangel_2.23.0~linux4_amd64.deb
clipangel
```

Run the application as your desktop user; only the package-management commands
need sudo. Do not remove the history/configuration folders, force dependencies,
or uninstall the older package first. This package upgrades the same `clipangel`
installation. It does not reset history, favorites, theme, paste preferences or
an existing optional login-startup entry.

`dpkg -i` installs the supplied archive but does not fetch missing dependencies.
APT can resolve the other distribution dependencies. The new package no longer
requires `unrtf`, so that missing converter does not prevent configuration.
Other runtime dependencies remain required; this is not an offline bundle.

## Clip menu disappearing / accidental command activation

Reproduced on X11 with a decorated window placed low enough on screen: the tall
Clip menu is shifted upward to fit. It can overlap the original menu button;
the opening mouse release then lands on a menu entry and invokes it. In the
reproduction this could reach Delete. This was not merely a repaint problem.

Preview 4 recognizes the opening click and suppresses only its stationary
release over the newly posted menu. Deliberate subsequent selections and
press-drag-release selections remain available. Small pointer jitter is treated
as part of the opening click. The same protection applies when a context menu
is moved above a right-click near a screen edge. No menu entries were removed
or relocated to unrelated commands.

## Context menus remaining on screen

The old code called `grab_release()` immediately after `tk_popup()`. On X11,
posting is non-blocking, so this removed the grab while the menu was still open.
Outside clicks no longer reached the normal menu-dismissal bindings.

Preview 4 leaves lifecycle handling with Tk until an item is selected, Escape
is pressed, or an outside click dismisses the menu. History, text preview,
image preview and tray popups share the fix. Menus are also dismissed before
hiding/rebuilding the window; preview/image menus are reused rather than leaked.
Tk retains keyboard navigation, submenu handling and focus/grab restoration.

A related shutdown error was found during these tests: cancelling a child
widget's timer via the root deleted its Tcl command twice during destruction.
Shutdown now cancels scheduling without removing a command from the wrong owner.

## Optional RTF converter

`unrtf` moved from `Depends` to `Suggests`. The built-in RTF-to-text fallback
continues to provide Unicode text for history/search/plain-text previews when
the converter is unavailable. Original RTF bytes remain in history, copies and
exports; they are not replaced with the plain preview text. Approximate formatted
RTF preview is enabled when `unrtf` is installed and native formatting is on.

```sh
sudo apt install unrtf
```

Help → Diagnostics shows the converter status. No pip workaround or mixing of
package repositories is necessary. The existing Pillow >= 9.0.1 / Python >= 3.10
requirements remain unchanged.

## Retained behavior and limitations

The 2.23 baseline label, terminal-aware paste, light/dark themes, and optional
per-user startup remain available. Startup is still opt-in and is never enabled
by the package installer. Database schema and storage paths are unchanged.

This remains an unofficial partial reimplementation. The supplied Windows source
snapshot and its older assembly metadata are documented in LINUX3-RELEASE.md;
no additional upstream Windows source was substituted for this fix.

See TEST-REPORT.md for the exact test environment and results. Xvfb/Openbox tests
are not a clean Linux Mint 21.2/Cinnamon installation or a real login-session
test. Native Wayland integration remains unsupported.

## Technical references

- Tk popup contract: https://www.tcl-lang.org/man/tcl8.6/TkCmd/popup.htm
- Tk menu bindings: https://www.tcl-lang.org/man/tcl8.6/TkCmd/menu.htm
- Tk grab semantics: https://www.tcl-lang.org/man/tcl8.6/TkCmd/grab.htm
- APT dependency repair: https://manpages.debian.org/bookworm/apt/apt-get.8.en.html
