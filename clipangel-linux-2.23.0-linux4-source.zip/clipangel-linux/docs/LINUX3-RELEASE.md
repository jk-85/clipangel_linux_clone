# ClipAngel Linux preview 3 — terminal paste, dark theme and login startup

Package: `clipangel_2.23.0~linux3_amd64.deb`  
Application version: `2.23.0-linux3`  
Date: 2026-11-24

## Upgrade on Linux Mint 21.2

Run these commands from the directory containing the new package. Stop the
previous instance before upgrading so that its old code is not left running.

```sh
clipangel --quit
sudo apt install ./clipangel_2.23.0~linux3_amd64.deb
clipangel
```

The package is an upgrade of the earlier `clipangel` package, not a separate
application. It retains the existing history database, favorites and settings.
There is no need to uninstall, purge or delete your data. Its dependencies still
accept Mint 21.2's Pillow 9.0.1; no additional runtime dependency was introduced.
Run ClipAngel and the commands below as your regular desktop user, not with sudo.

## Terminal paste

`Settings → General → Paste keystroke → Auto` now selects the shortcut from the
**destination window's X11 application class**:

| Destination | Shortcut sent |
|---|---|
| GNOME Terminal / Konsole | Ctrl+Shift+V |
| Ordinary or unrecognized applications | Ctrl+V |

Other explicitly recognized terminal classes include MATE Terminal, Xfce Terminal,
Terminator, Tilix, QTerminal, LXTerminal, Alacritty, Kitty, GNOME Console and Ptyxis.
These additional applications have not been exercised as real binaries in this
build's validation environment. An embedded terminal inside an editor cannot be
identified from the parent application's class.

Double-click, Enter, plain-text paste, one-line paste and paste-special all use
this destination-aware policy. The clip's original source application and the
destination window's title are not used to classify the destination. The native
adapter queries the saved destination window directly before restoring focus.

The old default `Ctrl+V` setting is migrated once to `Auto`. Existing non-default
manual choices are preserved; select `Auto` explicitly after an upgrade if you
previously selected `Ctrl+Shift+V` as a workaround. Manual `Ctrl+V`, `Ctrl+Shift+V`
and `Shift+Insert` overrides remain available for customized applications.

No additional Enter/Return key is generated. A clipboard snippet can itself
contain line breaks, and terminal applications retain their normal behavior for
pasted text. Review commands before pasting them into a shell.

Native Wayland integration remains unsupported. Automatic paste still requires
an X11 session.

## Dark theme

Use **Window → Dark theme** for an immediate switch, or
**Settings → Appearance → Use dark theme**, followed by **OK**.

The saved preference applies to the history list, favorite/used/match colors,
preview, menus, filters, selection, scrollbars, editor, settings and other dialogs.
Low-contrast source text colors are adapted for the dark rich-text preview only.
Clipboard payloads, exports and image pixels are not altered. Light mode remains
available and is the default. No restart is required.

Title bars and window borders remain controlled by the desktop/window manager;
they need not match the application's selected theme.

## Optional login startup

The application already had an opt-in startup checkbox. Preview 3 adds an
immediately accessible menu toggle, a command-line control, improved detection of
entries disabled outside ClipAngel, and hidden initialization for minimized starts.

Enable **Window → Start at login (minimized)**, or
**Settings → General → Start ClipAngel at login (minimized)** and press **OK**.
Alternatively:

```sh
clipangel --autostart on
clipangel --autostart status
```

Disable it through the same checkbox or:

```sh
clipangel --autostart off
```

The per-user entry is normally `~/.config/autostart/clipangel.desktop`;
`XDG_CONFIG_HOME` is honored. Its command is `clipangel --minimized`. Startup
remains **off by default**, and the package installer does not enable it or start
monitoring as root. If previously enabled, the existing user entry remains in
place through the upgrade. Closing the main window keeps monitoring alive when
“Keep running when the main window is closed” is enabled. Alt+V reopens history.
When neither a usable global shortcut nor a tray exists, the minimized taskbar
fallback keeps the application recoverable.

The CLI manages the default installed profile and does not accept `--data-dir`
with `--autostart`. An installed `clipangel` launcher must be on the login session's
PATH. Enabling startup does not launch a second instance immediately.

## Version-label correction and source provenance

The displayed baseline, title, About text, package description and initial-preview
changelog description now use **ClipAngel 2.23**, following the supplied correction.
Historical `2.22.0-linux1` / `2.22.0-linux2` package numbers remain in the changelog
because those were the actual earlier Linux package versions.

The Windows archive supplied for this work is still snapshot
`a8c60d32d05197fa01469a9e4ba6b189c180d069`; its
`Properties/AssemblyInfo.cs` contains `AssemblyFileVersion("2.22.0.0")`. Thus the
2.23 baseline label follows the user's correction, rather than verification from
that assembly metadata. No different Windows snapshot was downloaded or silently
substituted. This update does not claim full feature parity with a newer Windows
binary.

## Validation

See `TEST-REPORT.md` and `validation/linux3/` in the source archive. The new tests
exercise X11 double-click/Enter paste into independent processes with GNOME
Terminal and Konsole window classes and their expected shortcut handling. They
are **terminal-style fixtures, not the real GNOME Terminal or Konsole binaries**.

A clean Mint 21.2 installation, actual desktop logout/login, native Wayland and
real GNOME Terminal/Konsole execution were not tested in this container. Package
repository downloads failed because the Debian repository hostname could not be
resolved. Testing did not substitute these limitations with a claim of success.

## External protocol references

- GNOME Terminal copy/paste: https://help.gnome.org/gnome-terminal/txt-copy-paste.html
- Konsole command reference: https://docs.kde.org/stable_kf6/en/konsole/konsole/commandreference.html
- XDG desktop autostart specification: https://specifications.freedesktop.org/autostart/latest/
