# ClipAngel Linux preview 4 — verification report

Build: `2.23.0~linux4` (amd64). Date: 2026-11-24.

## Environment and scope

Debian 13 amd64; Python 3.13.5; Pillow 12.3.0; Tk 8.6.16; Xvfb at
1280 × 800 with Openbox using its standard configuration (decorated,
non-maximized windows). This is **not a Linux Mint 21.2/Cinnamon installation**.
All history and input used in validation are synthetic and isolated.

## Automated regressions

**101 tests passed**, retaining the earlier 78 tests and adding 23 regressions.
`docs/validation/linux4/automated-tests.log` contains the actual output.

The new menu tests use server-side XTest mouse/key input, not only direct method
calls or Tk event_generate, to exercise real menu posting, input grabs and
window-manager placement. Coverage includes:

- Tall Clip menu overlapping its menubutton: the opening click does not invoke
  or delete a clip; minor pointer jitter is also handled.
- All menubar entries remain open; switching to another menu works.
- History popups close on a click elsewhere inside the application, on the
  desktop, or over an independent application process.
- Context actions, keyboard navigation/selection, cascades, nested Escape,
  press-drag-release selection, and right-clicks near the bottom screen edge.
- Text/image context menus are reused; repeated settings changes do not leave
  grabs behind. Dark menu colors are retained. Hiding the window unposts menus.
- Tray-menu posting/dismissal through the application handler. **No real system
  tray host was present**, so this is not a test of a desktop's tray embedding.
- Clean shutdown with a pending child-widget timer.
- The RTF converter genuinely cannot be found on the process PATH in the new
  absence tests. Unicode text fallback, preview, storage and lossless export
  work; original RTF bytes remain intact. The package builder lists unrtf only
  under Suggests and retains the Pillow 9.0.1 minimum.

The retained tests cover history/search/favorites/import/export, text/image/rich
clipboard transfers and persistence, terminal-aware paste receivers, dark-theme
and startup preferences, and approximately 3 MB incremental clipboard transfer.
The terminal receivers are fixtures with GNOME Terminal/Konsole classes and
bindings, not the actual terminal binaries.

## Baseline reproduction

`menu-before-decorated.log` records the previous menu behavior, using harmless
recording replacements for commands: clicking the Clip button while its menu
was shifted upward immediately invoked entry 2 (Delete) on mouse release.
`menu-after-decorated.log` records the patched menu remaining mapped without
invoking a command. The automated overlap regression separately verifies a real
stored clip is not removed or marked used, without replacing those commands.

## Compatibility checks

All 13 application modules parse using Python 3.10 grammar. This is a parser
compatibility check, not a Python 3.10 runtime test. The rebuilt native adapter's
direct GLIBC symbol requirements do not exceed 2.17. Shell syntax checks pass.
Mint-compatible Python >= 3.10 / Pillow >= 9.0.1 requirements are unchanged.

**All 101 tests also passed** with application-facing legacy integer Pillow
constants while still using the installed Pillow engine. The output is in
`legacy-pillow-tests.log`; it is **not a test with Pillow 9.0.1 installed**.

## Package / upgrade validation

Both extracted-package and linux3-to-linux4 upgrade checks passed. The launcher
created private storage, accepted a Unicode clip through IPC, reopened its
window, saved settings and exited without stderr. The upgrade retained the
existing clip ID, favorite/used flags, dark theme, custom paste key, font/wrapping
preferences, and byte-identical enabled autostart entry; a new clip was stored.
The logs are `extracted-package.log` and `upgrade-smoke.log`.

The final package metadata has `Suggests: unrtf` and no unrtf in `Depends`.
Package and upgrade checks use extracted packages, not a dependency-resolved
APT installation. The installed
launcher uses `/usr/bin/python3`; this container lacks the distribution Pillow
package, so smoke tests expose the existing environment's Pillow via PYTHONPATH.
The shipped launcher has not been changed to depend on that environment path.
Normal installations use the declared system packages.

## Limits

No clean dependency-resolved installation on Mint 21.2, no Cinnamon/Muffin test,
no actual desktop logout/login cycle, and no real GNOME Terminal/Konsole binary
execution were performed. A tray-host integration test was not performed.
Native Wayland integration remains unsupported. No upstream Windows executable
was run to establish full feature or format parity. The source provenance and
2.23 labeling are unchanged from the prior release.

The new unrtf absence checks confirm the application's fallback, not that every
required system dependency is bundled. This package remains dependent on the
system Python, Tk, Pillow and X11 runtime packages.
