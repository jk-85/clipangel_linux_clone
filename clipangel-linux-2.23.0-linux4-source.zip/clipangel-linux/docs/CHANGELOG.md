# 2.23.0-linux4 — 2026-11-24

- Fix the opening click selecting an unintended command when a tall menu is
  repositioned over its menubutton. Keep the Clip menu open without executing an
  entry on that same stationary click; retain deliberate press-drag-release use.
- Keep Tk's popup input grab until normal dismissal, so clicking elsewhere or
  pressing Escape closes context menus. Protect the opening right-click too.
- Share the handling across history, text, image, search-options and tray menus.
  Reuse preview/image context menus instead of allocating a new menu every time.
- Dismiss active menus before hiding the window, showing Settings or rebuilding
  menus. Preserve Tk's keyboard/cascade traversal and focus restoration.
- Fix a shutdown error when a child-widget tooltip/image timer is still pending.
- Make unrtf optional (Suggests). RTF uses the existing Unicode plain-text
  fallback without it; original RTF MIME bytes are retained. Diagnostics reports
  converter availability. No new required dependencies or database changes.
- Retain the 2.23 baseline label, automatic terminal paste, dark theme, optional
  per-user startup and Mint-compatible Pillow 9.0.1 requirement.
- Add real XTest mouse/key regression tests and absent-converter checks. See
  LINUX4-RELEASE.md and TEST-REPORT.md for validation scope and limitations.

# 2.23.0-linux3 — 2026-11-24

- Correct the displayed Windows baseline to ClipAngel 2.23 in the title, About,
  package description and original-preview description below. Earlier Linux
  package version numbers remain historical. See LINUX3-RELEASE.md for source
  provenance and the supplied archive's assembly-version metadata discrepancy.
- Add automatic destination-aware paste: Ctrl+Shift+V in GNOME Terminal/Konsole
  and other recognized terminals; Ctrl+V in ordinary applications. Preserve
  manual overrides. Migrate the former default to Auto once.
- Query the saved destination window's class directly; do not infer terminal
  identity from its title or the clip's original source application.
- Use this policy for double-click, Enter, plain-text and special paste. Ignore
  double-clicks on empty history space or column headings.
- Add a saved dark-theme option, immediately switchable in the Window menu or
  in Settings → Appearance. Theme menus, list/preview, filters and dialogs.
  Adapt low-contrast preview text without changing clipboard bytes or images.
- Retain optional per-user login startup, add a Window-menu toggle and
  --autostart on/off/status. Start minimized without an initial main-window
  flash; preserve the taskbar fallback if no working tray/shortcut exists.
- Respect startup entries disabled through the desktop's Startup Applications
  tool. Theme changes do not rewrite the autostart entry.
- Retain Pillow 9.0.1 compatibility for Linux Mint 21.2. No added runtime
  dependencies and no changes to the history database schema.
- Add regression tests for these changes. See TEST-REPORT.md for exactly what
  was and was not tested; this remains an unofficial, partial Linux port.

# 2.22.0-linux2 — 2026-11-24

- Accept the distribution's Pillow 9.0.1 packages as well as newer versions.
- Use legacy resampling constants when `Image.Resampling` is unavailable.
- Apply compatibility to toolbar icons, image preview/zoom, tray icons and QR thumbnails.
- Add regression tests for old and new resampling-constant layouts.
- Keep Python 3.10+, X11, architecture and other package requirements unchanged.
- No new feature-parity or clean-distribution installation claims.

# 2.22.0-linux1 — 2026-11-24

First unofficial source-informed Linux preview based on the supplied Windows source snapshot, using ClipAngel 2.23 as the corrected baseline label.

Classic two-pane Tk interface with original icons and translated menu resources; native X11 clipboard ownership, incremental transfers, global shortcuts and paste-back; SQLite history; search, favorites, rich/image preview, editing, transforms, comparison, CAC/SQLite import and CAC/JSON export; XEmbed tray implementation; XDG launcher/autostart; Debian packaging and automated tests.

Deliberate differences and unimplemented Windows features are documented in FEATURE-PARITY.md. This version is not an upstream release and does not claim full Windows parity.
