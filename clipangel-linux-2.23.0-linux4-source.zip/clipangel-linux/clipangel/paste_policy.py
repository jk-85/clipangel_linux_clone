# SPDX-License-Identifier: GPL-3.0-only
"""Choose a paste accelerator from the destination's X11 WM_CLASS, not its title."""
from __future__ import annotations
import re

PASTE_KEYS = ("Auto", "Ctrl+V", "Ctrl+Shift+V", "Shift+Insert")
# Exact normalized identities avoid treating an editor displaying a terminal's
# name as a terminal. Native application classes and reverse-DNS variants are
# included. Unknown applications retain ordinary Ctrl+V behavior.
TERMINAL_CLASSES = frozenset({
    "gnometerminal", "gnometerminalserver", "orggnometerminal",
    "konsole", "orgkdekonsole",
    "mateterminal", "xfce4terminal", "terminator", "tilix", "comgexperttilix",
    "qterminal", "lxterminal", "alacritty", "kitty",
    "kgx", "orggnomeconsole", "ptyxis", "orggnomeptyxis",
})


def paste_key(configured: str, window_class: str) -> str:
    """Preserve manual overrides; use terminal accelerators only in Auto mode."""
    if configured in PASTE_KEYS[1:]:
        return configured
    identity = re.sub(r"[^a-z0-9]", "", window_class.casefold())
    return "Ctrl+Shift+V" if identity in TERMINAL_CLASSES else "Ctrl+V"
