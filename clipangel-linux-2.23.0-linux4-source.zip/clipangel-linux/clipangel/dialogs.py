# SPDX-License-Identifier: GPL-3.0-only
from __future__ import annotations
import difflib
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from datetime import date
from typing import Callable
from .core import DEFAULTS, delimiter, transform
from .x11 import parse_hotkey
from .paste_policy import PASTE_KEYS
from .theme import palette_for


def window(parent, title: str, geometry: str) -> tk.Toplevel:
    dialog = tk.Toplevel(parent, class_="ClipAngel")
    dialog.title(title + " — ClipAngel")
    dialog.geometry(geometry)
    dialog.transient(parent)
    dialog.bind("<Escape>", lambda e: dialog.destroy())
    return dialog


class SettingsDialog:
    def __init__(self, parent, settings: dict, data_path: Path, save: Callable[[dict], None]):
        self.win = window(parent, "Settings", "720x620")
        self.win.minsize(650, 540)
        self.vars: dict[str, tk.Variable] = {}
        self.texts: dict[str, tk.Text] = {}
        self.save_callback = save
        self.original = settings
        self.notebook = ttk.Notebook(self.win)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)
        general = self.tab("General")
        self.check(general, "Autostart", "Start ClipAngel at login (minimized)")
        self.check(general, "CloseToTray", "Keep running when the main window is closed")
        self.check(general, "MonitoringClipboard", "Monitoring clipboard")
        self.check(general, "AlwaysOnTop", "Window always on top")
        self.check(general, "DontSendPaste", "Copy to clipboard only; do not send a paste keystroke")
        self.field(general, "PasteKey", "Paste keystroke", values=list(PASTE_KEYS))
        ttk.Label(general, text="Auto: Ctrl+Shift+V in GNOME Terminal / Konsole; Ctrl+V in other apps.",
                  wraplength=640, style="Muted.TLabel").pack(anchor="w", pady=(0, 5))
        self.check(general, "MoveCopiedClipToTop", "Move to top after use")
        self.check(general, "ClearFiltersOnClose", "Clear filters when the window is hidden")
        self.check(general, "PlaySoundOnClipCapture", "Play a notification sound on clip capture")
        self.field(general, "Language", "Menu language", values=["en", "de", "el", "es", "fr", "hi", "it", "pl", "pt-BR", "ru", "zh-Hans"])
        ttk.Label(general, text="Original menu translations are included. Linux-specific dialogs are in English.", wraplength=640).pack(anchor="w", pady=(8, 0))
        ttk.Label(general, text="Login startup is optional and per-user. Uncheck to disable it.\nThe package installer does not enable startup or start capture.",
                  wraplength=640, style="Muted.TLabel").pack(anchor="w", pady=(8, 0))
        appearance = self.tab("Appearance")
        self.check(appearance, "DarkTheme", "Use dark theme")
        self.field(appearance, "FontSize", "Font size", numeric=(8, 24))
        ttk.Label(appearance, text="The theme changes when you press OK; no restart is needed.\nYou can also switch immediately using Window → Dark theme.\n\nDark colors apply to the history, preview, menus and dialogs.\nOriginal clipboard content and image pixels are not changed.\nWindow borders and title bars remain controlled by your desktop.",
                  wraplength=640).pack(anchor="w", pady=12)
        history = self.tab("History")
        self.field(history, "HistoryDepthNumber", "Maximum non-favorite clips", numeric=(10, 500000))
        self.field(history, "HistoryDepthDays", "History depth in days (0 = unlimited)", numeric=(0, 36500))
        self.field(history, "MaxClipSizeKB", "Maximum clip size in KiB", numeric=(1, 65536))
        self.check(history, "ReplaceDuplicates", "Replace duplicate clips")
        self.check(history, "UseFormattingInDuplicateDetection", "Use formatting in duplicate detection")
        self.check(history, "ConfirmationBeforeDelete", "Confirm before deleting clips")
        self.check(history, "DeleteNonFavoriteClipsOnExit", "Delete non-favorite clips on exit")
        ttk.Label(history, text="Favorite clips are exempt from automatic age and count pruning.\nDeletion can be undone during the current session with Ctrl+Z.", wraplength=640).pack(anchor="w", pady=12)
        ttk.Label(history, text="History database", font=("DejaVu Sans", 10, "bold")).pack(anchor="w")
        e = ttk.Entry(history)
        e.insert(0, str(data_path)); e.configure(state="readonly"); e.pack(fill="x", pady=5)
        ttk.Label(history, text="The Linux database is NOT encrypted. Its directory is private to your user.\nUse full-disk encryption for protection at rest. Clipboard history can contain passwords.", style="Warning.TLabel", wraplength=640).pack(anchor="w", pady=8)
        capture = self.tab("Capture")
        self.check(capture, "CaptureImages", "Capture images")
        self.check(capture, "ReadWindowTitles", "Read source window titles")
        self.check(capture, "IgnoreExclusiveFormatClipCapture", "Respect password-manager / confidential clipboard hints")
        self.textbox(capture, "IgnoreApplicationsClipCapture", "Ignore applications (one class/name pattern per line; * is a wildcard)", 5)
        self.textbox(capture, "IgnoreUrlsClipCapture", "Ignore source URLs containing any of these lines", 4)
        ttk.Label(capture, text="Source application detection and global capture target an X11 session.\nUnder Wayland, XWayland clipboard visibility varies with the compositor.", wraplength=640).pack(anchor="w", pady=8)
        shortcuts = self.tab("Hotkeys")
        for key, label in [
            ("GlobalHotkeyOpenLast", "Open clipboard history"),
            ("GlobalHotkeyOpenFavorites", "Open favorite clips"),
            ("GlobalHotkeyPasteText", "Paste latest clip as text"),
            ("GlobalHotkeySwitchMonitoring", "Toggle clipboard monitoring"),
            ("GlobalHotkeyIncrementalPaste", "Paste next (older) clip"),
            ("GlobalHotkeyDecrementalPaste", "Paste previous (newer) clip"),
            ("GlobalHotkeyCompareLastClips", "Compare last two clips"),
            ("GlobalHotkeyForcedCapture", "Capture current clipboard"),
        ]:
            self.field(shortcuts, key, label)
        ttk.Label(shortcuts, text="Examples: Alt+V, Ctrl+Shift+V, Super+F8. Leave a field blank to disable it.\nConflicting shortcuts are reported instead of silently replacing another application's binding.", wraplength=640).pack(anchor="w", pady=12)
        search = self.tab("Search / View")
        for key, label in [
            ("SearchCaseSensitive", "Case sensitive"), ("SearchWordsIndependently", "Independent words"),
            ("SearchWildcards", '"%" as any character sequence'), ("SearchAllFields", "Search source application, window and URL too"),
            ("SearchIgnoreBigTexts", "Ignore texts larger than 100,000 characters when searching"),
            ("FilterListBySearchString", "Filter list by search string"),
            ("WordWrap", "Word wrap"), ("MonospacedFont", "Monospaced font"),
            ("ShowNativeTextFormatting", "Native formatting preview"), ("ShowSecondaryColumns", "Secondary columns"),
        ]:
            self.check(search, key, label)
        self.field(search, "DelimiterForTextJoin", "Delimiter for joining clips (\\n = newline)")
        buttons = ttk.Frame(self.win)
        buttons.pack(fill="x", padx=10, pady=(0, 10))
        ttk.Button(buttons, text="Restore defaults", command=self.defaults).pack(side="left")
        ttk.Button(buttons, text="Cancel", command=self.win.destroy).pack(side="right", padx=4)
        ttk.Button(buttons, text="OK", command=self.accept).pack(side="right", padx=4)
        self.win.grab_set()

    def tab(self, title: str):
        f = ttk.Frame(self.notebook, padding=14)
        self.notebook.add(f, text=title)
        return f

    def check(self, parent, key: str, text: str):
        variable = tk.BooleanVar(parent, self.original[key])
        self.vars[key] = variable
        ttk.Checkbutton(parent, text=text, variable=variable).pack(anchor="w", pady=3)

    def field(self, parent, key: str, label: str, numeric: tuple | None = None, values: list | None = None):
        line = ttk.Frame(parent); line.pack(fill="x", pady=5)
        ttk.Label(line, text=label, width=40).pack(side="left")
        var = tk.StringVar(parent, str(self.original[key]))
        self.vars[key] = var
        if numeric:
            entry = ttk.Spinbox(line, textvariable=var, from_=numeric[0], to=numeric[1], width=12)
        elif values:
            entry = ttk.Combobox(line, textvariable=var, values=values, state="readonly", width=20)
        else:
            entry = ttk.Entry(line, textvariable=var, width=25)
        entry.pack(side="left", fill="x", expand=True)

    def textbox(self, parent, key: str, label: str, height: int):
        ttk.Label(parent, text=label, wraplength=630).pack(anchor="w", pady=(12, 4))
        text = tk.Text(parent, height=height, wrap="word", font=("DejaVu Sans", 10), relief="sunken", borderwidth=1)
        text.insert("1.0", self.original[key]); text.pack(fill="x")
        self.texts[key] = text

    def defaults(self):
        if not messagebox.askyesno("Restore defaults", "Restore the settings shown in this dialog to their defaults?", parent=self.win):
            return
        for key, variable in self.vars.items():
            variable.set(DEFAULTS[key])
        for key, text in self.texts.items():
            text.delete("1.0", "end"); text.insert("1.0", DEFAULTS[key])

    def accept(self):
        values = {}
        try:
            for key, var in self.vars.items():
                value = var.get()
                if type(DEFAULTS[key]) is int:
                    value = int(value)
                values[key] = value
            ranges = {"HistoryDepthNumber": (10, 500000), "HistoryDepthDays": (0, 36500), "MaxClipSizeKB": (1, 65536), "FontSize": (8, 24)}
            for key, (low, high) in ranges.items():
                if not low <= values[key] <= high:
                    raise ValueError(f"{key} must be between {low} and {high}")
            keys = []
            for key, value in values.items():
                if key.startswith("GlobalHotkey") and value.strip():
                    parsed = parse_hotkey(value)
                    if parsed in keys:
                        raise ValueError(f"Shortcut is assigned twice: {value}")
                    keys.append(parsed)
            for key, text in self.texts.items():
                values[key] = text.get("1.0", "end-1c").strip()
        except (ValueError, tk.TclError) as exc:
            messagebox.showerror("Invalid setting", str(exc), parent=self.win)
            return
        self.win.grab_release()
        self.win.destroy()
        self.save_callback(values)


class TextEditor:
    def __init__(self, parent, text: str, title: str, rich: bool, save: Callable[[str, bool], None]):
        self.win = window(parent, title, "800x570")
        self.save = save
        ttk.Label(self.win, text="Edit plain text. Saving an existing rich clip replaces its formatting; save a new clip to keep the original." if rich else "Edit the clip contents below.", wraplength=760).pack(fill="x", padx=10, pady=8)
        frame = ttk.Frame(self.win); frame.pack(fill="both", expand=True, padx=10)
        self.text = tk.Text(frame, wrap="none", undo=True, font=("DejaVu Sans Mono", 10))
        scroll = ttk.Scrollbar(frame, command=self.text.yview); scroll.pack(side="right", fill="y")
        self.text.configure(yscrollcommand=scroll.set); self.text.pack(fill="both", expand=True)
        self.text.insert("1.0", text)
        buttons = ttk.Frame(self.win); buttons.pack(fill="x", padx=10, pady=10)
        self.as_new = tk.BooleanVar(self.win, rich)
        ttk.Checkbutton(buttons, text="Save as a new clip", variable=self.as_new).pack(side="left")
        ttk.Button(buttons, text="Cancel", command=self.win.destroy).pack(side="right", padx=4)
        ttk.Button(buttons, text="Save (Ctrl+S)", command=self.accept).pack(side="right", padx=4)
        self.win.bind("<Control-s>", lambda e: self.accept())
        self.text.bind("<Control-a>", lambda e: self.select_all())
        self.win.grab_set(); self.text.focus_set()

    def select_all(self):
        self.text.tag_add("sel", "1.0", "end-1c"); return "break"

    def accept(self):
        value, as_new = self.text.get("1.0", "end-1c"), self.as_new.get()
        self.win.destroy(); self.save(value, as_new)


class PasteSpecial:
    def __init__(self, parent, texts: list[str], settings: dict, action: Callable[[str, str], None]):
        self.win = window(parent, "Paste special", "760x670")
        self.settings, self.texts, self.action = settings, texts, action
        self.pending = None
        self.result = ""
        top = ttk.Frame(self.win, padding=10); top.pack(fill="x")
        ttk.Label(top, text=f"Join {len(texts)} selected clip(s) with").pack(side="left")
        self.delim = tk.StringVar(self.win, settings["DelimiterForTextJoin"])
        ttk.Entry(top, textvariable=self.delim, width=20).pack(side="left", padx=8)
        ttk.Label(top, text="\\n = newline    \\t = tab").pack(side="left")
        options = ttk.Frame(self.win); options.pack(fill="x", padx=10)
        cases = ttk.LabelFrame(options, text="Case conversion", padding=8); cases.pack(side="left", fill="both", expand=True, padx=(0, 5))
        self.case = tk.StringVar(self.win, settings["CaseConversionMode"])
        for key, label in [("unchanged", "No change"), ("upper", "UPPER CASE"), ("lower", "lower case"), ("sentence", "Sentence case"),
                           ("upper_camel", "UpperCamelCase"), ("lower_camel", "lowerCamelCase"), ("from_camel", "From camel case")]:
            ttk.Radiobutton(cases, text=label, value=key, variable=self.case).pack(anchor="w")
        normal = ttk.LabelFrame(options, text="Normalize", padding=8); normal.pack(side="left", fill="both", expand=True)
        self.eol = tk.BooleanVar(self.win, settings["ReplaceEOFWithSpace"])
        self.tabs = tk.BooleanVar(self.win, settings["ReplaceTABWithSpaces"])
        self.spaces = tk.BooleanVar(self.win, settings["NormalizeNonPrintable"])
        self.lines = tk.BooleanVar(self.win, settings["NormalizeEOF"])
        self.tab_size = tk.StringVar(self.win, str(settings["NumberOfSpacesInTab"]))
        for variable, label in [(self.eol, "Replace line breaks with spaces"), (self.tabs, "Replace tabs with spaces"),
                                (self.spaces, "Normalize spaces"), (self.lines, "Normalize empty lines")]:
            ttk.Checkbutton(normal, text=label, variable=variable).pack(anchor="w", pady=3)
        line = ttk.Frame(normal); line.pack(fill="x", pady=5)
        ttk.Label(line, text="Spaces per tab").pack(side="left")
        ttk.Spinbox(line, textvariable=self.tab_size, from_=1, to=32, width=5).pack(side="left", padx=10)
        ttk.Label(self.win, text="Preview").pack(anchor="w", padx=12, pady=(10, 4))
        self.preview = tk.Text(self.win, wrap="word", font=("DejaVu Sans Mono", 10))
        self.preview.pack(fill="both", expand=True, padx=10)
        buttons = ttk.Frame(self.win); buttons.pack(fill="x", padx=10, pady=10)
        ttk.Button(buttons, text="Create new clip", command=lambda: self.accept("new")).pack(side="left")
        ttk.Button(buttons, text="Copy", command=lambda: self.accept("copy")).pack(side="left", padx=5)
        ttk.Button(buttons, text="Cancel", command=self.win.destroy).pack(side="right")
        ttk.Button(buttons, text="Paste", command=lambda: self.accept("paste")).pack(side="right", padx=5)
        for variable in (self.delim, self.case, self.eol, self.tabs, self.spaces, self.lines, self.tab_size):
            variable.trace_add("write", self.schedule)
        self.refresh(); self.win.grab_set()

    def schedule(self, *_):
        if self.pending:
            self.win.after_cancel(self.pending)
        self.pending = self.win.after(100, self.refresh)

    def refresh(self):
        self.pending = None
        try:
            tab_size = max(1, min(32, int(self.tab_size.get()))) if self.tabs.get() else 0
        except ValueError:
            tab_size = 4
        self.result = transform(delimiter(self.delim.get()).join(self.texts), self.case.get(), self.eol.get(), tab_size, self.spaces.get(), self.lines.get())
        self.preview.configure(state="normal"); self.preview.delete("1.0", "end")
        self.preview.insert("1.0", self.result[:250000]); self.preview.configure(state="disabled")

    def accept(self, mode: str):
        self.refresh()
        self.settings.update({"DelimiterForTextJoin": self.delim.get(), "CaseConversionMode": self.case.get(),
                              "ReplaceEOFWithSpace": self.eol.get(), "ReplaceTABWithSpaces": self.tabs.get(),
                              "NormalizeNonPrintable": self.spaces.get(), "NormalizeEOF": self.lines.get()})
        try:
            self.settings["NumberOfSpacesInTab"] = max(1, min(32, int(self.tab_size.get())))
        except ValueError:
            self.settings["NumberOfSpacesInTab"] = 4
        self.win.destroy(); self.action(self.result, mode)


def compare_dialog(parent, first: dict, second: dict, copy: Callable[[str], None]):
    win = window(parent, "Text compare", "1000x650")
    before, after = first["text"], second["text"]
    if len(before) + len(after) > 500000:
        messagebox.showwarning("Text compare", "The built-in comparison is limited to 500,000 combined characters. Export the clips for comparison in an external editor.", parent=win)
        win.destroy(); return
    old, new = before.splitlines(keepends=True), after.splitlines(keepends=True)
    panes = ttk.Panedwindow(win, orient="horizontal"); panes.pack(fill="both", expand=True, padx=8, pady=8)
    widgets = []
    for clip in (first, second):
        frame = ttk.Frame(panes); panes.add(frame, weight=1)
        ttk.Label(frame, text=clip["title"][:100], wraplength=440).pack(fill="x", pady=(0, 5))
        text = tk.Text(frame, wrap="none", font=("DejaVu Sans Mono", 10), width=40)
        scroll = ttk.Scrollbar(frame, command=text.yview); scroll.pack(side="right", fill="y")
        text.configure(yscrollcommand=scroll.set); text.pack(fill="both", expand=True)
        p = palette_for(parent)
        text.tag_configure("removed", background=p["removed"], foreground=p["fg"])
        text.tag_configure("added", background=p["added"], foreground=p["fg"])
        widgets.append(text)
    matcher = difflib.SequenceMatcher(None, old, new, autojunk=True)
    changed = 0
    for operation, i, j, k, l in matcher.get_opcodes():
        tag_old = "removed" if operation in ("replace", "delete") else ""
        tag_new = "added" if operation in ("replace", "insert") else ""
        if operation != "equal":
            changed += 1
        for idx in range(max(j-i, l-k)):
            widgets[0].insert("end", (f"{i+idx+1:5}  " + old[i+idx]).rstrip("\n") + "\n" if i+idx < j else "\n", tag_old)
            widgets[1].insert("end", (f"{k+idx+1:5}  " + new[k+idx]).rstrip("\n") + "\n" if k+idx < l else "\n", tag_new)
    for text in widgets:
        text.configure(state="disabled")
    buttons = ttk.Frame(win); buttons.pack(fill="x", padx=8, pady=(0, 8))
    ttk.Label(buttons, text=f"{changed} changed block(s)").pack(side="left")
    patch = "".join(difflib.unified_diff(old, new, fromfile="Clip " + str(first["id"]), tofile="Clip " + str(second["id"])))
    ttk.Button(buttons, text="Copy unified diff", command=lambda: copy(patch)).pack(side="left", padx=10)
    ttk.Button(buttons, text="Close", command=win.destroy).pack(side="right")


def date_dialog(parent, start: str, end: str, apply: Callable[[str, str], None]):
    win = window(parent, "Filter by date", "440x220")
    frame = ttk.Frame(win, padding=16); frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="Inclusive creation dates (UTC), YYYY-MM-DD").grid(row=0, column=0, columnspan=2, pady=(0, 12))
    variables = []
    for row, (label, value) in enumerate((("From", start), ("To", end)), 1):
        ttk.Label(frame, text=label).grid(row=row, column=0, sticky="w", padx=5, pady=5)
        var = tk.StringVar(win, value); variables.append(var)
        ttk.Entry(frame, textvariable=var, width=25).grid(row=row, column=1, padx=5, pady=5)
    def accept():
        values = [var.get().strip() for var in variables]
        try:
            for value in values:
                if value: date.fromisoformat(value)
            if all(values) and values[0] > values[1]:
                raise ValueError("The start date must not be after the end date")
        except ValueError as exc:
            messagebox.showerror("Date filter", str(exc), parent=win); return
        win.destroy(); apply(*values)
    ttk.Button(frame, text="Clear", command=lambda: (win.destroy(), apply("", ""))).grid(row=3, column=0, pady=10)
    ttk.Button(frame, text="Apply", command=accept).grid(row=3, column=1, sticky="e", pady=10)
    win.grab_set()


def text_dialog(parent, title: str, content: str, size: str = "820x650"):
    win = window(parent, title, size)
    frame = ttk.Frame(win, padding=10); frame.pack(fill="both", expand=True)
    text = tk.Text(frame, wrap="word", font=("DejaVu Sans", 10), padx=8, pady=8)
    scroll = ttk.Scrollbar(frame, command=text.yview); scroll.pack(side="right", fill="y")
    text.configure(yscrollcommand=scroll.set); text.pack(fill="both", expand=True)
    text.insert("1.0", content); text.configure(state="disabled")
    ttk.Button(win, text="Close", command=win.destroy).pack(pady=(0, 10))
    return win
