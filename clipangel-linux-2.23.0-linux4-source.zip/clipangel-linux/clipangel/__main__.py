# SPDX-License-Identifier: GPL-3.0-only
"""Run with python3 -m clipangel, or the packaged 'clipangel' launcher."""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import sys
from . import __version__, autostart
from .core import Settings, Store, private_dir
from .ipc import Instance


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description='ClipAngel clipboard history — unofficial Linux port')
    parser.add_argument('--version', action='version', version='ClipAngel Linux ' + __version__)
    parser.add_argument('--data-dir', type=Path, help='isolated settings and history directory')
    actions = parser.add_mutually_exclusive_group()
    actions.add_argument('--show', action='store_true', help='open the main window (default)')
    actions.add_argument('--minimized', '-m', action='store_true', help='start hidden/minimized')
    actions.add_argument('--favorites', action='store_true', help='open favorite clips')
    actions.add_argument('--toggle-monitoring', action='store_true', help='pause/resume capture')
    actions.add_argument('--capture', action='store_true', help='force capture of the current clipboard')
    actions.add_argument('--add-text', metavar='TEXT', help='add a text clip without changing the clipboard')
    actions.add_argument('--autostart', choices=('on', 'off', 'status'), help='enable, disable or report per-user login startup')
    actions.add_argument('--quit', action='store_true', help='exit an already running instance')
    args = parser.parse_args(argv)
    if args.autostart and args.data_dir:
        parser.error('--autostart manages the default installed profile; omit --data-dir')
    os.umask(0o077)
    if args.data_dir:
        data = private_dir(args.data_dir.expanduser().resolve())
        config = data
    else:
        data = private_dir(Path(os.environ.get('XDG_DATA_HOME', str(Path.home() / '.local/share'))) / 'clipangel')
        config = private_dir(Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'clipangel')
    if args.autostart:
        try:
            if args.autostart != 'status':
                autostart.set_enabled(args.autostart == 'on')
                settings = Settings(config / 'settings.json')
                settings['Autostart'] = autostart.is_enabled()
                settings.save()
                # Notify the running GUI so its checkbox reflects CLI changes.
                peer = Instance(data)
                try:
                    if not peer.primary:
                        peer.send({'action': 'sync-autostart'})
                finally:
                    peer.close()
            print('Login autostart: ' + ('enabled (minimized)' if autostart.is_enabled() else 'disabled'))
            print('Startup entry: ' + str(autostart.entry_path()))
            return 0
        except (OSError, RuntimeError) as exc:
            print('ClipAngel: could not update login startup: ' + str(exc), file=sys.stderr)
            return 1
    action = next((key for key in ('favorites', 'toggle_monitoring', 'capture', 'quit') if getattr(args, key)), 'show').replace('_', '-')
    command = {'action': action}
    if args.add_text is not None:
        command = {'action': 'add-text', 'text': args.add_text}
    instance = None
    store = None
    try:
        instance = Instance(data)
        if not instance.primary:
            if not args.minimized:
                instance.send(command)
            instance.close()
            return 0
        if args.quit:
            instance.close()
            return 0
        # Import GUI only after lightweight CLI/IPC actions have completed.
        import tkinter as tk
        from .app import Application
        settings = Settings(config / 'settings.json')
        store = Store(data / 'history.sqlite3')
        root = tk.Tk(className='ClipAngel')
        if args.minimized:
            root.withdraw()
        app = Application(root, store, settings, instance)
        if args.minimized:
            root.after(150, app.hide)
        elif command['action'] != 'show':
            root.after(150, lambda: app.handle_command(command))
        root.mainloop()
        return 0
    except (RuntimeError, OSError, ImportError) as exc:
        print('ClipAngel: ' + str(exc), file=sys.stderr)
        print('A graphical X11 session and the dependencies listed in README.md are required.', file=sys.stderr)
        return 1
    except Exception as exc:
        if exc.__class__.__name__ == 'TclError':
            print('ClipAngel: unable to initialize the desktop interface: ' + str(exc), file=sys.stderr)
            return 1
        raise
    finally:
        if instance:
            instance.close()
        # The GUI closes its store during normal shutdown; close again only on failures.
        if store:
            try:
                store.close()
            except Exception:
                pass


if __name__ == '__main__':
    sys.exit(main())
