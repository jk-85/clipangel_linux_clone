# SPDX-License-Identifier: GPL-3.0-only
"""Typed ctypes wrapper for the small X11 adapter. No Python Xlib dependency."""
from __future__ import annotations
import ctypes as C
import os
from pathlib import Path
from typing import Callable

CALLBACK = C.CFUNCTYPE(None, C.c_int, C.c_ulong, C.c_void_p, C.c_size_t)


class X11:
    def __init__(self, event: Callable[[int, int, bytes], None]):
        self.event = event
        self._callback = CALLBACK(self._dispatch)
        library = Path(__file__).with_name("libclipangel-x11.so")
        if not library.exists():
            raise RuntimeError("The X11 adapter is missing. Run 'make' in the source folder.")
        self.lib = C.CDLL(str(library))
        signatures = {
            "ca_create": ([CALLBACK], C.c_void_p), "ca_destroy": ([C.c_void_p], None),
            "ca_poll": ([C.c_void_p], None), "ca_window": ([C.c_void_p], C.c_ulong),
            "ca_owner": ([C.c_void_p], C.c_ulong), "ca_has_xfixes": ([C.c_void_p], C.c_int),
            "ca_fd": ([C.c_void_p], C.c_int), "ca_request": ([C.c_void_p, C.c_char_p, C.c_ulong], C.c_int),
            "ca_clear_formats": ([C.c_void_p], None),
            "ca_add_format": ([C.c_void_p, C.c_char_p, C.c_void_p, C.c_size_t], C.c_int),
            "ca_claim": ([C.c_void_p], C.c_int), "ca_release": ([C.c_void_p], None),
            "ca_ungrab": ([C.c_void_p], None), "ca_grab": ([C.c_void_p, C.c_int, C.c_char_p, C.c_uint], C.c_int),
            "ca_active": ([C.c_void_p, C.c_char_p, C.c_size_t, C.c_char_p, C.c_size_t], C.c_ulong),
            "ca_window_info": ([C.c_void_p, C.c_ulong, C.c_char_p, C.c_size_t, C.c_char_p, C.c_size_t], C.c_ulong),
            "ca_activate": ([C.c_void_p, C.c_ulong], C.c_int),
            "ca_modifiers": ([C.c_void_p], C.c_int), "ca_paste": ([C.c_void_p, C.c_ulong], C.c_int),
            "ca_paste_key": ([C.c_void_p, C.c_ulong, C.c_int], C.c_int),
            "ca_can_type": ([C.c_void_p, C.c_uint], C.c_int),
            "ca_type_char": ([C.c_void_p, C.c_ulong, C.c_uint], C.c_int),
            "ca_tray": ([C.c_void_p, C.c_void_p, C.c_int, C.c_int], C.c_int),
            "ca_tray_available": ([C.c_void_p], C.c_int),
        }
        for name, (args, result) in signatures.items():
            f = getattr(self.lib, name); f.argtypes = args; f.restype = result
        self.ctx = self.lib.ca_create(self._callback)
        if not self.ctx:
            raise RuntimeError("Cannot connect to the X11 display. Run ClipAngel inside a desktop session.")
        self.window = self.lib.ca_window(self.ctx)
        self.wayland = bool(os.environ.get("WAYLAND_DISPLAY") or os.environ.get("XDG_SESSION_TYPE") == "wayland")
        self.last_error: Exception | None = None

    def _dispatch(self, event: int, token: int, ptr: int, length: int) -> None:
        try:
            self.event(event, token, C.string_at(ptr, length) if ptr and length else b"")
        except Exception as exc:
            # ctypes callbacks must never propagate through C; surface in the GUI loop.
            self.last_error = exc

    def poll(self) -> None:
        if self.ctx:
            self.lib.ca_poll(self.ctx)
        if self.last_error:
            error, self.last_error = self.last_error, None
            raise error

    def request(self, name: str, token: int) -> bool:
        return bool(self.lib.ca_request(self.ctx, name.encode(), token))

    @property
    def owner(self) -> int:
        return self.lib.ca_owner(self.ctx)

    def copy(self, formats: dict[str, bytes]) -> None:
        self.lib.ca_clear_formats(self.ctx)
        formats = dict(formats)
        plain = formats.get("text/plain")
        if plain is not None:
            formats["UTF8_STRING"] = plain
            formats["text/plain;charset=utf-8"] = plain
            formats["TEXT"] = plain
            formats["STRING"] = plain.decode("utf-8", "replace").encode("latin-1", "replace")
        if "text/rtf" in formats:
            formats["application/rtf"] = formats["text/rtf"]
        for name, value in formats.items():
            if not self.lib.ca_add_format(self.ctx, name.encode(), value, len(value)):
                raise RuntimeError("Unable to allocate clipboard data")
        if not self.lib.ca_claim(self.ctx):
            raise RuntimeError("Could not take ownership of the clipboard")

    def clear(self) -> None:
        self.lib.ca_clear_formats(self.ctx)
        self.lib.ca_release(self.ctx)

    def active(self) -> tuple[int, str, str]:
        app, title = C.create_string_buffer(512), C.create_string_buffer(4096)
        window = self.lib.ca_active(self.ctx, app, len(app), title, len(title))
        return window, app.value.decode("utf-8", "replace"), title.value.decode("utf-8", "replace")

    def window_info(self, window: int) -> tuple[int, str, str]:
        app, title = C.create_string_buffer(512), C.create_string_buffer(4096)
        found = self.lib.ca_window_info(self.ctx, window, app, len(app), title, len(title))
        return found, app.value.decode("utf-8", "replace"), title.value.decode("utf-8", "replace")

    def activate(self, window: int) -> bool:
        return bool(self.lib.ca_activate(self.ctx, window))

    def modifiers(self) -> int:
        return self.lib.ca_modifiers(self.ctx)

    def paste(self, window: int, sequence: str = "Ctrl+V") -> bool:
        mode = {"Ctrl+V": 0, "Ctrl+Shift+V": 1, "Shift+Insert": 2}.get(sequence)
        if mode is None:
            raise ValueError(f"Unsupported paste keystroke: {sequence}")
        return bool(self.lib.ca_paste_key(self.ctx, window, mode))

    def can_type(self, text: str) -> bool:
        return all(ord(c) < 128 and self.lib.ca_can_type(self.ctx, ord(c)) for c in set(text))

    def type_char(self, window: int, char: str) -> bool:
        return bool(self.lib.ca_type_char(self.ctx, window, ord(char)))

    def bind_hotkeys(self, bindings: dict[int, str]) -> list[str]:
        self.lib.ca_ungrab(self.ctx)
        errors = []
        for ident, sequence in bindings.items():
            if not sequence.strip() or sequence.strip().lower() == "no":
                continue
            try:
                key, modifiers = parse_hotkey(sequence)
                if not self.lib.ca_grab(self.ctx, ident, key.encode(), modifiers):
                    errors.append(sequence)
            except ValueError:
                errors.append(sequence)
        return errors

    def tray(self, rgba: bytes, width: int, height: int) -> bool:
        return bool(self.lib.ca_tray(self.ctx, rgba, width, height))

    @property
    def has_tray(self) -> bool:
        return bool(self.lib.ca_tray_available(self.ctx))

    def close(self) -> None:
        if self.ctx:
            self.lib.ca_destroy(self.ctx)
            self.ctx = None


def parse_hotkey(sequence: str) -> tuple[str, int]:
    parts = [p.strip() for p in sequence.split("+") if p.strip()]
    if not parts:
        raise ValueError("Empty shortcut")
    modifiers = 0
    aliases = {"ctrl": 4, "control": 4, "alt": 8, "shift": 1, "super": 64, "win": 64, "meta": 64}
    for p in parts[:-1]:
        if p.lower() not in aliases:
            raise ValueError(f"Unknown modifier: {p}")
        modifiers |= aliases[p.lower()]
    key = parts[-1]
    key = {"enter": "Return", "space": "space", "esc": "Escape", "delete": "Delete",
           "pageup": "Prior", "pagedown": "Next"}.get(key.lower(), key)
    if len(key) == 1:
        key = key.lower()
    if not modifiers and not key.startswith("F"):
        raise ValueError("A global shortcut must contain a modifier")
    return key, modifiers
