# SPDX-License-Identifier: GPL-3.0-only
"""Resampling constants for distribution Pillow 9.0.1 and newer releases."""
from PIL import Image

# Pillow 9.1 introduced Image.Resampling. Ubuntu 22.04 ships Pillow 9.0.1,
# whose equivalent constants live directly on Image. Do not monkey-patch PIL.
Resampling = getattr(Image, "Resampling", Image)
