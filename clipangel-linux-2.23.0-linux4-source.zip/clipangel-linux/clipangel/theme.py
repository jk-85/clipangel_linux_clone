# SPDX-License-Identifier: GPL-3.0-only
"""Application-wide light/dark palettes for ttk and classic Tk widgets."""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk, font as tkfont

LIGHT = {
    "bg": "#f0f0f0", "fg": "#202020", "surface": "#ffffff", "muted": "#666666",
    "border": "#b7b7b7", "hover": "#c7e0f4", "pressed": "#add1ed",
    "select": "#287fcd", "select_fg": "#ffffff", "inactive": "#d5e7f5",
    "disabled": "#8a8a8a", "disabled_bg": "#e5e5e5", "canvas": "#f5f5f5",
    "favorite": "#ffe6dc", "used": "#d2ffff", "matched": "#fff2b6",
    "search": "#fff19a", "current_match": "#ffbd54", "keyword": "#0000a0",
    "string": "#9e1a1a", "comment": "#008000", "link": "#0645ad",
    "success": "#168000", "warning": "#8b2d16", "error": "#b03020",
    "removed": "#ffe1dd", "added": "#ddf3dd", "tooltip": "#ffffdf",
}
DARK = {
    "bg": "#25282e", "fg": "#eceff4", "surface": "#191c22", "muted": "#b2bac8",
    "border": "#4b5260", "hover": "#3c485b", "pressed": "#465c78",
    "select": "#315f94", "select_fg": "#ffffff", "inactive": "#34455c",
    "disabled": "#929aa8", "disabled_bg": "#2d323a", "canvas": "#1c2027",
    "favorite": "#49363a", "used": "#234349", "matched": "#4b4526",
    "search": "#605222", "current_match": "#825824", "keyword": "#9fc2ff",
    "string": "#f2b2a0", "comment": "#a4cf92", "link": "#8ec5ff",
    "success": "#a5d88b", "warning": "#f0bc83", "error": "#ffaea5",
    "removed": "#56333c", "added": "#304b37", "tooltip": "#393f49",
}


def palette_for(widget: tk.Misc) -> dict[str, str]:
    theme = getattr(widget._root(), "_clipangel_theme", None)
    return theme.palette if theme is not None else LIGHT


def readable_color(widget: tk.Misc, color: str) -> str:
    """Keep source colors where legible; adapt low-contrast rich text in dark mode.

    This affects only the preview. Clipboard MIME bytes are never changed.
    """
    p = palette_for(widget)
    if p is not DARK:
        return color
    def luminance(value: str) -> float:
        rgb = [v / 65535 for v in widget.winfo_rgb(value)]
        rgb = [v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4 for v in rgb]
        return sum(v * weight for v, weight in zip(rgb, (.2126, .7152, .0722)))
    try:
        a, b = sorted((luminance(color), luminance(p["surface"])))
        return color if (b + .05) / (a + .05) >= 4.5 else p["fg"]
    except tk.TclError:
        return p["fg"]


class Theme:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.palette = LIGHT
        root._clipangel_theme = self
        self.style = ttk.Style(root)
        self.style.theme_use("clam")
        # Dialogs and pop-up menus created later need the same classic-widget
        # colors. ttk widgets inherit styles without per-widget overrides.
        root.bind_all("<Map>", self._mapped, add="+")

    def _mapped(self, event):
        try:
            self.widget(event.widget)
        except (tk.TclError, AttributeError):
            pass

    def apply(self, dark: bool, size: int):
        self.palette = p = DARK if dark else LIGHT
        for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont", "TkCaptionFont", "TkSmallCaptionFont"):
            try:
                tkfont.nametofont(name).configure(family="DejaVu Sans", size=size)
            except tk.TclError:
                pass
        defaults = {
            "background": p["bg"], "foreground": p["fg"],
            "activeBackground": p["hover"], "activeForeground": p["fg"],
            "selectBackground": p["select"], "selectForeground": p["select_fg"],
            "disabledForeground": p["disabled"], "insertBackground": p["fg"],
            "highlightBackground": p["border"], "highlightColor": p["select"],
            "troughColor": p["surface"],
        }
        for key, value in defaults.items():
            self.root.option_add("*" + key, value, 80)
        for kind in ("Text", "Entry", "Listbox", "Spinbox"):
            self.root.option_add(f"*{kind}.background", p["surface"], 80)
        self.root.option_add("*TCombobox*Listbox.background", p["surface"], 80)
        self.root.option_add("*TCombobox*Listbox.foreground", p["fg"], 80)
        self.root.option_add("*TCombobox*Listbox.selectBackground", p["select"], 80)
        self.root.option_add("*TCombobox*Listbox.selectForeground", p["select_fg"], 80)
        s = self.style
        s.configure(".", background=p["bg"], foreground=p["fg"],
                    bordercolor=p["border"], lightcolor=p["border"], darkcolor=p["border"],
                    troughcolor=p["surface"], selectbackground=p["select"],
                    selectforeground=p["select_fg"], fieldbackground=p["surface"],
                    insertcolor=p["fg"], font=("DejaVu Sans", size))
        s.map(".", foreground=[("disabled", p["disabled"])])
        s.configure("TButton", padding=(5, 3))
        for name in ("TButton", "TMenubutton"):
            s.map(name, background=[("disabled", p["disabled_bg"]), ("pressed", p["pressed"]), ("active", p["hover"])],
                  foreground=[("disabled", p["disabled"]), ("!disabled", p["fg"])])
        for name in ("TCheckbutton", "TRadiobutton"):
            s.configure(name, indicatorbackground=p["surface"], indicatorforeground=p["fg"])
            s.map(name, background=[("active", p["hover"]), ("!active", p["bg"])],
                  indicatorbackground=[("disabled", p["disabled_bg"]), ("selected", p["select"]), ("!selected", p["surface"])],
                  indicatorforeground=[("disabled", p["disabled"]), ("selected", p["select_fg"]), ("!selected", p["fg"])])
        for name in ("TEntry", "TCombobox", "TSpinbox"):
            s.configure(name, fieldbackground=p["surface"], foreground=p["fg"], insertcolor=p["fg"], arrowcolor=p["fg"])
            s.map(name, fieldbackground=[("disabled", p["disabled_bg"]), ("readonly", p["surface"]), ("!disabled", p["surface"])],
                  foreground=[("disabled", p["disabled"]), ("!disabled", p["fg"])],
                  background=[("active", p["hover"]), ("!active", p["bg"])],
                  arrowcolor=[("disabled", p["disabled"]), ("!disabled", p["fg"])],
                  selectbackground=[("!disabled", p["select"])], selectforeground=[("!disabled", p["select_fg"])])
        s.configure("TCombobox", padding=1, arrowsize=13)
        s.configure("Treeview", rowheight=max(20, int(size * 1.8) + 4),
                    background=p["surface"], fieldbackground=p["surface"], foreground=p["fg"], borderwidth=0)
        s.map("Treeview", background=[("selected", p["select"])], foreground=[("selected", p["select_fg"])])
        s.configure("Treeview.Heading", background=p["bg"], foreground=p["fg"])
        s.map("Treeview.Heading", background=[("active", p["hover"])])
        s.configure("Status.TLabel", font=("DejaVu Sans", max(8, size - 1)), padding=(4, 2))
        s.configure("Warning.TLabel", foreground=p["warning"])
        s.configure("Muted.TLabel", foreground=p["muted"])
        s.configure("TNotebook", background=p["bg"])
        s.configure("TNotebook.Tab", padding=(8, 5), foreground=p["fg"])
        s.map("TNotebook.Tab", background=[("selected", p["surface"]), ("active", p["hover"]), ("!selected", p["bg"])],
              foreground=[("disabled", p["disabled"]), ("!disabled", p["fg"])])
        s.configure("TLabelframe.Label", foreground=p["fg"], background=p["bg"])
        for name in ("Vertical.TScrollbar", "Horizontal.TScrollbar"):
            s.configure(name, background=p["bg"], troughcolor=p["surface"], arrowcolor=p["fg"])
            s.map(name, background=[("pressed", p["pressed"]), ("active", p["hover"])],
                  arrowcolor=[("disabled", p["disabled"]), ("!disabled", p["fg"])])
        self.walk(self.root)
        # Combobox popdowns are Tcl-only windows, not Python widgets. Existing
        # ones retain their colors unless explicitly refreshed during a switch.
        self._combobox_popdowns(self.root)

    def _combobox_popdowns(self, widget):
        if isinstance(widget, ttk.Combobox):
            try:
                name = str(widget) + ".popdown.f.l"
                if int(widget.tk.call("winfo", "exists", name)):
                    p = self.palette
                    widget.tk.call(name, "configure", "-background", p["surface"], "-foreground", p["fg"],
                                   "-selectbackground", p["select"], "-selectforeground", p["select_fg"])
            except tk.TclError:
                pass
        for child in widget.winfo_children():
            self._combobox_popdowns(child)

    def walk(self, widget):
        self.widget(widget)
        for child in widget.winfo_children():
            self.walk(child)

    def widget(self, widget):
        p = self.palette
        if isinstance(widget, ttk.Widget):
            if isinstance(widget, ttk.Treeview):
                for name in ("favorite", "used", "matched"):
                    widget.tag_configure(name, background=p[name], foreground=p["fg"])
            return
        if not isinstance(widget, tk.Misc):
            return
        options = widget.keys()
        edits = {}
        surface = isinstance(widget, (tk.Text, tk.Entry, tk.Listbox, tk.Spinbox))
        values = {
            "background": p["surface"] if surface else p["canvas"] if isinstance(widget, tk.Canvas) else p["bg"],
            "foreground": p["fg"], "activebackground": p["hover"], "activeforeground": p["fg"],
            "disabledforeground": p["disabled"], "disabledbackground": p["disabled_bg"],
            "readonlybackground": p["surface"], "insertbackground": p["fg"],
            "selectbackground": p["select"], "selectforeground": p["select_fg"],
            "inactiveselectbackground": p["inactive"], "highlightbackground": p["border"],
            "highlightcolor": p["select"], "troughcolor": p["surface"],
        }
        if getattr(widget, "_theme_role", "") == "tooltip":
            values["background"] = p["tooltip"]
        toolbar_key = getattr(widget, "_theme_pressed", None)
        if callable(toolbar_key) and toolbar_key():
            values["background"] = p["hover"]
        for key, value in values.items():
            if key in options:
                edits[key] = value
        if edits:
            widget.configure(**edits)
        if isinstance(widget, tk.Text):
            semantic = {"code_keyword": "keyword", "code_string": "string", "code_comment": "comment", "link": "link"}
            for name in widget.tag_names():
                if name in semantic:
                    widget.tag_configure(name, foreground=p[semantic[name]])
                elif name.startswith("link"):
                    widget.tag_configure(name, foreground=p["link"])
                elif name in ("search", "current_match", "removed", "added"):
                    widget.tag_configure(name, background=p[name], foreground=p["fg"])
