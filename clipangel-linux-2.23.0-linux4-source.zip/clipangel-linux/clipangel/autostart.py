# SPDX-License-Identifier: GPL-3.0-only
"""Optional per-user XDG login startup. Never writes to system-wide directories."""
from __future__ import annotations
import configparser
import os
from pathlib import Path
from .core import atomic_write


def entry_path() -> Path:
    value = os.environ.get("XDG_CONFIG_HOME", "")
    base = Path(value) if value and Path(value).is_absolute() else Path.home() / ".config"
    return base / "autostart" / "clipangel.desktop"


def is_enabled(path: Path | None = None) -> bool:
    """Also honor entries disabled in the desktop's Startup Applications UI."""
    path = path if path is not None else entry_path()
    config = configparser.ConfigParser(interpolation=None, strict=False)
    try:
        config.read_string(path.read_text("utf-8"))
        entry = config["Desktop Entry"]
        return (entry.get("Type") == "Application"
                and bool(entry.get("Exec", "").strip())
                and not entry.getboolean("Hidden", fallback=False)
                and entry.getboolean("X-GNOME-Autostart-enabled", fallback=True))
    except (OSError, ValueError, KeyError, configparser.Error):
        return False


def set_enabled(enabled: bool, path: Path | None = None) -> Path:
    """Install or remove only ClipAngel's own per-user startup entry."""
    path = path if path is not None else entry_path()
    if enabled:
        atomic_write(path, (
            "[Desktop Entry]\nVersion=1.0\nType=Application\nName=ClipAngel\n"
            "Comment=Clipboard history capture and paste tool\n"
            "Exec=clipangel --minimized\nTryExec=clipangel\nIcon=clipangel\n"
            "Terminal=false\nStartupNotify=false\nHidden=false\n"
            "X-GNOME-Autostart-enabled=true\n"
        ).encode("utf-8"))
    else:
        path.unlink(missing_ok=True)
    return path
