# SPDX-License-Identifier: GPL-3.0-only
"""Classic desktop widgets and a non-executing, offline rich-text preview."""
from __future__ import annotations
import base64
from html.parser import HTMLParser
import io
import re
import tkinter as tk
from tkinter import ttk, font as tkfont
from pathlib import Path
from typing import Callable
import warnings
from PIL import Image, ImageTk, UnidentifiedImageError
from .pillow_compat import Resampling
from .core import decode_text, rtf_to_html
from .theme import palette_for, readable_color

ASSETS = Path(__file__).with_name("assets")
Image.MAX_IMAGE_PIXELS = 32_000_000


class Icons:
    def __init__(self, root: tk.Misc):
        self.root = root
        self.cache: dict[tuple[str, int], ImageTk.PhotoImage] = {}

    def get(self, name: str, size: int = 16) -> ImageTk.PhotoImage:
        key = name, size
        if key not in self.cache:
            path = ASSETS / name
            with Image.open(path) as im:
                image = im.convert("RGBA")
                image.thumbnail((size, size), Resampling.LANCZOS)
                self.cache[key] = ImageTk.PhotoImage(image, master=self.root)
        return self.cache[key]

    def type_icon(self, kind: str) -> ImageTk.PhotoImage:
        return self.get({"text": "TypeText.png", "html": "TypeHtml.png", "rtf": "TypeRtf.png",
                         "img": "TypeImg.png", "file": "TypeFile.png"}.get(kind, "TypeUnknown.png"))


class Tooltip:
    def __init__(self, widget: tk.Widget, text: str):
        self.widget, self.text = widget, text
        self.window = None
        self.timer = None
        widget.bind("<Enter>", self.enter, add="+")
        widget.bind("<Leave>", self.leave, add="+")
        widget.bind("<ButtonPress>", self.leave, add="+")

    def enter(self, _event=None):
        self.timer = self.widget.after(600, self.show)

    def leave(self, _event=None):
        if self.timer:
            self.widget.after_cancel(self.timer)
            self.timer = None
        if self.window:
            self.window.destroy(); self.window = None

    def show(self):
        self.timer = None
        if not self.widget.winfo_exists():
            return
        self.window = tk.Toplevel(self.widget)
        self.window.wm_overrideredirect(True)
        self.window.wm_geometry(f"+{self.widget.winfo_rootx()+8}+{self.widget.winfo_rooty()+self.widget.winfo_height()+4}")
        p = palette_for(self.widget)
        label = tk.Label(self.window, text=self.text, justify="left", background=p["tooltip"], foreground=p["fg"],
                         relief="solid", borderwidth=1, font=("DejaVu Sans", 9), padx=5, pady=3)
        label._theme_role = "tooltip"
        label.pack()


class HTMLRenderer(HTMLParser):
    """A limited HTML-to-Tk renderer. It never opens URLs or executes code.

    Original HTML remains in the clipboard database and is pasted unchanged.
    This renderer is intentionally not a browser engine.
    """
    def __init__(self, widget: tk.Text, size: int, link: Callable[[str], None]):
        super().__init__(convert_charrefs=True)
        self.widget = widget
        self.size = size
        self.open_link = link
        self.stack: list[tuple[str, list[str]]] = []
        self.images: list[ImageTk.PhotoImage] = []
        self.tags: list[str] = []
        self.skip = 0
        self.pre = 0
        self.count = 0
        self.widget.tag_configure("bold", font=("DejaVu Sans", size, "bold"))
        self.widget.tag_configure("italic", font=("DejaVu Sans", size, "italic"))
        self.widget.tag_configure("underline", underline=True)
        self.widget.tag_configure("strike", overstrike=True)
        self.widget.tag_configure("code", font=("DejaVu Sans Mono", size))
        for i in range(1, 7):
            self.widget.tag_configure(f"h{i}", font=("DejaVu Sans", max(size, size + 10 - 2*i), "bold"), spacing1=8, spacing3=4)

    def newline(self):
        if self.widget.index("end-1c") != "1.0" and self.widget.get("end-2c", "end-1c") != "\n":
            self.widget.insert("end", "\n")

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]):
        if tag in ("script", "style", "head", "object", "iframe"):
            self.skip += 1
            return
        if self.skip:
            return
        attrs = dict(attrs)
        newtags = list(self.tags)
        if tag in ("p", "div", "li", "tr", "pre", "blockquote") or re.fullmatch(r"h[1-6]", tag):
            self.newline()
        if tag == "br":
            self.widget.insert("end", "\n")
            return
        if tag == "hr":
            self.newline(); self.widget.insert("end", "─" * 40 + "\n"); return
        if tag == "li":
            self.widget.insert("end", "• ")
        if tag in ("td", "th") and self.widget.index("end-1c") != "1.0":
            self.widget.insert("end", "\t")
        if tag in ("b", "strong", "th"):
            newtags.append("bold")
        if tag in ("i", "em"):
            newtags.append("italic")
        if tag == "u":
            newtags.append("underline")
        if tag in ("s", "strike", "del"):
            newtags.append("strike")
        if tag in ("code", "pre", "tt"):
            newtags.append("code")
        if tag == "pre":
            self.pre += 1
        if re.fullmatch(r"h[1-6]", tag):
            newtags.append(tag)
        if tag == "a" and attrs.get("href"):
            self.count += 1
            key = f"link{self.count}"
            url = attrs["href"]
            self.widget.tag_configure(key, foreground=palette_for(self.widget)["link"], underline=True)
            self.widget.tag_bind(key, "<Alt-Button-1>", lambda e, u=url: self.open_link(u))
            newtags.append(key)
        style = attrs.get("style", "") or ""
        styles = dict(re.findall(r"([\w-]+)\s*:\s*([^;]+)", style))
        options = {}
        color = styles.get("color", attrs.get("color"))
        if color and (re.fullmatch(r"#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?", color) or re.fullmatch(r"[a-zA-Z]{3,20}", color)):
            options["foreground"] = readable_color(self.widget, color)
        if styles.get("text-align") in ("left", "right", "center"):
            options["justify"] = styles["text-align"]
        if styles.get("font-weight") in ("bold", "700", "800", "900"):
            newtags.append("bold")
        if styles.get("font-style") == "italic":
            newtags.append("italic")
        if options:
            self.count += 1; key = f"style{self.count}"
            try:
                self.widget.tag_configure(key, **options)
                newtags.append(key)
            except tk.TclError:
                pass
        if tag == "img":
            self.inline_image(attrs)
            return
        if tag not in ("meta", "link", "input", "source", "wbr", "area", "base", "embed", "param", "col"):
            self.stack.append((tag, self.tags))
            self.tags = newtags

    def inline_image(self, attrs: dict):
        source = attrs.get("src", "") or ""
        # Remote and file-based images deliberately never load in a preview.
        if source.startswith("data:image/") and ";base64," in source and len(source) < 2_000_000:
            try:
                raw = base64.b64decode(source.split(",", 1)[1], validate=True)
                with warnings.catch_warnings():
                    warnings.simplefilter("error", Image.DecompressionBombWarning)
                    with Image.open(io.BytesIO(raw)) as im:
                        im.thumbnail((480, 300))
                        photo = ImageTk.PhotoImage(im.convert("RGBA"), master=self.widget)
                self.images.append(photo)
                self.widget.image_create("end", image=photo)
                return
            except (ValueError, OSError, Image.DecompressionBombError, Image.DecompressionBombWarning):
                pass
        if attrs.get("alt"):
            self.widget.insert("end", f"[{attrs['alt']}]", tuple(self.tags))

    def handle_endtag(self, tag: str):
        if tag in ("script", "style", "head", "object", "iframe"):
            self.skip = max(0, self.skip - 1)
            return
        if self.skip:
            return
        if tag in ("p", "div", "li", "tr", "pre", "blockquote") or re.fullmatch(r"h[1-6]", tag):
            self.newline()
        if tag == "pre":
            self.pre = max(0, self.pre - 1)
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                self.tags = self.stack[i][1]
                del self.stack[i:]
                break

    def handle_data(self, data: str):
        if not self.skip:
            if not self.pre:
                data = re.sub(r"\s+", " ", data)
            self.widget.insert("end", data, tuple(self.tags))


class Preview(ttk.Frame):
    def __init__(self, master, open_link: Callable[[str], None]):
        super().__init__(master)
        self.open_link = open_link
        self.text = tk.Text(self, relief="sunken", borderwidth=1, wrap="word", undo=False,
                            background=palette_for(self)["surface"], foreground=palette_for(self)["fg"], padx=5, pady=4, highlightthickness=0,
                            exportselection=False, selectbackground=palette_for(self)["select"], selectforeground=palette_for(self)["select_fg"])
        self.text.grid(row=0, column=0, sticky="nsew")
        self.yscroll = ttk.Scrollbar(self, orient="vertical", command=self.text.yview)
        self.xscroll = ttk.Scrollbar(self, orient="horizontal", command=self.text.xview)
        self.yscroll.grid(row=0, column=1, sticky="ns")
        self.xscroll.grid(row=1, column=0, sticky="ew")
        self.text.configure(yscrollcommand=self.yscroll.set, xscrollcommand=self.xscroll.set)
        self.canvas = tk.Canvas(self, background=palette_for(self)["canvas"], highlightthickness=0)
        self.canvas.bind("<Configure>", self._resize)
        self.canvas.bind("<Control-Button-4>", lambda e: self.zoom(1.2))
        self.canvas.bind("<Control-Button-5>", lambda e: self.zoom(1/1.2))
        self.canvas.bind("<Button-4>", lambda e: self.canvas.yview_scroll(-3, "units"))
        self.canvas.bind("<Button-5>", lambda e: self.canvas.yview_scroll(3, "units"))
        self.rowconfigure(0, weight=1); self.columnconfigure(0, weight=1)
        self.image = None; self.photo = None; self.mode = "text"; self.scale = None
        self.renderer = None
        self.font_size = 10
        self.resize_after = None
        self.matches: list[tuple[str, str]] = []
        self.match_index = -1
        self.text.tag_configure("search", background=palette_for(self)["search"], foreground=palette_for(self)["fg"])
        self.text.tag_configure("current_match", background=palette_for(self)["current_match"], foreground=palette_for(self)["fg"])
        self.text.tag_configure("code_keyword", foreground=palette_for(self)["keyword"])
        self.text.tag_configure("code_string", foreground=palette_for(self)["string"])
        self.text.tag_configure("code_comment", foreground=palette_for(self)["comment"])
        self.text.tag_configure("link", foreground=palette_for(self)["link"], underline=True)
        self.text.bind("<Alt-Button-1>", self._link_at)
        self.text.bind("<Control-a>", lambda e: self.select_all())

    def select_all(self):
        self.text.tag_add("sel", "1.0", "end-1c")
        return "break"

    def _link_at(self, event):
        index = self.text.index(f"@{event.x},{event.y}")
        for start, end in zip(self.text.tag_ranges("link")[::2], self.text.tag_ranges("link")[1::2]):
            if self.text.compare(start, "<=", index) and self.text.compare(index, "<", end):
                self.open_link(self.text.get(start, end)); return "break"
        return None

    def _text_mode(self):
        self.mode = "text"; self.canvas.grid_remove(); self.text.grid()
        self.yscroll.configure(command=self.text.yview); self.xscroll.configure(command=self.text.xview)
        self.text.configure(state="normal"); self.text.delete("1.0", "end")
        self.renderer = None
        for name in self.text.tag_names():
            if name.startswith(("style", "link")) and name != "link":
                self.text.tag_delete(name)

    def show_empty(self, message: str):
        self._text_mode()
        self.text.configure(font=("DejaVu Sans", 10))
        self.text.insert("1.0", message)
        self.text.configure(state="disabled")

    def show(self, clip: dict, formats: dict[str, bytes], settings: dict):
        self.font_size = settings["FontSize"]
        self.matches = []; self.match_index = -1
        if clip["kind"] == "img":
            data = next((v for k, v in formats.items() if k.startswith("image/")), b"")
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("error", Image.DecompressionBombWarning)
                    with Image.open(io.BytesIO(data)) as im:
                        self.image = im.convert("RGBA")
                self.mode = "image"; self.scale = None
                self.text.grid_remove(); self.canvas.grid(row=0, column=0, sticky="nsew")
                self.yscroll.configure(command=self.canvas.yview); self.xscroll.configure(command=self.canvas.xview)
                self.canvas.configure(xscrollcommand=self.xscroll.set, yscrollcommand=self.yscroll.set)
                self.after_idle(self._render_image)
                return
            except (OSError, ValueError, Image.DecompressionBombError, Image.DecompressionBombWarning):
                self.show_empty("The stored image could not be previewed safely.\nThe original bytes are still available for export.")
                return
        self._text_mode()
        family = "DejaVu Sans Mono" if settings["MonospacedFont"] else "DejaVu Sans"
        self.text.configure(font=(family, self.font_size), wrap="word" if settings["WordWrap"] else "none")
        rich = ""
        if settings["ShowNativeTextFormatting"]:
            if "text/html" in formats:
                rich = decode_text(formats["text/html"])
            elif "text/rtf" in formats:
                rich = rtf_to_html(formats["text/rtf"])
        if rich:
            self.renderer = HTMLRenderer(self.text, self.font_size, self.open_link)
            try:
                self.renderer.feed(rich[:250000])
            except (ValueError, tk.TclError):
                self.text.delete("1.0", "end"); self.text.insert("end", clip["text"][:250000])
        else:
            self.text.insert("end", clip["text"][:250000])
            self._syntax(clip["text"][:50000])
        if max(len(rich), len(clip["text"])) > 250000:
            self.text.insert("end", "\n\n[Preview limited to 250,000 characters. Copy/paste and export preserve the full clip.]")
        self._links()
        self.text.configure(state="disabled")
        self.text.yview_moveto(0); self.text.xview_moveto(0)

    def _syntax(self, text: str):
        if not re.search(r"<[/!?\w]|[{};]|^\s*(def |class |import |SELECT |public )", text):
            return
        rules = [(r"</?[\w:.-]+|\b(?:class|public|private|return|def|import|from|if|else|for|while|using|var|int|string|void|new|const|true|false|null|SELECT|FROM|WHERE)\b", "code_keyword"),
                 (r'''"[^"\n]*"|'[^'\n]*' ''', "code_string"),
                 (r"//[^\n]*|#[^\n]*|<!--[\s\S]*?-->", "code_comment")]
        for pattern, tag in rules:
            for m in re.finditer(pattern.strip(), text):
                self.text.tag_add(tag, f"1.0+{m.start()}c", f"1.0+{m.end()}c")

    def _links(self):
        content = self.text.get("1.0", "end-1c")
        for m in re.finditer(r"https?://[^\s<>\"']+", content):
            self.text.tag_add("link", f"1.0+{m.start()}c", f"1.0+{m.end()}c")

    def search(self, query: str, sensitive: bool = False):
        self.matches = []; self.match_index = -1
        self.text.tag_remove("search", "1.0", "end")
        self.text.tag_remove("current_match", "1.0", "end")
        if self.mode != "text" or not query.strip():
            return
        content = self.text.get("1.0", "end-1c")
        terms = [t for t in re.split(r"[\s%]+", query.strip()) if t]
        if not terms:
            return
        pattern = "|".join(re.escape(t) for t in terms)
        for m in re.finditer(pattern, content, 0 if sensitive else re.I):
            start, end = f"1.0+{m.start()}c", f"1.0+{m.end()}c"
            self.matches.append((start, end)); self.text.tag_add("search", start, end)
            if len(self.matches) >= 5000:
                break
        if self.matches:
            self.find(1)

    def find(self, direction: int) -> bool:
        if not self.matches:
            return False
        self.match_index = (self.match_index + direction) % len(self.matches)
        start, end = self.matches[self.match_index]
        self.text.tag_remove("current_match", "1.0", "end")
        self.text.tag_add("current_match", start, end); self.text.see(start)
        return True

    def selected_text(self) -> str:
        if self.mode != "text":
            return ""
        try:
            return self.text.get("sel.first", "sel.last")
        except tk.TclError:
            return ""

    def _resize(self, _event=None):
        if self.resize_after:
            self.after_cancel(self.resize_after)
        self.resize_after = self.after(70, self._render_image)

    def _render_image(self):
        self.resize_after = None
        if self.mode != "image" or self.image is None:
            return
        width, height = max(50, self.canvas.winfo_width() - 10), max(50, self.canvas.winfo_height() - 10)
        scale = self.scale if self.scale is not None else min(1, width / self.image.width, height / self.image.height)
        size = (max(1, int(self.image.width * scale)), max(1, int(self.image.height * scale)))
        if size[0] * size[1] > 25_000_000:
            return
        self.photo = ImageTk.PhotoImage(self.image.resize(size, Resampling.LANCZOS), master=self.canvas)
        self.canvas.delete("all")
        x, y = max(5, (width-size[0])//2), max(5, (height-size[1])//2)
        self.canvas.create_image(x, y, anchor="nw", image=self.photo)
        self.canvas.configure(scrollregion=(0, 0, max(width, size[0]+10), max(height, size[1]+10)))

    def zoom(self, factor: float):
        if self.image is None:
            return "break"
        current = self.scale if self.scale is not None else min(1, max(50, self.canvas.winfo_width()-10)/self.image.width,
                                                               max(50, self.canvas.winfo_height()-10)/self.image.height)
        self.scale = max(.05, min(8, current*factor)); self._render_image()
        return "break"

    def image_fit(self):
        self.scale = None; self._render_image()

    def image_original(self):
        self.scale = 1.; self._render_image()
