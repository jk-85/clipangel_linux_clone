# SPDX-License-Identifier: GPL-3.0-only
"""Storage, clip normalization, search, transforms and Windows interchange.

This module is independent of both Tk and X11 and is suitable for unit tests.
Clipboard data is private user data: do not log clip contents.
"""
from __future__ import annotations

import base64
from contextlib import contextmanager
import hashlib
import html
from html.parser import HTMLParser
import io
import json
import os
from pathlib import Path
import re
import shlex
import sqlite3
import subprocess
import tempfile
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable, Mapping
from urllib.parse import unquote, urlparse
import xml.etree.ElementTree as ET

MAX_PAYLOAD = 64 * 1024 * 1024
MAX_IMPORT = 128 * 1024 * 1024
DEFAULTS: dict[str, Any] = {
    "HistoryDepthNumber": 30000, "HistoryDepthDays": 0, "MaxClipSizeKB": 2000,
    "GlobalHotkeyOpenLast": "Alt+V", "GlobalHotkeyOpenFavorites": "Alt+B",
    "GlobalHotkeyPasteText": "", "GlobalHotkeySwitchMonitoring": "",
    "GlobalHotkeyIncrementalPaste": "", "GlobalHotkeyDecrementalPaste": "",
    "GlobalHotkeyCompareLastClips": "", "GlobalHotkeyForcedCapture": "",
    "Autostart": False, "DarkTheme": False, "Language": "en", "WordWrap": True,
    "MoveCopiedClipToTop": False, "MonospacedFont": False,
    "ShowNativeTextFormatting": False, "ShowSecondaryColumns": False,
    "SearchCaseSensitive": False, "SearchWordsIndependently": True,
    "SearchWildcards": True, "SearchAllFields": False,
    "SearchIgnoreBigTexts": False, "FilterListBySearchString": True,
    "MonitoringClipboard": True, "CaptureImages": True,
    "ReplaceDuplicates": True, "UseFormattingInDuplicateDetection": False,
    "ReadWindowTitles": True, "IgnoreApplicationsClipCapture": "",
    "IgnoreUrlsClipCapture": "", "IgnoreExclusiveFormatClipCapture": True,
    "DeleteNonFavoriteClipsOnExit": False, "ConfirmationBeforeDelete": False,
    "ClearFiltersOnClose": False, "DelimiterForTextJoin": "\\n",
    "CaseConversionMode": "unchanged", "NumberOfSpacesInTab": 4,
    "ReplaceEOFWithSpace": False, "ReplaceTABWithSpaces": False,
    "NormalizeNonPrintable": False, "NormalizeEOF": False,
    "PasteKey": "Auto", "PastePolicyVersion": 1, "DontSendPaste": False, "AlwaysOnTop": False, "CloseToTray": True,
    "FontSize": 10, "WindowGeometry": "980x600", "SplitterPosition": 460,
    "LastFilterValues": [], "PlaySoundOnClipCapture": False,
}


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def private_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    path.chmod(0o700)
    return path


def atomic_write(path: Path, data: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix="." + path.name + ".", dir=path.parent)
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, "wb") as out:
            out.write(data)
            out.flush()
            os.fsync(out.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


class Settings(dict):
    def __init__(self, path: Path):
        super().__init__(DEFAULTS)
        self.path = path
        self.warning = ""
        if path.exists():
            try:
                obj = json.loads(path.read_text("utf-8"))
                if not isinstance(obj, dict):
                    raise ValueError("settings must be a JSON object")
                # The first two previews defaulted to Ctrl+V for all targets.
                # Upgrade that old default to target-aware automatic paste once;
                # preserve non-default manual overrides and future explicit Ctrl+V.
                if "PastePolicyVersion" not in obj and obj.get("PasteKey", "Ctrl+V") == "Ctrl+V":
                    obj["PasteKey"] = "Auto"
                for key, value in obj.items():
                    if key in DEFAULTS and type(value) is type(DEFAULTS[key]):
                        self[key] = value
            except (ValueError, OSError) as exc:
                self.warning = f"Settings could not be read: {exc}. Defaults are in use."
        self["HistoryDepthNumber"] = max(10, min(500000, self["HistoryDepthNumber"]))
        self["MaxClipSizeKB"] = max(1, min(MAX_PAYLOAD // 1024, self["MaxClipSizeKB"]))
        self["FontSize"] = max(8, min(24, self["FontSize"]))
        if self["PasteKey"] not in ("Auto", "Ctrl+V", "Ctrl+Shift+V", "Shift+Insert"):
            self["PasteKey"] = "Auto"
        self["PastePolicyVersion"] = 1

    def save(self) -> None:
        private_dir(self.path.parent)
        if self.warning and self.path.exists():
            backup = self.path.with_name(self.path.name + ".unreadable-backup")
            if not backup.exists():
                atomic_write(backup, self.path.read_bytes())
            self.warning = ""
        atomic_write(self.path, (json.dumps(self, ensure_ascii=False, indent=2) + "\n").encode())


class PlainHTML(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.skip = 0

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag in ("script", "style", "head"):
            self.skip += 1
        elif not self.skip and tag in ("br", "p", "div", "li", "tr", "h1", "h2", "h3", "pre"):
            self.parts.append("\n")
        elif not self.skip and tag in ("td", "th"):
            self.parts.append("\t")

    def handle_endtag(self, tag: str) -> None:
        if tag in ("script", "style", "head"):
            self.skip = max(0, self.skip - 1)
        elif not self.skip and tag in ("p", "div", "li", "tr", "pre"):
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self.skip:
            self.parts.append(data)


def html_text(value: str) -> str:
    parser = PlainHTML()
    parser.feed(value)
    return re.sub(r"\n[ \t]*\n(?:[ \t]*\n)+", "\n\n", "".join(parser.parts)).strip()


def decode_text(data: bytes) -> str:
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16", "replace").rstrip("\x00")
    if data[:100].count(b"\x00") > 10:
        return data.decode("utf-16-le", "replace").rstrip("\x00")
    return data.decode("utf-8-sig", "replace").rstrip("\x00")


def html_fragment(value: str) -> str:
    start = value.find("<!--StartFragment-->")
    end = value.find("<!--EndFragment-->")
    if 0 <= start < end:
        return value[start + len("<!--StartFragment-->"):end]
    if re.match(r"Version:\d", value):
        start = value.find("<")
        return value[start:] if start >= 0 else value
    return value


def rtf_to_html(data: bytes) -> str:
    """Optional local RTF formatting. Return empty for the plain-text fallback.

    unrtf is a suggested package, not required to capture, store or paste RTF.
    This never invokes a shell or downloads data. Original RTF bytes are kept.
    """
    if len(data) > 8 * 1024 * 1024:
        return ""
    try:
        result = subprocess.run(["unrtf", "--html"], input=data, stdout=subprocess.PIPE,
                                stderr=subprocess.DEVNULL, timeout=4, check=True)
        if len(result.stdout) <= MAX_PAYLOAD:
            return result.stdout.decode("utf-8", "replace")
    except (FileNotFoundError, subprocess.SubprocessError, OSError):
        pass
    return ""


def rtf_text(value: str) -> str:
    # A conservative plain-text fallback. The original RTF bytes remain intact.
    out: list[str] = []
    stack: list[tuple[bool, int]] = []
    skip = False
    uc = 1
    fallback = 0
    tokens = re.finditer(r"\\([a-zA-Z]+)(-?\d+)? ?|\\'([0-9a-fA-F]{2})|\\([^a-zA-Z])|([{}])|([^\\{}]+)", value)
    destinations = {"fonttbl", "colortbl", "stylesheet", "info", "pict", "object", "header", "footer", "filetbl", "datastore", "generator"}
    for m in tokens:
        word, number, hexadecimal, escaped, brace, plain = m.groups()
        if brace == "{":
            stack.append((skip, uc))
        elif brace == "}":
            skip, uc = stack.pop() if stack else (False, 1)
            fallback = 0
        elif escaped == "*":
            skip = True
        elif word in destinations:
            skip = True
        elif skip:
            continue
        elif word == "uc":
            uc = max(0, min(10, int(number or 1)))
        elif word == "u":
            out.append(chr(int(number or 0) & 0xFFFF))
            fallback = uc
        elif word in ("par", "line"):
            out.append("\n")
        elif word == "tab":
            out.append("\t")
        elif hexadecimal:
            if fallback:
                fallback -= 1
            else:
                out.append(bytes.fromhex(hexadecimal).decode("cp1252", "replace"))
        elif escaped in ("{", "}", "\\"):
            if fallback:
                fallback -= 1
            else:
                out.append(escaped)
        elif escaped == "~":
            out.append("\u00a0")
        elif plain:
            plain = plain.replace("\r", "").replace("\n", "")
            used = min(fallback, len(plain))
            fallback -= used
            out.append(plain[used:])
    return "".join(out).encode("utf-16", "surrogatepass").decode("utf-16", "replace").strip()


def file_urls(formats: Mapping[str, bytes]) -> list[str]:
    raw = formats.get("text/uri-list", b"")
    if not raw and "x-special/gnome-copied-files" in formats:
        raw = b"\n".join(formats["x-special/gnome-copied-files"].splitlines()[1:])
    return [s.strip() for s in decode_text(raw).splitlines() if s.strip() and not s.startswith("#")]


def normalize_formats(source: Mapping[str, bytes]) -> dict[str, bytes]:
    formats = {str(k): bytes(v) for k, v in source.items() if isinstance(v, (bytes, bytearray))}
    if sum(map(len, formats.values())) > MAX_PAYLOAD:
        raise ValueError("Clip exceeds the 64 MiB safety limit")
    if not formats:
        raise ValueError("Clipboard has no supported data")
    for name in ("text/plain;charset=utf-8", "text/plain;charset=UTF-8", "UTF8_STRING", "text/plain", "TEXT", "STRING"):
        if name in formats:
            text = formats[name].decode("latin-1") if name == "STRING" else decode_text(formats[name])
            formats["text/plain"] = text.encode("utf-8")
            break
    for name in ("UTF8_STRING", "STRING", "TEXT", "text/plain;charset=utf-8", "text/plain;charset=UTF-8"):
        formats.pop(name, None)
    if "application/rtf" in formats and "text/rtf" not in formats:
        formats["text/rtf"] = formats.pop("application/rtf")
    if "text/html" in formats:
        formats["text/html"] = html_fragment(decode_text(formats["text/html"])).encode("utf-8")
    urls = file_urls(formats)
    if urls:
        formats["text/uri-list"] = ("\r\n".join(urls) + "\r\n").encode()
        # Replaying an old cut must not silently move or remove the originals.
        formats["x-special/gnome-copied-files"] = ("copy\n" + "\n".join(urls)).encode()
        if "text/plain" not in formats:
            formats["text/plain"] = "\n".join(unquote(urlparse(u).path) if u.startswith("file:") else u for u in urls).encode()
    if "text/plain" not in formats:
        if "text/html" in formats:
            formats["text/plain"] = html_text(decode_text(formats["text/html"])).encode()
        elif "text/rtf" in formats:
            formats["text/plain"] = rtf_text(formats["text/rtf"].decode("latin-1")).encode()
    return formats


def describe(formats: Mapping[str, bytes]) -> dict[str, Any]:
    text = decode_text(formats.get("text/plain", b""))
    kind = "text"
    dims = ""
    if file_urls(formats):
        kind = "file"
    elif any(name.startswith("image/") for name in formats):
        kind = "img"
        try:
            from PIL import Image
            data = next(v for k, v in formats.items() if k.startswith("image/"))
            with Image.open(io.BytesIO(data)) as image:
                dims = f"{image.width} × {image.height}"
        except (OSError, ValueError, ImportError, StopIteration):
            dims = "image"
    elif "text/html" in formats:
        kind = "html"
    elif "text/rtf" in formats:
        kind = "rtf"
    title = re.sub(r"\s+", " ", text).strip()[:240]
    if kind == "img":
        title = f"Image {dims}" + (f" — {title}" if title else "")
    elif kind == "file":
        names = [Path(unquote(urlparse(u).path)).name or u for u in file_urls(formats)]
        title = "; ".join(names)[:240]
    return {"kind": kind, "text": text, "title": title or "(empty)",
            "size": sum(map(len, formats.values())), "chars": len(text), "dimensions": dims}


def payload_digest(formats: Mapping[str, bytes], formatting: bool) -> str:
    if not formatting and "text/plain" in formats and not any(k.startswith("image/") for k in formats) and not file_urls(formats):
        return hashlib.sha256(b"text\0" + formats["text/plain"]).hexdigest()
    h = hashlib.sha256()
    for name in sorted(formats):
        h.update(name.encode()); h.update(b"\0"); h.update(formats[name]); h.update(b"\0")
    return h.hexdigest()


class Store:
    COLUMNS = ("kind", "text", "title", "app", "window", "url", "created", "size", "chars",
               "dimensions", "favorite", "used", "sort_order", "digest")

    def __init__(self, path: Path):
        self.path = path
        private_dir(path.parent)
        self.db = sqlite3.connect(path)
        path.chmod(0o600)
        self.db.row_factory = sqlite3.Row
        self.db.create_function("casefold", 1, lambda s: (s or "").casefold(), deterministic=True)
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA busy_timeout=5000")
        self.db.execute("PRAGMA trusted_schema=OFF")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS clips (
          id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, text TEXT NOT NULL DEFAULT '',
          title TEXT NOT NULL, app TEXT NOT NULL DEFAULT '', window TEXT NOT NULL DEFAULT '',
          url TEXT NOT NULL DEFAULT '', created TEXT NOT NULL, size INTEGER NOT NULL,
          chars INTEGER NOT NULL, dimensions TEXT NOT NULL DEFAULT '',
          favorite INTEGER NOT NULL DEFAULT 0, used INTEGER NOT NULL DEFAULT 0,
          sort_order REAL NOT NULL, digest TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS formats (
          clip_id INTEGER NOT NULL REFERENCES clips(id) ON DELETE CASCADE,
          mime TEXT NOT NULL, data BLOB NOT NULL, PRIMARY KEY(clip_id,mime)
        );
        CREATE INDEX IF NOT EXISTS clips_sort ON clips(sort_order DESC);
        CREATE INDEX IF NOT EXISTS clips_digest ON clips(digest);
        CREATE INDEX IF NOT EXISTS clips_marks ON clips(favorite,used);
        PRAGMA user_version=1;
        """)
        self._undo: list[list[dict[str, Any]]] = []
        self._transaction_id = 0
        for ext in ("-wal", "-shm"):
            p = Path(str(path) + ext)
            if p.exists():
                p.chmod(0o600)

    @contextmanager
    def transaction(self):
        """Nested savepoints keep imports and edits atomic without implicit commits."""
        self._transaction_id += 1
        name = f"operation_{self._transaction_id}"
        self.db.execute("SAVEPOINT " + name)
        try:
            yield
        except BaseException:
            self.db.execute("ROLLBACK TO " + name)
            self.db.execute("RELEASE " + name)
            raise
        else:
            self.db.execute("RELEASE " + name)

    def close(self) -> None:
        self.db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        self.db.close()

    def _top(self) -> float:
        return float(self.db.execute("SELECT COALESCE(MAX(sort_order),0)+1 FROM clips").fetchone()[0])

    def add(self, data: Mapping[str, bytes], meta: Mapping[str, Any] | None = None,
            settings: Mapping[str, Any] = DEFAULTS, force_duplicate: bool = False) -> int:
        formats = normalize_formats(data)
        info = describe(formats)
        meta = dict(meta or {})
        for name in ("title", "app", "window", "url", "created"):
            if name in meta and meta[name] is not None:
                info[name] = str(meta[name])
        for name in ("app", "window", "url"):
            info.setdefault(name, "")
        info.setdefault("created", timestamp())
        if not info["url"]:
            raw_html = decode_text(data.get("text/html", b""))
            match = re.search(r"SourceURL:([^\r\n]+)", raw_html)
            if match:
                info["url"] = match.group(1).strip()
            elif re.fullmatch(r"https?://\S+", info["text"].strip()):
                info["url"] = info["text"].strip()
        info["favorite"] = bool(meta.get("favorite", False))
        info["used"] = bool(meta.get("used", False))
        info["sort_order"] = self._top()
        info["digest"] = payload_digest(formats, bool(settings.get("UseFormattingInDuplicateDetection")))
        duplicate = None
        if settings.get("ReplaceDuplicates", True) and not force_duplicate:
            duplicate = self.db.execute("SELECT * FROM clips WHERE digest=? ORDER BY sort_order DESC LIMIT 1", (info["digest"],)).fetchone()
        with self.transaction():
            if duplicate:
                ident = int(duplicate["id"])
                info["favorite"] |= bool(duplicate["favorite"])
                info["used"] |= bool(duplicate["used"])
                self.db.execute("UPDATE clips SET " + ",".join(f"{k}=?" for k in self.COLUMNS) + " WHERE id=?",
                                [info[k] for k in self.COLUMNS] + [ident])
                self.db.execute("DELETE FROM formats WHERE clip_id=?", (ident,))
            else:
                cur = self.db.execute("INSERT INTO clips (" + ",".join(self.COLUMNS) + ") VALUES (" + ",".join("?" for _ in self.COLUMNS) + ")", [info[k] for k in self.COLUMNS])
                ident = int(cur.lastrowid)
            self.db.executemany("INSERT INTO formats VALUES (?,?,?)", [(ident, k, v) for k, v in formats.items()])
        return ident

    def get(self, ident: int, with_data: bool = False) -> dict[str, Any] | None:
        row = self.db.execute("SELECT * FROM clips WHERE id=?", (ident,)).fetchone()
        if row is None:
            return None
        result = dict(row)
        if with_data:
            result["formats"] = self.formats(ident)
        return result

    def formats(self, ident: int) -> dict[str, bytes]:
        return {row[0]: bytes(row[1]) for row in self.db.execute("SELECT mime,data FROM formats WHERE clip_id=?", (ident,))}

    def query(self, search: str = "", kind: str = "all", mark: str = "all", settings: Mapping[str, Any] = DEFAULTS,
              start_date: str = "", end_date: str = "", sort: str = "default", limit: int = 5000,
              offset: int = 0) -> tuple[list[dict[str, Any]], int]:
        clauses: list[str] = []
        params: list[Any] = []
        if kind == "texts":
            clauses.append("kind IN ('text','html','rtf')")
        elif kind != "all":
            clauses.append("kind=?"); params.append(kind)
        if mark in ("favorite", "used"):
            clauses.append(f"{mark}=1")
        elif mark == "unused":
            clauses.append("used=0")
        if start_date:
            clauses.append("substr(created,1,10)>=?"); params.append(start_date)
        if end_date:
            clauses.append("substr(created,1,10)<=?"); params.append(end_date)
        if search:
            fields = ["title", "text"] + (["app", "window", "url"] if settings.get("SearchAllFields") else [])
            try:
                terms = shlex.split(search) if settings.get("SearchWordsIndependently") else [search]
            except ValueError:
                terms = search.split()
            for term in terms:
                term = term.replace("\\", "\\\\").replace("_", "\\_")
                if not settings.get("SearchWildcards"):
                    term = term.replace("%", "\\%")
                # LIKE is explicitly made case-sensitive. casefold provides full Unicode matching.
                sensitive = settings.get("SearchCaseSensitive", False)
                bits = [f"{field if sensitive else 'casefold(' + field + ')'} LIKE ? ESCAPE '\\'" for field in fields]
                clauses.append("(" + " OR ".join(bits) + ")")
                params.extend(["%" + (term if sensitive else term.casefold()) + "%"] * len(fields))
            if settings.get("SearchIgnoreBigTexts"):
                clauses.append("chars<=100000")
        self.db.execute("PRAGMA case_sensitive_like=ON")
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        order = {"default": "sort_order DESC,id DESC", "size": "size DESC", "chars": "chars DESC", "created": "created DESC,id DESC"}.get(sort, "sort_order DESC,id DESC")
        total = self.db.execute("SELECT COUNT(*) FROM clips" + where, params).fetchone()[0]
        rows = self.db.execute("SELECT * FROM clips" + where + " ORDER BY " + order + " LIMIT ? OFFSET ?", params + [limit, offset])
        return [dict(r) for r in rows], total

    def count(self) -> int:
        return self.db.execute("SELECT COUNT(*) FROM clips").fetchone()[0]

    def set_mark(self, ids: Iterable[int], field: str, value: bool) -> None:
        if field not in ("favorite", "used"):
            raise ValueError("Invalid mark")
        with self.transaction():
            self.db.executemany(f"UPDATE clips SET {field}=? WHERE id=?", [(int(value), int(i)) for i in ids])

    def rename(self, ident: int, title: str) -> None:
        with self.transaction():
            self.db.execute("UPDATE clips SET title=? WHERE id=?", (title[:1000], ident))

    def edit(self, ident: int, text: str) -> None:
        old = self.get(ident)
        if not old:
            return
        with self.transaction():
            new = self.add({"text/plain": text.encode()}, {"title": old["title"], "app": old["app"],
                           "window": old["window"], "url": old["url"], "created": old["created"],
                           "favorite": old["favorite"], "used": old["used"]}, force_duplicate=True)
            # Replace the contents without changing the externally visible clip ID.
            self.db.execute("DELETE FROM clips WHERE id=?", (ident,))
            self.db.execute("PRAGMA defer_foreign_keys=ON")
            self.db.execute("UPDATE clips SET id=?,sort_order=? WHERE id=?", (ident, old["sort_order"], new))
            self.db.execute("UPDATE formats SET clip_id=? WHERE clip_id=?", (ident, new))

    def move(self, ident: int, direction: str) -> None:
        row = self.get(ident)
        if not row:
            return
        with self.transaction():
            if direction == "top":
                self.db.execute("UPDATE clips SET sort_order=? WHERE id=?", (self._top(), ident))
            else:
                compare, order = (">", "ASC") if direction == "up" else ("<", "DESC")
                other = self.db.execute(f"SELECT id,sort_order FROM clips WHERE sort_order {compare} ? ORDER BY sort_order {order} LIMIT 1", (row["sort_order"],)).fetchone()
                if other:
                    self.db.execute("UPDATE clips SET sort_order=? WHERE id=?", (other["sort_order"], ident))
                    self.db.execute("UPDATE clips SET sort_order=? WHERE id=?", (row["sort_order"], other["id"]))

    def delete(self, ids: Iterable[int], remember: bool = True) -> None:
        snapshots = [r for i in ids if (r := self.get(int(i), True))]
        if remember and snapshots:
            self._undo.append(snapshots)
            self._undo = self._undo[-10:]
        with self.transaction():
            self.db.executemany("DELETE FROM clips WHERE id=?", [(r["id"],) for r in snapshots])

    def undo_delete(self) -> list[int]:
        if not self._undo:
            return []
        ids = []
        snapshots = self._undo[-1]
        with self.transaction():
            for row in snapshots:
                ident = row["id"]
                if self.get(ident) is not None:
                    ident = self.db.execute("SELECT COALESCE(MAX(id),0)+1 FROM clips").fetchone()[0]
                self.db.execute("INSERT INTO clips (id," + ",".join(self.COLUMNS) + ") VALUES (" + ",".join("?" for _ in range(len(self.COLUMNS) + 1)) + ")", [ident] + [row[k] for k in self.COLUMNS])
                self.db.executemany("INSERT INTO formats VALUES (?,?,?)", [(ident, k, v) for k, v in row["formats"].items()])
                ids.append(ident)
        self._undo.pop()
        return ids

    def prune(self, settings: Mapping[str, Any]) -> None:
        depth = max(10, int(settings.get("HistoryDepthNumber", 30000)))
        days = max(0, int(settings.get("HistoryDepthDays", 0)))
        with self.transaction():
            self.db.execute("DELETE FROM clips WHERE favorite=0 AND id IN (SELECT id FROM clips WHERE favorite=0 ORDER BY sort_order DESC LIMIT -1 OFFSET ?)", (depth,))
            if days:
                cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
                self.db.execute("DELETE FROM clips WHERE favorite=0 AND created<?", (cutoff,))

    def export_json(self, path: Path, ids: Iterable[int]) -> int:
        clips = []
        for ident in ids:
            clip = self.get(int(ident), True)
            if clip:
                clip["formats"] = {k: base64.b64encode(v).decode("ascii") for k, v in clip["formats"].items()}
                clips.append(clip)
        atomic_write(path, json.dumps({"format": "clipangel-linux", "version": 1, "clips": clips}, ensure_ascii=False, indent=2).encode())
        return len(clips)

    def export_cac(self, path: Path, ids: Iterable[int]) -> int:
        xs = "http://www.w3.org/2001/XMLSchema"
        ms = "urn:schemas-microsoft-com:xml-msdata"
        ET.register_namespace("xs", xs); ET.register_namespace("msdata", ms)
        root = ET.Element("NewDataSet")
        schema = ET.SubElement(root, f"{{{xs}}}schema", {"id": "NewDataSet"})
        dataset = ET.SubElement(schema, f"{{{xs}}}element", {"name": "NewDataSet", f"{{{ms}}}IsDataSet": "true", f"{{{ms}}}UseCurrentLocale": "false"})
        choice = ET.SubElement(ET.SubElement(dataset, f"{{{xs}}}complexType"), f"{{{xs}}}choice", {"minOccurs": "0", "maxOccurs": "unbounded"})
        table = ET.SubElement(choice, f"{{{xs}}}element", {"name": "ClipAngelClips"})
        seq = ET.SubElement(ET.SubElement(table, f"{{{xs}}}complexType"), f"{{{xs}}}sequence")
        fields = {"Type": "string", "Text": "string", "Title": "string", "Application": "string", "Window": "string",
                  "Size": "int", "Chars": "int", "Created": "dateTime", "Binary": "base64Binary", "RichText": "string",
                  "Id": "int", "HtmlText": "string", "Used": "boolean", "Url": "string", "Hash": "string",
                  "Favorite": "boolean", "ImageSample": "base64Binary", "AppPath": "string"}
        for name, typ in fields.items():
            ET.SubElement(seq, f"{{{xs}}}element", {"name": name, "type": "xs:" + typ, "minOccurs": "0"})
        count = 0
        for ident in ids:
            clip = self.get(int(ident), True)
            if not clip:
                continue
            formats = clip["formats"]
            binary = next((v for k, v in formats.items() if k.startswith("image/")), b"")
            values = {"Type": clip["kind"], "Text": clip["text"], "Title": clip["title"], "Application": clip["app"], "Window": clip["window"],
                      "Size": clip["size"], "Chars": clip["chars"], "Created": normalized_date(clip["created"]),
                      "Binary": base64.b64encode(binary).decode(), "RichText": formats.get("text/rtf", b"").decode("latin-1"),
                      "Id": clip["id"], "HtmlText": decode_text(formats.get("text/html", b"")), "Used": str(bool(clip["used"])).lower(),
                      "Url": clip["url"], "Hash": clip["digest"], "Favorite": str(bool(clip["favorite"])).lower(), "ImageSample": "", "AppPath": ""}
            item = ET.SubElement(root, "ClipAngelClips")
            for name, value in values.items():
                # XML 1.0 cannot represent C0 controls or isolated surrogate code points.
                clean = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff]", "\ufffd", str(value))
                ET.SubElement(item, name).text = clean
            count += 1
        atomic_write(path, ET.tostring(root, encoding="utf-8", xml_declaration=True))
        return count

    def import_file(self, path: Path) -> int:
        if path.stat().st_size > MAX_IMPORT:
            raise ValueError("Import is larger than the 128 MiB safety limit")
        with path.open("rb") as f:
            magic = f.read(16)
        if magic.startswith(b"SQLite format 3"):
            return self.import_sqlite(path)
        raw = path.read_bytes()
        if raw.lstrip().startswith(b"{"):
            obj = json.loads(raw)
            if obj.get("format") != "clipangel-linux" or obj.get("version") != 1:
                raise ValueError("Unsupported ClipAngel JSON format")
            items = obj.get("clips", [])
            if not isinstance(items, list) or len(items) > 50000:
                raise ValueError("Invalid clip list")
            prepared = []
            for item in items:
                formats = {k: base64.b64decode(v, validate=True) for k, v in item["formats"].items()}
                formats = normalize_formats(formats)
                prepared.append((formats, item))
        else:
            if re.search(br"<!\s*(DOCTYPE|ENTITY)", raw, re.I):
                raise ValueError("XML entities and document types are not accepted")
            root = ET.fromstring(raw)
            prepared = []
            for node in root.iter():
                if node.tag.rsplit("}", 1)[-1] == "ClipAngelClips" and len(node):
                    values = {child.tag.rsplit("}", 1)[-1].lower(): child.text or "" for child in node}
                    if "type" in values:
                        prepared.append(windows_clip(values))
                        if len(prepared) > 50000:
                            raise ValueError("Too many clips")
            if not prepared:
                raise ValueError("No ClipAngelClips records were found")
        # Validate everything before modifying the database.
        return self._import_prepared(prepared)

    def _import_prepared(self, prepared: list) -> int:
        count = 0
        with self.transaction():
            for data, meta in reversed(prepared):
                self.add(data, meta)
                count += 1
        return count

    def import_sqlite(self, path: Path) -> int:
        from urllib.parse import quote
        source = sqlite3.connect("file:" + quote(str(path.resolve())) + "?mode=ro", uri=True)
        source.row_factory = sqlite3.Row
        try:
            source.execute("PRAGMA query_only=ON")
            source.execute("PRAGMA trusted_schema=OFF")
            names = {r[0].casefold(): r[0] for r in source.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if "clips" not in names:
                raise ValueError("This database has no Clips table")
            prepared = []
            if "formats" in names:
                for row in source.execute("SELECT * FROM clips ORDER BY sort_order DESC LIMIT 50001"):
                    item = dict(row)
                    formats = {r[0]: bytes(r[1]) for r in source.execute("SELECT mime,data FROM formats WHERE clip_id=?", (item["id"],))}
                    prepared.append((normalize_formats(formats), item))
            else:
                for row in source.execute('SELECT * FROM "Clips" ORDER BY "Id" DESC LIMIT 50001'):
                    prepared.append(windows_clip({k.lower(): v for k, v in dict(row).items()}))
            if len(prepared) > 50000:
                raise ValueError("Import is limited to 50,000 clips per file")
            return self._import_prepared(prepared)
        finally:
            source.close()

    def backup(self, path: Path) -> None:
        if path.resolve() == self.path.resolve():
            raise ValueError("Choose a different path for the backup")
        target = sqlite3.connect(path)
        try:
            path.chmod(0o600)
            self.db.backup(target)
        finally:
            target.close()


def normalized_date(value: str) -> str:
    try:
        date = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if date.tzinfo is None:
            date = date.replace(tzinfo=timezone.utc)
        return date.isoformat(timespec="seconds")
    except (ValueError, AttributeError):
        return timestamp()


def windows_clip(row: Mapping[str, Any]) -> tuple[dict[str, bytes], dict[str, Any]]:
    def s(name: str) -> str:
        return str(row.get(name) or "")
    def flag(name: str) -> bool:
        return s(name).lower() in ("true", "1")
    formats: dict[str, bytes] = {}
    kind = s("type").lower()
    if s("text") or kind in ("text", "html", "rtf", "1c"):
        formats["text/plain"] = s("text").encode()
    if s("htmltext"):
        formats["text/html"] = s("htmltext").encode()
    if s("richtext"):
        formats["text/rtf"] = s("richtext").encode("latin-1", "backslashreplace")
    if row.get("binary"):
        value = row["binary"]
        raw = bytes(value) if isinstance(value, (bytes, bytearray)) else base64.b64decode(value, validate=True)
        if raw:
            mime = "image/jpeg" if raw.startswith(b"\xff\xd8") else "image/bmp" if raw.startswith(b"BM") else "image/png"
            formats[mime] = raw
    if kind == "file":
        from urllib.parse import quote
        urls = []
        for line in s("text").splitlines():
            line = line.strip()
            if not line:
                continue
            if line.startswith("file:"):
                urls.append(line)
            elif re.match(r"^[A-Za-z]:[\\/]", line):
                urls.append("file:///" + quote(line.replace("\\", "/"), safe="/:"))
            elif line.startswith("/"):
                urls.append(Path(line).as_uri())
        if urls:
            formats["text/uri-list"] = ("\r\n".join(urls) + "\r\n").encode()
    if not formats:
        formats["text/plain"] = s("text").encode()
    meta = {"title": s("title") or re.sub(r"\s+", " ", s("text"))[:240] or "Imported clip",
            "app": s("application"), "window": s("window"), "url": s("url"),
            "created": normalized_date(s("created")), "favorite": flag("favorite"), "used": flag("used")}
    return normalize_formats(formats), meta


def transform(text: str, case: str = "unchanged", replace_eol: bool = False,
              tabs: int = 0, normalize_space: bool = False, normalize_eol: bool = False) -> str:
    if case == "upper":
        text = text.upper()
    elif case == "lower":
        text = text.lower()
    elif case == "sentence":
        text = re.sub(r"(^\s*\w|[.!?]\s+\w)", lambda m: m[0].upper(), text.lower())
    elif case in ("upper_camel", "lower_camel"):
        text = "".join(w[:1].upper() + w[1:].lower() for w in re.findall(r"[^\W_]+", text, re.UNICODE))
        if case == "lower_camel":
            text = text[:1].lower() + text[1:]
    elif case == "from_camel":
        text = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", text)
        text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", text).lower()
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    if replace_eol:
        text = text.replace("\n", " ")
    if tabs > 0:
        text = text.replace("\t", " " * min(tabs, 32))
    if normalize_space:
        text = re.sub(r"[ \f\t\v]+", " ", text.strip())
    if normalize_eol:
        text = re.sub(r"\n\s*\n+", "\n", text.strip())
    return text


def delimiter(value: str) -> str:
    return value.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\t", "\t")
