# SPDX-License-Identifier: GPL-3.0-only
"""Single-instance control over a private, same-user Unix domain socket."""
from __future__ import annotations
import fcntl
import hashlib
import json
import os
from pathlib import Path
import socket
import stat
import time
from .core import private_dir

MAX_MESSAGE = 1024 * 1024 + 4096


class Instance:
    def __init__(self, data_dir: Path):
        directory = private_dir(data_dir)
        self.path = directory / 'control.sock'
        if len(os.fsencode(self.path)) > 100:
            name = hashlib.sha256(os.fsencode(directory.resolve())).hexdigest()[:20]
            runtime = Path(os.environ.get('XDG_RUNTIME_DIR', '/tmp')) / f'clipangel-{os.getuid()}-{name}'
            if runtime.exists() and (runtime.is_symlink() or runtime.stat().st_uid != os.getuid()):
                raise RuntimeError('Unsafe runtime directory')
            directory = private_dir(runtime)
            self.path = directory / 'control.sock'
        self.lock = open(directory / 'control.lock', 'a+b')
        os.chmod(directory / 'control.lock', 0o600)
        self.server = None
        self.clients = {}
        self.primary = False
        try:
            fcntl.flock(self.lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.primary = True
        except BlockingIOError:
            return
        try:
            self.path.unlink(missing_ok=True)
            self.server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self.server.bind(str(self.path))
            self.path.chmod(0o600)
            self.server.listen(8)
            self.server.setblocking(False)
        except BaseException:
            self.close()
            raise

    def send(self, command: dict) -> None:
        payload = (json.dumps(command, ensure_ascii=False) + '\n').encode()
        if len(payload) > MAX_MESSAGE:
            raise ValueError('Command is too large')
        last_error = None
        for _ in range(20):
            try:
                with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                    client.settimeout(2)
                    client.connect(str(self.path))
                    client.sendall(payload)
                return
            except (FileNotFoundError, ConnectionRefusedError) as exc:
                last_error = exc
                time.sleep(.05)
        raise RuntimeError('The other ClipAngel instance is not responding') from last_error

    def commands(self) -> list[dict]:
        if not self.server:
            return []
        while len(self.clients) < 16:
            try:
                client, _ = self.server.accept()
                client.setblocking(False)
                self.clients[client] = (bytearray(), time.monotonic())
            except BlockingIOError:
                break
        commands = []
        for client, (buffer, start) in list(self.clients.items()):
            done = False
            try:
                data = client.recv(65536)
                if data:
                    buffer.extend(data)
                if len(buffer) > MAX_MESSAGE or time.monotonic() - start > 5:
                    done = True
                elif b'\n' in buffer or not data:
                    try:
                        command = json.loads(bytes(buffer).split(b'\n', 1)[0])
                        if isinstance(command, dict):
                            commands.append(command)
                    except (ValueError, UnicodeError):
                        pass
                    done = True
            except BlockingIOError:
                done = time.monotonic() - start > 5
            except OSError:
                done = True
            if done:
                client.close()
                self.clients.pop(client, None)
        return commands

    def close(self) -> None:
        for client in list(self.clients):
            client.close()
        self.clients.clear()
        if self.server:
            self.server.close()
            self.server = None
        if self.primary:
            self.path.unlink(missing_ok=True)
            self.primary = False
        if not self.lock.closed:
            self.lock.close()
