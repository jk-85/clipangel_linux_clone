"""ClipAngel Linux — a source-informed native Linux reimplementation."""
__version__ = "2.23.0-linux4"
UPSTREAM_VERSION = "2.23"
