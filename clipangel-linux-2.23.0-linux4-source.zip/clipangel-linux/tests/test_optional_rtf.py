"""Verify optional unrtf without changing system packages or clipboard bytes."""
import os
from pathlib import Path
import tempfile
import tkinter as tk
import unittest
from unittest.mock import patch
from clipangel.core import Settings, Store, normalize_formats, rtf_text, rtf_to_html

RTF = br'{\rtf1\ansi\ansicpg1252 Hello \b world\b0\par M\u252?nchen \u26085?\u26412?\u35486?}'


class OptionalRTFTests(unittest.TestCase):
    def test_absent_converter_falls_back_to_unicode_text(self):
        with patch.dict(os.environ, {'PATH':'/nonexistent-clipangel-test'}):
            self.assertEqual(rtf_to_html(RTF),'')
            formats = normalize_formats({'application/rtf':RTF})
        self.assertEqual(formats['text/rtf'],RTF)
        self.assertEqual(formats['text/plain'].decode(),'Hello world\nMünchen 日本語')

    def test_rtf_storage_and_export_without_converter(self):
        with tempfile.TemporaryDirectory() as d, patch.dict(os.environ, {'PATH':'/nonexistent-clipangel-test'}):
            p=Path(d);store=Store(p/'h.db');other=Store(p/'other.db')
            try:
                ident=store.add({'text/rtf':RTF})
                self.assertEqual(store.get(ident)['kind'],'rtf')
                self.assertEqual(store.formats(ident)['text/rtf'],RTF)
                export=p/'test.json';store.export_json(export,[ident]);other.import_file(export)
                row=other.query()[0][0]
                self.assertEqual(row['text'],'Hello world\nMünchen 日本語')
                self.assertEqual(other.formats(row['id'])['text/rtf'],RTF)
            finally:
                store.close();other.close()

    def test_package_builder_declares_converter_only_as_suggestion(self):
        builder=(Path(__file__).parent.parent/'packaging/build-deb.sh').read_text()
        depends=next(line for line in builder.splitlines() if line.startswith('Depends:'))
        self.assertNotIn('unrtf',depends)
        self.assertIn('Suggests: unrtf',builder)
        self.assertIn('python3-pil (>= 9.0.1)',depends)

    @unittest.skipUnless(os.environ.get('DISPLAY'), 'requires X11')
    def test_rtf_preview_without_converter(self):
        from clipangel.views import Preview
        with tempfile.TemporaryDirectory() as d, patch.dict(os.environ, {'PATH':'/nonexistent-clipangel-test'}):
            p=Path(d);r=tk.Tk();store=Store(p/'h.db');settings=Settings(p/'s.json')
            settings['ShowNativeTextFormatting']=True
            try:
                ident=store.add({'text/rtf':RTF})
                preview=Preview(r,lambda *args:None)
                preview.pack();r.update()
                preview.show(store.get(ident),store.formats(ident),settings);r.update()
                self.assertIn('Hello world\nMünchen 日本語',preview.text.get('1.0','end'))
                self.assertEqual(store.formats(ident)['text/rtf'],RTF)
            finally:
                r.destroy();store.close()
