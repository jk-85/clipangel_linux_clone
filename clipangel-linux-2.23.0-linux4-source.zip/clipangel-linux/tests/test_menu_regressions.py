"""Real XTest pointer/key regression tests; requires X11 + a window manager."""
import ctypes as C
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import tkinter as tk
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from PIL import Image
from clipangel.app import Application
from clipangel.core import Settings, Store
from clipangel.theme import DARK


class Input:
    """Send server-side input, not event_generate (which misses overlap bugs)."""
    def __init__(self):
        self.x = C.CDLL('libX11.so.6')
        self.t = C.CDLL('libXtst.so.6')
        for name, args, result in (
            ('XOpenDisplay', [C.c_char_p], C.c_void_p),
            ('XCloseDisplay', [C.c_void_p], C.c_int),
            ('XFlush', [C.c_void_p], C.c_int),
            ('XStringToKeysym', [C.c_char_p], C.c_ulong),
            ('XKeysymToKeycode', [C.c_void_p, C.c_ulong], C.c_uint),
        ):
            f = getattr(self.x, name); f.argtypes = args; f.restype = result
        self.t.XTestFakeMotionEvent.argtypes = [C.c_void_p, C.c_int, C.c_int, C.c_int, C.c_ulong]
        self.t.XTestFakeButtonEvent.argtypes = [C.c_void_p, C.c_uint, C.c_int, C.c_ulong]
        self.t.XTestFakeKeyEvent.argtypes = [C.c_void_p, C.c_uint, C.c_int, C.c_ulong]
        self.d = self.x.XOpenDisplay(None)
        if not self.d:
            raise RuntimeError('Cannot connect test input to DISPLAY')

    def move(self, x, y):
        self.t.XTestFakeMotionEvent(self.d, -1, int(x), int(y), 0)
        self.x.XFlush(self.d)

    def button(self, number, down):
        self.t.XTestFakeButtonEvent(self.d, number, down, 0)
        self.x.XFlush(self.d)

    def key(self, name):
        code = self.x.XKeysymToKeycode(self.d, self.x.XStringToKeysym(name.encode()))
        self.t.XTestFakeKeyEvent(self.d, code, 1, 0)
        self.t.XTestFakeKeyEvent(self.d, code, 0, 0)
        self.x.XFlush(self.d)

    def close(self):
        for button in (1, 2, 3):
            self.button(button, 0)
        self.x.XCloseDisplay(self.d)


@unittest.skipUnless(os.environ.get('DISPLAY'), 'requires X11 + a window manager')
class MenuRegressionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name)
        self.env = patch.dict(os.environ, {'XDG_CONFIG_HOME': str(self.path / 'config'),
                                          'XDG_DATA_HOME': str(self.path / 'data')})
        self.env.start()
        self.root = tk.Tk(className='ClipAngel')
        self.settings = Settings(self.path / 'settings.json')
        self.settings['MonitoringClipboard'] = False
        self.settings['WindowGeometry'] = '980x560+40+40'
        self.store = Store(self.path / 'history.sqlite3')
        self.app = Application(self.root, self.store, self.settings)
        self.ident = self.store.add({'text/plain': b'Menu regression: no unintended action'})
        self.app.refresh(select=self.ident)
        self.errors = []
        self.root.report_callback_exception = lambda *args: self.errors.append(args)
        self.input = Input()
        self.pump(.22)

    def tearDown(self):
        self.input.close()
        if self.app.running:
            self.app.quit()
        self.env.stop()
        self.temp.cleanup()
        self.assertEqual(self.errors, [])

    def pump(self, seconds=.07, until=None):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            self.root.update()
            time.sleep(.003)
            if until and until():
                return

    def click(self, x, y, button=1):
        self.input.move(x, y); self.pump(.04)
        self.input.button(button, 1); self.pump(.06)
        self.input.button(button, 0); self.pump(.09)

    def button(self, title):
        return next(w for w in self.app.menu_frame.winfo_children()
                    if isinstance(w, tk.Menubutton) and w.cget('text') == title)

    def open_menu(self, title):
        button = self.button(title)
        menu = self.root.nametowidget(button.cget('menu'))
        self.click(button.winfo_rootx()+button.winfo_width()//2,
                   button.winfo_rooty()+button.winfo_height()//2)
        self.assertTrue(menu.winfo_ismapped(), title)
        return menu

    def entry(self, menu, label):
        return next(i for i in range(menu.index('end')+1)
                    if menu.type(i) != 'separator' and menu.entrycget(i, 'label') == label)

    def entry_position(self, menu, index):
        y = menu.yposition(index)
        after = menu.yposition(index+1) if index < menu.index('end') else menu.winfo_height()-2
        return menu.winfo_rootx()+max(20, menu.winfo_width()//3), menu.winfo_rooty()+(y+after)//2

    def assert_closed(self, menu):
        self.pump()
        self.assertFalse(menu.winfo_ismapped())
        self.assertIsNone(self.root.grab_current())
        self.assertEqual(self.root.state(), 'normal')

    def test_clip_overlap_open_does_not_delete_or_invoke(self):
        button = self.button('Clip')
        menu = self.root.nametowidget(button.cget('menu'))
        y = max(35, self.root.winfo_screenheight()-menu.winfo_reqheight()+60)
        self.root.geometry(f'980x410+40+{y}'); self.pump()
        menu = self.open_menu('Clip')
        # Establish that this run REALLY exercises the reported overlap.
        self.assertLess(menu.winfo_rooty(), button.winfo_rooty()+button.winfo_height())
        self.assertIsNotNone(self.store.get(self.ident))
        self.assertFalse(self.store.get(self.ident)['used'])
        self.assertIsNone(menu.index('active'))
        self.input.key('Escape'); self.assert_closed(menu)

    def test_clip_small_pointer_jitter_is_still_opening_click(self):
        button = self.button('Clip'); menu = self.root.nametowidget(button.cget('menu'))
        y = max(35, self.root.winfo_screenheight()-menu.winfo_reqheight()+60)
        self.root.geometry(f'980x410+40+{y}'); self.pump()
        x, y = button.winfo_rootx()+10, button.winfo_rooty()+10
        self.input.move(x,y); self.pump(); self.input.button(1,1); self.pump()
        self.input.move(x+2,y+2); self.pump(); self.input.button(1,0); self.pump()
        self.assertTrue(menu.winfo_ismapped())
        self.assertIsNotNone(self.store.get(self.ident))

    def test_all_menubar_entries_stay_open_and_escape_only_closes_menu(self):
        for title in ('Window','List','Clip','Help'):
            with self.subTest(title=title):
                menu = self.open_menu(title)
                self.assertIsNotNone(self.root.grab_current())
                self.input.key('Escape'); self.assert_closed(menu)

    def test_click_different_menubar_switches_menu(self):
        old = self.open_menu('Window')
        menu = self.open_menu('Help')
        self.assertFalse(old.winfo_ismapped())
        self.input.key('Escape'); self.assert_closed(menu)

    def test_history_context_outside_inside_app_dismisses(self):
        self.click(self.app.tree.winfo_rootx()+80, self.app.tree.winfo_rooty()+35, 3)
        menu = self.app.context
        self.assertTrue(menu.winfo_ismapped())
        self.assertEqual(str(self.root.grab_current()), str(menu))
        self.click(self.app.preview.text.winfo_rootx()+self.app.preview.text.winfo_width()-30,
                   self.app.preview.text.winfo_rooty()+25)
        self.assert_closed(menu)

    def test_history_context_outside_application_dismisses(self):
        self.click(self.app.tree.winfo_rootx()+80, self.app.tree.winfo_rooty()+35, 3)
        menu = self.app.context
        self.assertTrue(menu.winfo_ismapped())
        self.click(self.root.winfo_screenwidth()-15, self.root.winfo_screenheight()-15)
        self.assert_closed(menu)

    def test_context_click_over_independent_application_dismisses(self):
        code = '''import tkinter as t,sys\nfrom pathlib import Path\nr=t.Tk(className="MenuTestTarget");r.geometry("180x120+1080+570");r.update();Path(sys.argv[1]).write_text(str(r.winfo_rootx()+20)+","+str(r.winfo_rooty()+50));r.mainloop()'''
        path = self.path/'target'
        proc = subprocess.Popen([sys.executable,'-c',code,str(path)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:
            self.pump(3, path.exists)
            self.assertTrue(path.exists())
            xy = tuple(map(int,path.read_text().split(',')))
            self.app.show();self.pump()
            self.click(self.app.tree.winfo_rootx()+80, self.app.tree.winfo_rooty()+35, 3)
            self.assertTrue(self.app.context.winfo_ismapped())
            self.click(*xy)
            self.assert_closed(self.app.context)
        finally:
            proc.terminate();_,err=proc.communicate(timeout=3)
            self.assertEqual(err,b'')

    def test_history_context_command_still_works(self):
        self.click(self.app.tree.winfo_rootx()+80, self.app.tree.winfo_rooty()+35, 3)
        menu = self.app.context
        self.click(*self.entry_position(menu, self.entry(menu,'Mark as favorite')))
        self.assertTrue(self.store.get(self.ident)['favorite'])
        self.assert_closed(menu)

    def test_context_keyboard_navigation_and_command(self):
        self.click(self.app.tree.winfo_rootx()+80, self.app.tree.winfo_rooty()+35, 3)
        menu = self.app.context
        self.input.key('Down'); self.pump()
        self.assertIsNotNone(menu.index('active'))
        menu.activate(self.entry(menu,'Mark as favorite'))
        self.input.key('Return'); self.pump()
        self.assertTrue(self.store.get(self.ident)['favorite'])
        self.assert_closed(menu)

    def test_popup_near_screen_bottom_does_not_invoke_on_right_release(self):
        menu = self.app.context
        # An actual preview right-click close to the bottom forces Tk to move
        # the menu upward under the cursor. Override one binding to open the
        # history menu there (its many commands reproduce the dangerous case).
        self.root.geometry('980x600+40+160'); self.pump()
        text = self.app.preview.text
        text.bind('<Button-3>', lambda e: (self.app.menus.popup(menu,e.x_root,e.y_root),'break')[1])
        x,y = text.winfo_rootx()+60, text.winfo_rooty()+text.winfo_height()-35
        self.click(x,y,3)
        self.assertLess(menu.winfo_rooty(),y)
        self.assertTrue(menu.winfo_ismapped())
        self.assertIsNone(menu.index('active'))
        self.assertIsNotNone(self.store.get(self.ident))
        self.assertFalse(self.store.get(self.ident)['used'])

    def test_press_drag_release_selection_is_retained(self):
        button=self.button('Window');menu=self.root.nametowidget(button.cget('menu'))
        self.input.move(button.winfo_rootx()+10,button.winfo_rooty()+10);self.pump()
        self.input.button(1,1);self.pump()
        self.assertTrue(menu.winfo_ismapped())
        self.input.move(*self.entry_position(menu,self.entry(menu,'Dark theme')));self.pump()
        self.input.button(1,0);self.pump()
        self.assertTrue(self.settings['DarkTheme'])
        self.assert_closed(menu)

    def test_cascade_remains_usable_and_escape_restores_parent(self):
        menu = self.open_menu('Clip')
        self.click(*self.entry_position(menu,0));self.pump(.15)
        child = self.root.nametowidget(menu.entrycget(0,'menu'))
        self.assertTrue(child.winfo_ismapped())
        self.input.move(*self.entry_position(child,0));self.pump()
        self.input.key('Escape');self.pump()
        self.assertFalse(child.winfo_ismapped())
        self.assertTrue(menu.winfo_ismapped())
        self.input.key('Escape');self.assert_closed(menu)

    def test_preview_and_image_contexts_close_and_are_reused(self):
        for mode in ('text','image'):
            if mode=='image':
                data=io.BytesIO();Image.new('RGB',(20,20),'white').save(data,'PNG')
                ident=self.store.add({'image/png':data.getvalue()});self.app.refresh(select=ident);self.pump()
            widget=self.app.preview.text if mode=='text' else self.app.preview.canvas
            menu=self.app.preview_context if mode=='text' else self.app.image_context
            before=len([w for w in self.root.winfo_children() if isinstance(w,tk.Menu)])
            for _ in range(3):
                self.click(widget.winfo_rootx()+50,widget.winfo_rooty()+50,3)
                self.assertTrue(menu.winfo_ismapped())
                self.input.key('Escape');self.assert_closed(menu)
            after=len([w for w in self.root.winfo_children() if isinstance(w,tk.Menu)])
            self.assertEqual(before,after)

    def test_dark_contexts_and_rebuild_do_not_leave_grab(self):
        self.app.toggle('DarkTheme',True)
        menu=self.app.preview_context
        self.click(self.app.preview.text.winfo_rootx()+60,self.app.preview.text.winfo_rooty()+40,3)
        self.assertEqual(str(menu.cget('background')),DARK['bg'])
        self.app.apply_settings({'FontSize':11})
        self.pump()
        self.assertIsNone(self.root.grab_current())
        self.assertFalse(menu.winfo_exists())
        new=self.open_menu('Clip')
        self.input.key('Escape');self.assert_closed(new)

    def test_hide_unposts_context_and_releases_grab(self):
        self.click(self.app.tree.winfo_rootx()+80,self.app.tree.winfo_rooty()+35,3)
        self.app.hide();self.pump()
        self.assertFalse(self.app.context.winfo_ismapped())
        self.assertIsNone(self.root.grab_current())
        self.app.show();self.pump()
        self.assertEqual(self.root.state(),'normal')

    def test_search_options_popup_after_repeated_settings_changes(self):
        for size in (10,11,10):
            self.app.apply_settings({'FontSize':size});self.pump()
            button=self.app.search_options_button
            self.click(button.winfo_rootx()+10,button.winfo_rooty()+10)
            self.assertTrue(self.app.search_options_menu.winfo_ismapped())
            self.input.key('Escape');self.assert_closed(self.app.search_options_menu)

    def test_tray_menu_lifecycle_without_tray_host(self):
        self.input.move(1100,700);self.pump()
        self.app._xevent(5,3,b'');self.pump()
        self.assertTrue(self.app.tray_menu.winfo_ismapped())
        self.assertIsNotNone(self.root.grab_current())
        self.input.key('Escape');self.assert_closed(self.app.tray_menu)

    def test_quit_with_pending_child_timer_does_not_double_delete_callback(self):
        self.app.preview.text.after(60000, lambda: None)
        self.app.quit()
        self.assertFalse(self.app.running)
        self.assertEqual(self.root.tk.call('after','info'), '')

    def test_keyboard_enters_cascade_and_returns(self):
        menu=self.open_menu('Clip')
        menu.activate(0)
        self.input.key('Right');self.pump()
        child=self.root.nametowidget(menu.entrycget(0,'menu'))
        self.assertTrue(child.winfo_ismapped())
        self.input.key('Escape');self.pump()
        self.assertFalse(child.winfo_ismapped())
        self.assertTrue(menu.winfo_ismapped())
        self.input.key('Escape');self.assert_closed(menu)
