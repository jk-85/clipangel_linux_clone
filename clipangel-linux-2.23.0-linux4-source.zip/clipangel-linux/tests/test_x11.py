import io
import os
import time
import unittest
from PIL import Image
from clipangel.x11 import X11


@unittest.skipUnless(os.environ.get('DISPLAY'), 'requires an X11 display (xvfb-run)')
class X11Tests(unittest.TestCase):
    def setUp(self):
        self.events=[]
        self.sender=X11(lambda *args:None)
        self.receiver=X11(lambda *args:self.events.append(args))

    def tearDown(self):
        self.sender.close(); self.receiver.close()

    def get(self, mime, token=100):
        self.events.clear(); self.assertTrue(self.receiver.request(mime,token))
        end=time.monotonic()+6
        while time.monotonic()<end:
            self.sender.poll(); self.receiver.poll()
            for event,ident,data in self.events:
                if ident==token and event in (2,3): return event,data
            time.sleep(.002)
        self.fail('Clipboard transfer timed out')

    def test_unicode_text(self):
        payload='München 日本語 😀\nsecond line'.encode()
        self.sender.copy({'text/plain':payload})
        self.assertEqual(self.get('UTF8_STRING'),(2,payload))

    def test_incr_3mb(self):
        payload=bytes(range(256))*11719
        self.sender.copy({'application/test-binary':payload})
        self.assertEqual(self.get('application/test-binary'),(2,payload))

    def test_rich_multiple_targets(self):
        formats={'text/plain':b'hello','text/html':b'<b>hello</b>','text/rtf':br'{\rtf1 hello}'}
        self.sender.copy(formats)
        event,targets=self.get('TARGETS')
        self.assertEqual(event,2)
        for mime,payload in formats.items():
            self.assertIn(mime.encode(),targets.splitlines())
            self.assertEqual(self.get(mime),(2,payload))

    def test_png_image(self):
        out=io.BytesIO(); Image.new('RGB',(80,50),'white').save(out,'PNG')
        self.sender.copy({'image/png':out.getvalue()})
        self.assertEqual(self.get('image/png'),(2,out.getvalue()))

    def test_file_uri(self):
        payload=b'file:///tmp/a.txt\r\nfile:///tmp/b.txt\r\n'
        self.sender.copy({'text/uri-list':payload})
        self.assertEqual(self.get('text/uri-list'),(2,payload))

    def test_unsupported_target_fails(self):
        self.sender.copy({'text/plain':b'a'})
        self.assertEqual(self.get('application/does-not-exist')[0],3)

    def test_empty_text(self):
        self.sender.copy({'text/plain':b''})
        self.assertEqual(self.get('UTF8_STRING'),(2,b''))

    def test_hotkey_conflict(self):
        self.assertEqual(self.sender.bind_hotkeys({1:'Alt+V'}),[])
        self.assertEqual(self.receiver.bind_hotkeys({1:'Alt+V'}),['Alt+V'])
        self.sender.bind_hotkeys({})
        self.assertEqual(self.receiver.bind_hotkeys({1:'Alt+V'}),[])

    def test_xfixes_owner_notification(self):
        self.sender.copy({'text/plain':b'owner'})
        end=time.monotonic()+1
        while time.monotonic()<end:
            self.sender.poll(); self.receiver.poll(); time.sleep(.002)
            if any(e==1 and token==self.sender.window for e,token,_ in self.events): return
        self.fail('No XFixes owner notification')

if __name__=='__main__': unittest.main()
