"""Regression coverage for Linux preview 3: paste policy and login startup."""
import configparser
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from clipangel import autostart
from clipangel.core import Settings
from clipangel.paste_policy import paste_key, PASTE_KEYS


class PastePolicyTests(unittest.TestCase):
    def test_terminal_class_variants(self):
        for name in ('Gnome-terminal', 'gnome-terminal-server', 'GNOME Terminal',
                     'org.gnome.Terminal', 'konsole', 'Konsole', 'org.kde.konsole',
                     'Mate-terminal', 'Xfce4-terminal'):
            with self.subTest(name=name):
                self.assertEqual(paste_key('Auto', name), 'Ctrl+Shift+V')

    def test_nonterminal_classes_and_unknown(self):
        for name in ('notepadqq', 'Gimp', 'Drawing', 'org.gnome.Drawing', 'Firefox',
                     '', 'unknown', 'my-konsole-notes-editor', 'terminal-preview'):
            with self.subTest(name=name):
                self.assertEqual(paste_key('Auto', name), 'Ctrl+V')

    def test_manual_overrides(self):
        for mode in PASTE_KEYS[1:]:
            for name in ('Konsole', 'Gnome-terminal', 'notepadqq'):
                self.assertEqual(paste_key(mode, name), mode)

    def test_old_default_migrates_once(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'settings.json'
            path.write_text(json.dumps({'PasteKey': 'Ctrl+V', 'FontSize': 12, 'WordWrap': False}))
            settings = Settings(path)
            self.assertEqual(settings['PasteKey'], 'Auto')
            self.assertEqual(settings['FontSize'], 12)
            self.assertFalse(settings['WordWrap'])
            settings['PasteKey'] = 'Ctrl+V'
            settings.save()
            self.assertEqual(Settings(path)['PasteKey'], 'Ctrl+V')

    def test_old_manual_override_is_preserved(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'settings.json'
            for mode in ('Ctrl+Shift+V', 'Shift+Insert'):
                path.write_text(json.dumps({'PasteKey': mode}))
                self.assertEqual(Settings(path)['PasteKey'], mode)

    def test_theme_defaults_and_persistence(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'settings.json'
            settings = Settings(path)
            self.assertFalse(settings['DarkTheme'])
            self.assertFalse(settings['Autostart'])
            self.assertEqual(settings['PasteKey'], 'Auto')
            settings['DarkTheme'] = True
            settings.save()
            self.assertTrue(Settings(path)['DarkTheme'])

    def test_invalid_paste_setting_falls_back_to_auto(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'settings.json'
            path.write_text(json.dumps({'PasteKey': 'invalid'}))
            self.assertEqual(Settings(path)['PasteKey'], 'Auto')


class AutostartTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name)
        self.environment = patch.dict(os.environ, {'HOME': str(self.path),
            'XDG_CONFIG_HOME': str(self.path / 'config space München'),
            'XDG_DATA_HOME': str(self.path / 'data'), 'XDG_RUNTIME_DIR': str(self.path / 'runtime')})
        self.environment.start()

    def tearDown(self):
        self.environment.stop()
        self.temp.cleanup()

    def test_enable_disable_per_user_entry(self):
        self.assertFalse(autostart.is_enabled())
        path = autostart.set_enabled(True)
        self.assertEqual(path, self.path / 'config space München/autostart/clipangel.desktop')
        self.assertTrue(autostart.is_enabled())
        config = configparser.ConfigParser()
        config.read(path)
        self.assertEqual(config['Desktop Entry']['Exec'], 'clipangel --minimized')
        self.assertEqual(config['Desktop Entry']['TryExec'], 'clipangel')
        self.assertFalse(config['Desktop Entry'].getboolean('Terminal'))
        other = path.with_name('unrelated.desktop')
        other.write_text('not ours')
        autostart.set_enabled(False)
        self.assertFalse(path.exists())
        self.assertEqual(other.read_text(), 'not ours')
        autostart.set_enabled(False)  # Idempotent.

    def test_external_startup_manager_disable_is_respected(self):
        path = autostart.set_enabled(True)
        contents = path.read_text()
        path.write_text(contents.replace('Hidden=false', 'Hidden=true'))
        self.assertFalse(autostart.is_enabled())
        path.write_text(contents.replace('X-GNOME-Autostart-enabled=true', 'X-GNOME-Autostart-enabled=false'))
        self.assertFalse(autostart.is_enabled())

    def test_corrupt_entry_is_not_enabled(self):
        path = autostart.set_enabled(True)
        for content in ('not a desktop file', '[Desktop Entry]\nHidden=invalid',
                        '[Desktop Entry]\nType=Application\nExec='):
            path.write_text(content)
            self.assertFalse(autostart.is_enabled())

    def test_failure_does_not_replace_existing_entry(self):
        path = autostart.set_enabled(True)
        original = path.read_bytes()
        with patch('clipangel.autostart.atomic_write', side_effect=PermissionError('denied')):
            with self.assertRaises(PermissionError):
                autostart.set_enabled(True)
        self.assertEqual(path.read_bytes(), original)

    def test_relative_xdg_path_falls_back_to_home(self):
        with patch.dict(os.environ, {'XDG_CONFIG_HOME': 'relative/path'}):
            self.assertEqual(autostart.entry_path(), self.path / '.config/autostart/clipangel.desktop')

    def test_cli_works_without_display(self):
        env = dict(os.environ)
        env.pop('DISPLAY', None)
        command = [sys.executable, '-m', 'clipangel', '--autostart']
        for arg, expected in [('status', False), ('on', True), ('status', True), ('off', False)]:
            result = subprocess.run(command + [arg], env=env, text=True, capture_output=True, timeout=8)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stderr, '')
            self.assertEqual(autostart.is_enabled(), expected)
            self.assertIn('enabled (minimized)' if expected else 'disabled', result.stdout)
        self.assertFalse((self.path / 'data/clipangel/history.sqlite3').exists())

    def test_cli_rejects_isolated_profile(self):
        result = subprocess.run([sys.executable, '-m', 'clipangel', '--data-dir', str(self.path / 'isolated'),
                                 '--autostart', 'on'], text=True, capture_output=True, timeout=8)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(autostart.entry_path().exists())


if __name__ == '__main__':
    unittest.main()
