import base64
import io
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from PIL import Image
from clipangel.core import Store, Settings, DEFAULTS, normalize_formats, describe, transform, html_text, html_fragment, rtf_text, file_urls
from clipangel.ipc import Instance
from clipangel.x11 import parse_hotkey


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name)
        self.store = Store(self.path / 'history.sqlite3')
        self.settings = dict(DEFAULTS)

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def add(self, text, **meta):
        return self.store.add({'text/plain': text.encode()}, meta, self.settings)

    def test_unicode_storage_search(self):
        ident = self.add('München Straße 日本語 😀')
        for term in ['MÜNCHEN', 'STRASSE', '日本語', '😀']:
            self.assertEqual(self.store.query(term)[0][0]['id'], ident)
        self.assertEqual(self.store.formats(ident)['text/plain'].decode(), 'München Straße 日本語 😀')

    def test_case_sensitive(self):
        self.add('MixedCase')
        self.settings['SearchCaseSensitive'] = True
        self.assertEqual(self.store.query('mixed', settings=self.settings)[1], 0)
        self.assertEqual(self.store.query('Mixed', settings=self.settings)[1], 1)

    def test_independent_words(self):
        self.add('alpha middle beta')
        self.assertEqual(self.store.query('beta alpha')[1], 1)
        self.settings['SearchWordsIndependently'] = False
        self.assertEqual(self.store.query('beta alpha', settings=self.settings)[1], 0)

    def test_search_wildcards_literal_underscore(self):
        self.add('alpha middle beta_1 50%')
        self.assertEqual(self.store.query('alpha%beta')[1], 1)
        self.assertEqual(self.store.query('beta_1')[1], 1)
        self.assertEqual(self.store.query('beta_2')[1], 0)
        self.settings['SearchWildcards'] = False
        self.assertEqual(self.store.query('alpha%beta', settings=self.settings)[1], 0)
        self.assertEqual(self.store.query('50%', settings=self.settings)[1], 1)

    def test_search_fields(self):
        self.add('A clip', app='SourceApplication')
        self.assertEqual(self.store.query('SourceApplication')[1], 0)
        self.settings['SearchAllFields'] = True
        self.assertEqual(self.store.query('SourceApplication', settings=self.settings)[1], 1)

    def test_duplicate_preserves_marks(self):
        ident = self.add('duplicate', favorite=True, used=True)
        self.add('other')
        again = self.add('duplicate')
        self.assertEqual(ident, again)
        self.assertEqual(self.store.count(), 2)
        self.assertTrue(self.store.get(ident)['favorite'])
        self.assertTrue(self.store.get(ident)['used'])
        self.assertEqual(self.store.query()[0][0]['id'], ident)

    def test_formatted_duplicate_detection(self):
        self.add('same')
        self.store.add({'text/plain': b'same', 'text/html': b'<b>same</b>'})
        self.assertEqual(self.store.count(), 1)
        self.settings['UseFormattingInDuplicateDetection'] = True
        self.store.add({'text/plain': b'same', 'text/html': b'<i>same</i>'}, settings=self.settings)
        self.assertEqual(self.store.count(), 2)

    def test_edit_preserves_id_and_metadata(self):
        ident = self.add('before', favorite=True, app='app', window='window')
        self.store.edit(ident, 'after 😀')
        self.assertEqual(self.store.count(), 1)
        self.assertEqual(self.store.get(ident)['text'], 'after 😀')
        self.assertEqual(self.store.get(ident)['window'], 'window')
        self.assertTrue(self.store.get(ident)['favorite'])
        self.assertEqual(self.store.db.execute('PRAGMA foreign_key_check').fetchall(), [])

    def test_delete_undo_does_not_overwrite_new_clip(self):
        ident = self.add('old')
        self.store.delete([ident])
        new = self.add('new')
        restored = self.store.undo_delete()
        self.assertEqual(self.store.get(new)['text'], 'new')
        self.assertEqual(self.store.get(restored[0])['text'], 'old')
        self.assertEqual(self.store.count(), 2)

    def test_favorites_type_and_date(self):
        self.add('old', favorite=True, created='2024-01-10T12:00:00+00:00')
        self.add('new', used=True, created='2025-02-11T00:00:00+00:00')
        self.assertEqual(self.store.query(mark='favorite')[1], 1)
        self.assertEqual(self.store.query(mark='used')[1], 1)
        self.assertEqual(self.store.query(kind='img')[1], 0)
        self.assertEqual(self.store.query(start_date='2025-02-11', end_date='2025-02-11')[1], 1)

    def test_move_order(self):
        a=self.add('a'); b=self.add('b'); c=self.add('c')
        self.store.move(a, 'up')
        self.assertEqual([r['id'] for r in self.store.query()[0]], [c,a,b])
        self.store.move(b, 'top')
        self.assertEqual(self.store.query()[0][0]['id'], b)

    def test_retention_keeps_favorites(self):
        favorite=self.add('favorite', favorite=True, created='2000-01-01T00:00:00+00:00')
        for i in range(14): self.add(str(i), created='2000-01-01T00:00:00+00:00')
        self.settings['HistoryDepthNumber']=10
        self.store.prune(self.settings)
        self.assertEqual(self.store.count(), 11)
        self.settings['HistoryDepthDays']=1
        self.store.prune(self.settings)
        self.assertEqual(self.store.count(), 1)
        self.assertTrue(self.store.get(favorite)['favorite'])

    def fixtures(self):
        out=io.BytesIO(); Image.new('RGB',(40,30),'white').save(out, 'PNG')
        return [
            {'text/plain':'Unicode Straße 😀'.encode()},
            {'text/plain':b'Rich', 'text/html':b'<p><b>Rich</b></p>'},
            {'text/plain':b'RTF', 'text/rtf':br'{\rtf1\ansi\b RTF\b0}'},
            {'image/png':out.getvalue()},
            {'text/uri-list':b'file:///tmp/one.txt\r\nfile:///tmp/two.txt\r\n'},
        ]

    def test_json_full_format_roundtrip(self):
        ids=[self.store.add(f, {'favorite':True}) for f in self.fixtures()]
        dest=self.path/'export.json'; self.store.export_json(dest, ids)
        other=Store(self.path/'other.sqlite3')
        try:
            self.assertEqual(other.import_file(dest), 5)
            exported={r['kind']:other.formats(r['id']) for r in other.query()[0]}
            original={r['kind']:self.store.formats(r['id']) for r in self.store.query()[0]}
            self.assertEqual(exported, original)
        finally: other.close()

    def test_cac_five_types_roundtrip(self):
        ids=[self.store.add(f, {'favorite':True}) for f in self.fixtures()]
        dest=self.path/'export.cac'; self.store.export_cac(dest, ids)
        other=Store(self.path/'other.sqlite3')
        try:
            self.assertEqual(other.import_file(dest), 5)
            self.assertEqual({r['kind'] for r in other.query()[0]}, {'text','html','rtf','img','file'})
            self.assertEqual(other.query(mark='favorite')[1], 5)
            for r in other.query()[0]:
                if r['kind']=='img': self.assertEqual(other.formats(r['id'])['image/png'], self.fixtures()[3]['image/png'])
        finally: other.close()

    def test_windows_sqlite_import(self):
        source=self.path/'windows.db'; db=sqlite3.connect(source)
        db.execute('CREATE TABLE Clips (Id INTEGER, Type TEXT, Text TEXT, Title TEXT, Application TEXT, Window TEXT, Created TEXT, Favorite BOOL, Used BOOL, HtmlText TEXT, RichText TEXT, Binary BLOB, Url TEXT)')
        db.execute('INSERT INTO Clips VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)', (12,'html','Original','Title','winapp','Window','2020-04-09T10:20:30',1,0,'<b>Original</b>','','',''))
        db.commit(); db.close()
        self.assertEqual(self.store.import_file(source), 1)
        row=self.store.query()[0][0]
        self.assertEqual(row['title'],'Title'); self.assertTrue(row['favorite'])
        self.assertEqual(self.store.formats(row['id'])['text/html'], b'<b>Original</b>')

    def test_reject_xml_entities(self):
        dest=self.path/'malformed.cac'; dest.write_text('<!DOCTYPE a [<!ENTITY x SYSTEM "file:///etc/passwd">]><NewDataSet/>')
        with self.assertRaises(ValueError): self.store.import_file(dest)
        self.assertEqual(self.store.count(),0)

    def test_import_transaction_rolls_back(self):
        with self.assertRaises(Exception):
            self.store._import_prepared([({'text/plain':None},{}),({'text/plain':b'ok'},{})])
        self.assertEqual(self.store.count(),0)

    def test_invalid_json_does_not_partially_import(self):
        dest=self.path/'bad.json'
        dest.write_text(json.dumps({'format':'clipangel-linux','version':1,'clips':[{'formats':{'text/plain':base64.b64encode(b'valid').decode()}},{'formats':{'text/plain':'not base64!'}}]}))
        with self.assertRaises(Exception): self.store.import_file(dest)
        self.assertEqual(self.store.count(),0)

    def test_backup(self):
        self.add('backup'); self.store.backup(self.path/'backup.db')
        db=sqlite3.connect(self.path/'backup.db')
        self.assertEqual(db.execute('SELECT text FROM clips').fetchone()[0], 'backup'); db.close()

    def test_private_permissions(self):
        self.assertEqual(self.store.path.stat().st_mode & 0o777, 0o600)
        self.assertEqual(self.path.stat().st_mode & 0o777, 0o700)

    def test_settings_roundtrip_recovery(self):
        p=self.path/'config/settings.json'; s=Settings(p); s['WordWrap']=False; s.save()
        self.assertFalse(Settings(p)['WordWrap'])
        p.write_text('{broken'); s=Settings(p); self.assertTrue(s.warning); s.save()
        self.assertTrue(p.with_name('settings.json.unreadable-backup').exists())

    def test_html_no_script_content(self):
        self.assertEqual(html_text('<head>hidden</head><p>Visible <b>text</b></p><script>evil()</script>'),'Visible text')
        self.assertEqual(html_fragment('Version:0.9\n<!--StartFragment--><b>A</b><!--EndFragment-->'),'<b>A</b>')

    def test_rtf_text(self):
        self.assertIn('Hello',rtf_text(r'{\rtf1\ansi Hello \b world\b0.}'))

    def test_file_copy_not_cut(self):
        formats=normalize_formats({'x-special/gnome-copied-files':b'cut\nfile:///tmp/a.txt'})
        self.assertTrue(formats['x-special/gnome-copied-files'].startswith(b'copy\n'))
        self.assertEqual(file_urls(formats),['file:///tmp/a.txt'])

    def test_text_transforms(self):
        self.assertEqual(transform('hello world',case='upper_camel'),'HelloWorld')
        self.assertEqual(transform('HelloWorld',case='from_camel'),'hello world')
        self.assertEqual(transform('ABC',case='lower'),'abc')
        self.assertEqual(transform('',case='lower_camel'),'')
        self.assertEqual(transform('a\r\nb',replace_eol=True),'a b')
        self.assertEqual(transform('a\tb',tabs=2),'a  b')

    def test_shortcut_parser(self):
        self.assertEqual(parse_hotkey('Ctrl+Shift+V'),('v',5))
        with self.assertRaises(ValueError): parse_hotkey('v')
        with self.assertRaises(ValueError): parse_hotkey('invalid+V')

    def test_single_instance_ipc(self):
        a=Instance(self.path); b=Instance(self.path)
        try:
            self.assertTrue(a.primary); self.assertFalse(b.primary)
            b.send({'action':'add-text','text':'hello 😀'})
            commands=a.commands()
            self.assertEqual(commands,[{'action':'add-text','text':'hello 😀'}])
        finally: b.close(); a.close()

if __name__=='__main__': unittest.main()
