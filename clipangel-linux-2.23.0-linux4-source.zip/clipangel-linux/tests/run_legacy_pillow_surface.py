#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Exercise app rendering with legacy constants, not a real Pillow 9.0 install."""
import sys
from pathlib import Path
import types
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from PIL import __version__ as pillow_version
from clipangel import pillow_compat

# Image operations still use the installed Pillow. Only the app-facing
# constant namespace is changed, so this is an API-compatibility simulation.
pillow_compat.Resampling = types.SimpleNamespace(LANCZOS=1, NEAREST=0)
print(f"Installed Pillow: {pillow_version}; application uses legacy integer constants.", flush=True)
print("This is not a test with Pillow 9.0.1 installed.", flush=True)
suite = unittest.defaultTestLoader.discover(str(Path(__file__).parent))
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
