import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import tkinter as tk
import unittest
from PIL import Image
from clipangel.core import Settings,Store
from clipangel.app import Application
from clipangel.x11 import X11
from clipangel.dialogs import SettingsDialog,TextEditor,PasteSpecial,compare_dialog


@unittest.skipUnless(os.environ.get('DISPLAY'), 'requires an X11 display (xvfb-run)')
class GUITests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.path=Path(self.temp.name)
        self.root=tk.Tk(className='ClipAngel')
        self.settings=Settings(self.path/'settings.json')
        self.store=Store(self.path/'history.sqlite3')
        self.app=Application(self.root,self.store,self.settings)
        self.errors=[]; self.root.report_callback_exception=lambda *args:self.errors.append(args)
        self.peer=X11(lambda *args:None)
        self.pump(.4)

    def tearDown(self):
        self.peer.close()
        if self.app.running: self.app.quit()
        self.temp.cleanup()
        self.assertEqual(self.errors,[])

    def pump(self, seconds=.2, until=None):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            self.peer.poll(); self.root.update(); time.sleep(.005)
            if until and until(): return

    def test_capture_text_and_favorite_filter(self):
        self.peer.copy({'text/plain':'captured Unicode München'.encode()})
        self.pump(2,lambda:self.store.count()>0)
        self.assertEqual(self.store.count(),1)
        ident=self.store.query()[0][0]['id']
        self.app.select(ident); self.app.favorite(True)
        self.app.mark_var.set('favorite'); self.app.refresh()
        self.assertEqual(len(self.app.rows),1)
        self.app.search_var.set('MÜNCHEN'); self.pump(.3)
        self.assertEqual(len(self.app.rows),1)
        self.app.search_var.set('missing'); self.pump(.3)
        self.assertEqual(len(self.app.rows),0)

    def test_monitoring_pause_and_forced_capture(self):
        self.settings['MonitoringClipboard']=False
        self.peer.copy({'text/plain':b'paused'})
        self.pump(.4); self.assertEqual(self.store.count(),0)
        self.app.capture_current(); self.pump(2,lambda:self.store.count()>0)
        self.assertEqual(self.store.count(),1)

    def test_privacy_hint_skips_capture(self):
        self.peer.copy({'text/plain':b'do not save','application/x-keepassxc-secret':b'1'})
        self.pump(.4); self.assertEqual(self.store.count(),0)

    def test_capture_size_limit(self):
        self.settings['MaxClipSizeKB']=1
        self.peer.copy({'text/plain':b'x'*2000})
        self.pump(.5); self.assertEqual(self.store.count(),0)

    def test_capture_rich_preview(self):
        self.peer.copy({'text/plain':b'Rich preview','text/html':b'<p><b>Rich preview</b></p><script>blocked</script>'})
        self.pump(2,lambda:self.store.count()>0)
        ident=self.store.query()[0][0]['id']; self.app.select(ident)
        self.app.toggle('ShowNativeTextFormatting'); self.pump(.3)
        self.assertEqual(self.store.get(ident)['kind'],'html')
        self.assertIn('Rich preview',self.app.preview.text.get('1.0','end'))
        self.assertNotIn('blocked',self.app.preview.text.get('1.0','end'))

    def test_capture_image_preview(self):
        out=io.BytesIO(); Image.new('RGB',(350,180),'white').save(out,'PNG')
        self.peer.copy({'image/png':out.getvalue()})
        self.pump(2,lambda:self.store.count()>0)
        ident=self.store.query()[0][0]['id']; self.app.select(ident); self.pump(.3)
        self.assertEqual(self.store.get(ident)['kind'],'img')
        self.assertTrue(self.app.preview.canvas.winfo_ismapped())

    def test_clipboard_survives_source_exit(self):
        payload=b'persisted after source exit'
        self.peer.copy({'text/plain':payload})
        self.pump(2,lambda:self.store.count()>0)
        self.peer.close()
        self.peer=X11(lambda *args:None)
        self.pump(.3)
        events=[]; self.peer.event=lambda *args:events.append(args)
        self.peer.request('UTF8_STRING',920)
        self.pump(2,lambda:any(e==2 and token==920 for e,token,_ in events))
        self.assertIn((2,920,payload),events)

    def test_settings_editor_paste_special_compare(self):
        values=[]
        dialog=SettingsDialog(self.root,self.settings,self.store.path,values.append)
        self.pump(.1); dialog.accept(); self.assertEqual(len(values),1)
        saved=[]; editor=TextEditor(self.root,'before','Test editor',False,lambda *args:saved.append(args))
        editor.text.delete('1.0','end'); editor.text.insert('1.0','after'); editor.accept()
        self.assertEqual(saved,[('after',False)])
        changed=[]; special=PasteSpecial(self.root,['hello','world'],self.settings,lambda *args:changed.append(args))
        special.case.set('upper'); special.accept('copy')
        self.assertEqual(changed,[('HELLO\nWORLD','copy')])
        compare_dialog(self.root,{'id':1,'text':'a\nb','title':'Before'},{'id':2,'text':'a\nc','title':'After'},lambda text:None)
        self.pump(.2)
        for child in self.root.winfo_children():
            if isinstance(child,tk.Toplevel): child.destroy()

    def test_copy_selection_to_external_connection(self):
        payload='copy back 日本語'.encode()
        ident=self.store.add({'text/plain':payload}); self.app.refresh(select=ident)
        self.app.copy_selected()
        events=[]; self.peer.event=lambda *args:events.append(args)
        self.peer.request('UTF8_STRING',900)
        self.pump(2,lambda:any(e==2 and token==900 for e,token,_ in events))
        self.assertIn((2,900,payload),events)

    def test_actual_paste_into_independent_application(self):
        target_code=r'''
import tkinter as tk,sys
from pathlib import Path
p=Path(sys.argv[1]); r=tk.Tk(className='ClipAngelTestTarget'); r.title('Independent paste target')
t=tk.Text(r); t.pack(); r.update(); t.focus_force()
(p/'ready').write_text(str(r.winfo_id()))
def save():
 (p/'received').write_text(t.get('1.0','end-1c'),encoding='utf-8')
 r.after(40,save)
r.after(40,save); r.after(15000,r.destroy); r.mainloop()
'''
        proc=subprocess.Popen([sys.executable,'-c',target_code,str(self.path)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:
            self.pump(4,lambda:(self.path/'ready').exists())
            self.assertTrue((self.path/'ready').exists(),'Target did not start')
            self.pump(.5)
            target_id,app,title=self.app.x11.active()
            self.assertNotEqual(app.lower(),'clipangel')
            self.app.last_target=target_id; self.app.last_target_app=app
            text='Paste-back verified: München 日本語 😀\nSecond line.'
            ident=self.store.add({'text/plain':text.encode()})
            self.app.refresh(select=ident); self.app.show(); self.pump(.25)
            self.app.paste('text')
            def received():
                try:return (self.path/'received').read_text()==text
                except FileNotFoundError:return False
            self.pump(4,received)
            self.assertTrue(received(),f'Paste result: {(self.path/"received").read_text()!r}')
            self.assertTrue(self.store.get(ident)['used'])
        finally:
            proc.terminate(); proc.communicate(timeout=3)

if __name__=='__main__':unittest.main()
