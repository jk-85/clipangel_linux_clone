# SPDX-License-Identifier: GPL-3.0-only
"""Test both Pillow constant layouts without replacing Pillow internals."""
from pathlib import Path
import runpy
import types
import unittest
from unittest.mock import patch

from PIL import Image
from clipangel import pillow_compat


class PillowCompatibilityTests(unittest.TestCase):
    def load_with_image(self, image):
        pil = types.ModuleType("PIL")
        pil.Image = image
        # Only this module's import sees the fake PIL; real image operations
        # elsewhere in the suite always use the installed Pillow library.
        with patch.dict("sys.modules", {"PIL": pil}):
            return runpy.run_path(pillow_compat.__file__)["Resampling"]

    def test_pillow_90_legacy_constants(self):
        legacy_image = types.SimpleNamespace(LANCZOS=1, NEAREST=0)
        result = self.load_with_image(legacy_image)
        self.assertIs(result, legacy_image)
        self.assertEqual(result.LANCZOS, 1)
        self.assertEqual(result.NEAREST, 0)

    def test_modern_enum_preferred_without_legacy_constants(self):
        enum = types.SimpleNamespace(LANCZOS=1, NEAREST=0)
        modern_image = types.SimpleNamespace(Resampling=enum)
        self.assertIs(self.load_with_image(modern_image), enum)

    def test_resizing_with_installed_and_legacy_constants(self):
        legacy = self.load_with_image(types.SimpleNamespace(LANCZOS=1, NEAREST=0))
        for constants in (pillow_compat.Resampling, legacy):
            with self.subTest(constants=repr(constants)):
                with Image.new("RGBA", (40, 20), "white") as image:
                    with image.resize((10, 5), constants.LANCZOS) as resized:
                        self.assertEqual(resized.size, (10, 5))
                    image.thumbnail((8, 8), constants.NEAREST)
                    self.assertEqual(image.size, (8, 4))


if __name__ == "__main__":
    unittest.main()
